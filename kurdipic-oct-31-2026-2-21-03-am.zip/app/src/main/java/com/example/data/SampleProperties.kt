package com.example.data

import com.example.R
import com.example.data.model.Agent
import com.example.data.model.ListingType
import com.example.data.model.Property
import com.example.data.model.PropertyType

object SampleProperties {

  val duhokNeighborhoods = listOf(
    "All Duhok",
    "مالتا (Malta)",
    "ماسیک (Masik)",
    "ئەڤرۆ ستی (Avro City)",
    "سێمێل (Semel)",
    "زاویتە (Zawita)",
    "شاخکێ (Shakhke)",
    "بەڕۆشکێ (Baroshke)",
    "سندی ستی (Sindi City)",
    "گرێ باسی (Gre Basi)",
    "ئازادی (Azadi)",
    "شۆڕش (Shorsh)",
    "کەی ئاڕ ئۆ (KRO)",
    "نزارکێ (Nizarke)",
    "دهۆک مۆڵ (Duhok Mall)",
    "سەرسنگ (Sarsing)",
    "ئامێدیێ (Amedi)",
    "زاخۆ (Zakho)",
    "ئاکرێ (Akre)",
    "بریفکا (Brifka)"
  )

  val defaultAgent = Agent(
    id = "agent_primary",
    name = "The Duhok-Aqar Agent",
    agency = "The Duhok-Aqar Real Estate",
    phone = "07514036954",
    whatsapp = "+9647514036954",
    rating = 5.0f,
    reviewsCount = 48,
    verified = true
  )

  private val agentDilshad = Agent(
    id = "agent_1",
    name = "The Duhok-Aqar Agent",
    agency = "The Duhok-Aqar Real Estate",
    phone = "07514036954",
    whatsapp = "+9647514036954",
    rating = 4.9f,
    reviewsCount = 42,
    verified = true
  )

  private val agentRojin = Agent(
    id = "agent_2",
    name = "The Duhok-Aqar Agent",
    agency = "The Duhok-Aqar Real Estate",
    phone = "07514036954",
    whatsapp = "+9647514036954",
    rating = 4.8f,
    reviewsCount = 38,
    verified = true
  )

  private val agentKovan = Agent(
    id = "agent_3",
    name = "The Duhok-Aqar Agent",
    agency = "The Duhok-Aqar Real Estate",
    phone = "07514036954",
    whatsapp = "+9647514036954",
    rating = 5.0f,
    reviewsCount = 56,
    verified = true
  )

  val properties: List<Property> = listOf(
    Property(
      id = "p1",
      titleEn = "Royal Hillside Villa with Panoramic Zagros View",
      titleBadini = "ڤێلایەکا شایانە ل سەر گرێ ماسیک دگەل دیمەنێ چیا",
      titleSorani = "ڤێلایەکی شاھانە لەسەر گردی ماسیک بە دیمەنی چیاکان",
      titleArabic = "فيلا ملكية فاخرة في تلال ماسيك مع إطلالة جبلية بانورامية",
      neighborhoodEn = "Masik",
      neighborhoodKu = "ماسیک",
      neighborhoodArabic = "ماسيك",
      type = PropertyType.VILLA,
      listingType = ListingType.FOR_SALE,
      priceUsd = 480000.0,
      areaSqm = 520,
      bedrooms = 5,
      bathrooms = 6,
      parkingSpaces = 3,
      yearBuilt = 2024,
      isFeatured = true,
      isTapuVerified = true,
      descriptionEn = "A magnificent architectural masterpiece nestled on the scenic hillside of Masik, Duhok. Features triple-height glass ceilings overlooking the city and Zagros mountain range, infinity heated pool, private Italian marble sauna, smart home automation, and expansive landscaped garden. Official 100% Tapu title deed registered with Duhok Real Estate Directorate.",
      descriptionBadini = "شاکارەکێ ئەندازیاریێ سەردەمیانە ل جهێ بلند و دەولەمەندێ ماسیک ل دهۆکێ. پێکدهێت ژ پەنجەرێن مەزنێن پانۆراما، حەوزا مەلەڤانیێ یا گەرم، ساونایا مەڕمەڕا ئیتالی، سیستەمێ زیرەک یێ خانی، و باخچەکێ مەزن یێ چاندیی. تاپۆ ١٠٠٪ یا باوەرپێکری ل رێڤەبەریا تاپۆیا دهۆکێ.",
      descriptionSorani = "شاكارێكی ئەندازیاری هاوچەرخ لە شوێنێکی بەرز لە ماسیکی دهۆک بە دیمەنی تەواوی زنجیرە چیاکان. خاوەنی حەوزی مەلەی گەرم، ساونای مەڕمەڕی ئیتاڵی، سیستەمی هۆشمەندی ماڵ و باخچەی فراوان. تاپۆی ڕەسمی ١٠٠٪ پەسەندکراو لە بەڕێوەبەرایەتی تۆماری دهۆک.",
      descriptionArabic = "تحفة معمارية عصرية استثنائية تقع على تلال حي ماسيك الراقي في دهوك. تتميز بنوافذ زجاجية بانورامية وإطلالة على جبال زاغروس، مسبح مدفأ، ساونا رخام إيطالي، ونظام منزلي ذكي كامل مع حديقة واسعة. طابو ملك صرف ١٠٠٪ موثق رسمياً في مديرية التسجيل العقاري بدهوك.",
      amenities = listOf(
        "Panoramic Mountain View",
        "Infinity Heated Pool",
        "Private Landscaped Garden",
        "Smart Home System",
        "Central VRF Cooling & Heating",
        "Registered Tapu Deed",
        "Backup Solar Power & Generator",
        "CCTV & 24/7 Gated Security"
      ),
      imageResIds = listOf(
        R.drawable.img_hero_duhok,
        R.drawable.img_villa_malta,
        R.drawable.img_apt_duhok
      ),
      agent = agentDilshad,
      latitude = 36.8720,
      longitude = 42.9790,
      isFavorite = true
    ),
    Property(
      id = "p2",
      titleEn = "Luxury Modern Penthouse in Avro City",
      titleBadini = "شوقەکا لوکس یا پێنتهائوس ل ئەڤرۆ ستی",
      titleSorani = "شوقەیەکی لوکسی پێنتهاوس لە ئەڤرۆ ستی",
      titleArabic = "شقة بنتهاوس فاخرة بإطلالة غروب ساحرة في أفرو سيتي",
      neighborhoodEn = "Avro City",
      neighborhoodKu = "ئەڤرۆ ستی",
      neighborhoodArabic = "أفرو سيتي",
      type = PropertyType.APARTMENT,
      listingType = ListingType.FOR_SALE,
      priceUsd = 165000.0,
      areaSqm = 240,
      bedrooms = 3,
      bathrooms = 3,
      parkingSpaces = 2,
      yearBuilt = 2023,
      isFeatured = true,
      isTapuVerified = true,
      descriptionEn = "Located in the premier residential tower in Avro City, this designer penthouse offers high-floor panoramic sunset views of Duhok. Features imported European hardwood flooring, open-concept German kitchen with marble island, and 2 designated underground parking spaces.",
      descriptionBadini = "شوقەکا ناڤدار ل تاوەرێن ئەڤرۆ ستی ل دهۆکێ، دیمەنەکێ جوانێ ڕۆژئاڤابوونێ ل دەڤەرێ هەیە. مەتبەخەکێ مۆدێرنێ ئەلمانی، بەلە کۆنەکا مەزن، و جهێ پارککرنا دو ترۆمبێلا ل ژێر عەردی.",
      descriptionSorani = "دەکەوێتە یەکێک لە باشترین تاوەرەکانی ئەڤرۆ ستی، دیمەنی جوانی ئاوابوونی خۆر بەسەر شاری دهۆکدا دەبەخشێت. مەتبەخی ئەڵمانی بە دوورگەی مەڕمەڕ و شوێنی تایبەت بۆ دوو ئۆتۆمبێل.",
      descriptionArabic = "شقة بنتهاوس في برج راقٍ داخل أفرو سيتي، توفر إطلالة علوية خلابة على غروب شمس دهوك. مطبخ ألماني مجهز، شرفة رحبة، وموقفان مغطيان تحت الأرض مع مصعد سريع.",
      amenities = listOf(
        "Elevator Direct Access",
        "Sunset City View",
        "Underground Parking",
        "Full Fitted Kitchen",
        "Community Gym & Pool",
        "24/7 Security",
        "Balcony Terrace"
      ),
      imageResIds = listOf(
        R.drawable.img_apt_duhok,
        R.drawable.img_hero_duhok,
        R.drawable.img_villa_malta
      ),
      agent = agentRojin,
      latitude = 36.8580,
      longitude = 42.9980,
      isFavorite = false
    ),
    Property(
      id = "p3",
      titleEn = "Contemporary Stone Duplex Villa in Malta",
      titleBadini = "ڤێلایەکا دۆپلێکس یا کەڤرێ سرۆشتی ل مالتا",
      titleSorani = "ڤێلایەکی دۆپلێکسی بەردی سروشتی لە ماڵتا",
      titleArabic = "فيلا دوبلكس حجر طبيعي كوردستاني في حي مالطا الراقي",
      neighborhoodEn = "Malta",
      neighborhoodKu = "مالتا",
      neighborhoodArabic = "مالطا",
      type = PropertyType.VILLA,
      listingType = ListingType.FOR_SALE,
      priceUsd = 340000.0,
      areaSqm = 400,
      bedrooms = 4,
      bathrooms = 4,
      parkingSpaces = 2,
      yearBuilt = 2023,
      isFeatured = true,
      isTapuVerified = true,
      descriptionEn = "Crafted with authentic Kurdistan natural stone and warm contemporary timber accents in prestigious Malta neighborhood. Includes an outdoor BBQ pavilion, olive & palm garden, double-height salon, and master suite with jacuzzi.",
      descriptionBadini = "ئاڤاکری ب کەڤرێ سرۆشتیێ کوردستانێ ل گەرەکا ناڤدار و ئاراما مالتا ل دهۆکێ. باخچەکێ تایبەت، شوینێ کەباب و باربیکیو، دۆپلێکس، و ژوورا نڤستنێ یا ماستەر دگەل جاکوزی.",
      descriptionSorani = "دروستکراو بە بەردی سروشتی کوردستان و دار لە گەڕەکی ماڵتای دهۆک. باخچەی زەیتوون، شوێنی باربیکیۆ، هۆڵی بەرز و ماستەر بێدڕومی گەورە لەگەڵ جاکوزی.",
      descriptionArabic = "فيلا دوبلكس مبنية بالحجر الطبيعي الكوردستاني الفاخر في حي مالطا الهادئ. حديقة أشجار زيتون ونخيل، جلسة باربيكيو خارجية، صالة مرتفعة الأسقف، وجناح نوم رئيسي فخم مع جاكوزي.",
      amenities = listOf(
        "Kurdistan Natural Stone",
        "Private Courtyard",
        "Underfloor Heating",
        "BBQ Pavilion",
        "Master Suite with Jacuzzi",
        "Walk-in Closet",
        "Tapu Certified"
      ),
      imageResIds = listOf(
        R.drawable.img_villa_malta,
        R.drawable.img_hero_duhok,
        R.drawable.img_apt_duhok
      ),
      agent = agentKovan,
      latitude = 36.8620,
      longitude = 42.9650,
      isFavorite = true
    ),
    Property(
      id = "p4",
      titleEn = "Spacious Furnished Residence for Rent in Gre Basi",
      titleBadini = "خانیەکێ بەرینێ مۆبێلێ کرێ ل گرێ باسی",
      titleSorani = "خانوویەکی گەورەی کەلوپەلدار بۆ کرێ لە گرێ باسی",
      titleArabic = "بيت عائلي مؤثث بالكامل للإيجار في حي كري باسي",
      neighborhoodEn = "Gre Basi",
      neighborhoodKu = "گرێ باسی",
      neighborhoodArabic = "كري باسي",
      type = PropertyType.VILLA,
      listingType = ListingType.FOR_RENT,
      priceUsd = 1600.0,
      areaSqm = 320,
      bedrooms = 4,
      bathrooms = 3,
      parkingSpaces = 2,
      yearBuilt = 2022,
      isFeatured = false,
      isTapuVerified = true,
      descriptionEn = "A peaceful high-elevation family home available for lease in Gre Basi. Completely furnished with quality Scandinavian furniture, modern kitchen appliances, private garage, clean mountain breeze, and close proximity to top international schools in Duhok.",
      descriptionBadini = "خانیەکێ خێزانیێ ئارام ل جهێ بلندێ گرێ باسی ل دهۆکێ بۆ کرێ. ب تەمامی مۆبێلێ مۆدێرن تێدایە، هەوایێ پاقژێ چیایی، گەراجێ تایبەت، و نێزیکی قوتابخانەیێن نێڤدەولەتی.",
      descriptionSorani = "خانوویەکی خێزانی ئارام لە گرێ باسی دهۆک بۆ کرێ. بە تەواوی بە مۆبیلیاتی کوالیتی بەرز ڕازاوەتەوە، سیستەمی تەبرید و گەرمی، و نزیک لە قوتابخانە نێودەوڵەتییەکان.",
      descriptionArabic = "منزل عائلي مؤثث بالكامل ومريح في حي كري باسي المرتفع والهادئ في دهوك. إطلالة جبلية نقية، كراج سيارات خاص، وقريب من المدارس والمراكز الصحية.",
      amenities = listOf(
        "Fully Furnished",
        "High Elevation Mountain Breeze",
        "Private Garage",
        "Central Heating & AC",
        "Fast Fiber Internet Ready",
        "Water Well & Reserve Tank"
      ),
      imageResIds = listOf(
        R.drawable.img_villa_malta,
        R.drawable.img_apt_duhok,
        R.drawable.img_hero_duhok
      ),
      agent = agentDilshad,
      latitude = 36.8810,
      longitude = 42.9830,
      isFavorite = false
    ),
    Property(
      id = "p5",
      titleEn = "Executive 3-Bedroom Apartment in Central Azadi",
      titleBadini = "شوقەکا بەرین ل ناڤەندا ئازادی نێزیک بازاڕی",
      titleSorani = "شوقەیەکی گەورەی ٣ ژووری لە ناوەندی ئازادی",
      titleArabic = "شقة تنفيذية ٣ غرف نوم في قلب حي آزادي قرب السوق",
      neighborhoodEn = "Azadi",
      neighborhoodKu = "ئازادی",
      neighborhoodArabic = "آزادي",
      type = PropertyType.APARTMENT,
      listingType = ListingType.FOR_RENT,
      priceUsd = 950.0,
      areaSqm = 185,
      bedrooms = 3,
      bathrooms = 2,
      parkingSpaces = 1,
      yearBuilt = 2022,
      isFeatured = false,
      isTapuVerified = true,
      descriptionEn = "Prime central Duhok location in heart of Azadi, walking distance to cafes, banks, and Duhok bazaar. Features high ceilings, sunny exposure, modern elevator, soundproof windows, and 24/7 power coverage.",
      descriptionBadini = "جهەکێ زۆر سەرەکی ل ناڤەندا گەرەکا ئازادی، ب پیان نێزیکی بازاڕ و کافێتێریایێن دهۆکێیە. ئەسەنسۆر، کەهرەبا بەردەوام ٢٤ دەمژمێر، و پەنجەرێن نەهێلانا دەنگی.",
      descriptionSorani = "شوێنێکی ستراتیژی لە ناوەندی گەڕەکی ئازادی دهۆک، نزیک لە بازاڕ و بانکەکان. ئەسانسۆری مۆدێرن، کارەبای بەردەوامی ٢٤ کاتژمێری و پەنجەرەی دژە دەنگ.",
      descriptionArabic = "موقع حيوي وسكني ممتاز في وسط حي آزادي، على مسافة خطوات من أسواق دهوك والمرافق الخدمية. مصعد حديث، كهرباء مستمرة ٢٤ ساعة، ونوافذ عازلة للصوت.",
      amenities = listOf(
        "Prime Central Location",
        "Modern Elevator",
        "Generator 24/7",
        "Double-Glazed Windows",
        "Balcony",
        "Security Concierge"
      ),
      imageResIds = listOf(
        R.drawable.img_apt_duhok,
        R.drawable.img_hero_duhok,
        R.drawable.img_villa_malta
      ),
      agent = agentRojin,
      latitude = 36.8655,
      longitude = 42.9890,
      isFavorite = false
    ),
    Property(
      id = "p6",
      titleEn = "Prime Commercial Land for Development in Shorsh",
      titleBadini = "ئەردەکێ ستراتیجیێ بازرگانی ل جادەیا سەرەکی یا شۆڕش",
      titleSorani = "زەوییەکی بازرگانی ستراتیژی لەسەر شەقامی سەرەکی شۆڕش",
      titleArabic = "أرض تجارية استثمارية ممتازة على الشارع العام في حي شورش",
      neighborhoodEn = "Shorsh",
      neighborhoodKu = "شۆڕش",
      neighborhoodArabic = "شورش",
      type = PropertyType.LAND,
      listingType = ListingType.FOR_SALE,
      priceUsd = 550000.0,
      areaSqm = 1200,
      bedrooms = 0,
      bathrooms = 0,
      parkingSpaces = 0,
      yearBuilt = 2024,
      isFeatured = false,
      isTapuVerified = true,
      descriptionEn = "Exceptional investment and development land plot located on the main boulevard in Shorsh near University of Duhok. Corner plot with 45-meter frontage, zoned for commercial or mixed-use multi-story residential building.",
      descriptionBadini = "پارجەکا ئەردی یا بازرگانی یا زۆر گرانبها ل سەر جادەیا گشتی یا شۆڕش نێزیک زانکۆیا دهۆکێ. بەرهەڤە بۆ ئاڤاکرنا مۆل، کۆمپلێکس یان باڵەخانەیا نیشتەجێبوونێ. تاپۆ ١٠٠٪ تەپا یا پاقژە.",
      descriptionSorani = "زەوییەکی گەورە و ستراتیژی بازرگانی لەسەر شەقامی شۆڕش نزیک زانکۆی دهۆک. گونجاوە بۆ پڕۆژەی تجاری یان شوقە، بە ڕووبەری بەرەی ٤٥ مەتری و تاپۆی تەواو.",
      descriptionArabic = "قطعة أرض تجارية استثمارية متميزة على الشارع الرئيسي في حي شورش قرب جامعة دهوك. واجهة ٤٥ متراً مناسبة لبناء مجمع تجاري أو أبراج سكنية. سند ملكية رسمي جاهز للتحويل الفوري.",
      amenities = listOf(
        "Commercial Zoning",
        "Main Boulevard Frontage (45m)",
        "Direct Road & Electricity Access",
        "Clean 100% Tapu Deed",
        "High ROI Investment Potential"
      ),
      imageResIds = listOf(
        R.drawable.img_hero_duhok,
        R.drawable.img_villa_malta,
        R.drawable.img_apt_duhok
      ),
      agent = agentKovan,
      latitude = 36.8520,
      longitude = 43.0110,
      isFavorite = false
    ),
    Property(
      id = "p7",
      titleEn = "Luxury Modern Apartment with Dam View in KRO",
      titleBadini = "شوقەکا نوی ل کەی ئاڕ ئۆ دگەل دیمەنێ دەوروبەرێ بەنداڤێ",
      titleSorani = "شوقەیەکی نوێ لە KRO بە دیمەنی دەوروبەری بەنداو",
      titleArabic = "شقة عصرية راقية في حي KRO بإطلالة نحو سد دهوك",
      neighborhoodEn = "KRO",
      neighborhoodKu = "کەی ئاڕ ئۆ",
      neighborhoodArabic = "كي آر أو",
      type = PropertyType.APARTMENT,
      listingType = ListingType.FOR_SALE,
      priceUsd = 135000.0,
      areaSqm = 195,
      bedrooms = 3,
      bathrooms = 2,
      parkingSpaces = 1,
      yearBuilt = 2023,
      isFeatured = false,
      isTapuVerified = true,
      descriptionEn = "Located in the sought-after KRO area, close to premier medical centers and shopping plazas. Modern open layout with master bathroom, private balcony, video intercom system, and dedicated resident parking.",
      descriptionBadini = "ل جهەکێ دڵگیر ل دەڤەرا کەی ئاڕ ئۆ ل دهۆکێ، نێزیک خەستەخانە و ناڤەندێن بازرگانی. خوەدی باڵکۆنا کراوە، سیستەمێ ئینتەرکۆم یێ نوی، و جهێ پارککرنا مسۆگەر.",
      descriptionSorani = "لە ناوچەی KRO ی دهۆک، نزیک لە سەنتەرە پزیشکییەکان و شوێنە بازرگانییەکان. دیزاینی مۆدێرنی کراوە لەگەڵ بەلەکۆن و ئینتەرکۆمی ڤیدیۆیی.",
      descriptionArabic = "تقع في منطقة KRO المرغوبة بدهوك قرب المراكز الطبية والمجمعات التجارية. تصميم داخلي مفتوح ومريح، شرفة خاصة، موقف سيارات، ونظام إنتركم ذكي.",
      amenities = listOf(
        "Dedicated Parking",
        "Intercom & Card Access",
        "Modern Sanitary Fixtures",
        "Built-in Storage",
        "Near Medical & Shopping Centers"
      ),
      imageResIds = listOf(
        R.drawable.img_apt_duhok,
        R.drawable.img_villa_malta,
        R.drawable.img_hero_duhok
      ),
      agent = agentRojin,
      latitude = 36.8630,
      longitude = 42.9940,
      isFavorite = false
    ),
    Property(
      id = "p8",
      titleEn = "Estate Villa with Private Orchard in Nizarke",
      titleBadini = "ڤێلایەکا مەزن دگەل باخچەیێ میوا ل نزارکێ",
      titleSorani = "ڤێلایەکی گەورە لەگەڵ باخچەی میوە لە نزارکێ",
      titleArabic = "فيلا مزرعة فسيحة مع بستان فواكه خاص في نزاركي دهوك",
      neighborhoodEn = "Nizarke",
      neighborhoodKu = "نزارکێ",
      neighborhoodArabic = "نزاركي",
      type = PropertyType.VILLA,
      listingType = ListingType.FOR_SALE,
      priceUsd = 390000.0,
      areaSqm = 650,
      bedrooms = 5,
      bathrooms = 5,
      parkingSpaces = 4,
      yearBuilt = 2022,
      isFeatured = true,
      isTapuVerified = true,
      descriptionEn = "An expansive private country-style estate on the slopes of Nizarke, Duhok. Features mature pomegranate and fig fruit trees, traditional Kurdish diwan majlis, outdoor summer terrace, private water well, and caretaker quarters.",
      descriptionBadini = "ڤێلایەکا ئەردێ بەرفرەهـ ل بنارێن نزارکێ ل دهۆکێ. دارێن هنار و هەژیرا، دیوانخانا کوردی یا رەسەن، بیرەکا ئاڤێ یا تایبەت، هەیوانا هاڤینێ، و جهێ پارککرنا ٤ ترۆمبێلا.",
      descriptionSorani = "ڤێلایەکی گەورەی تایبەت لە نزارکێی دهۆک. باخی هەنار و هەنجیر، دیوەخانی نەریتی کوردی، بیری ئاوی تایبەت، شوێنی کارمەندی چاودێر و گەراجی ٤ ئۆتۆمبێل.",
      descriptionArabic = "مزرعة وفيلا فسيحة على سفوح نزاركي في دهوك. أشجار تين ورمان مثمرة، ديوان ومجلس كوردي تقليدي، بئر ماء عذب خاص، تراس صيفي مطل، ومواقف لـ ٤ سيارات.",
      amenities = listOf(
        "Private Fruit Orchard",
        "Traditional Kurdish Diwan",
        "Private Water Well",
        "Caretaker Quarters",
        "Expansive 4-Car Parking",
        "Mountain Horizon View"
      ),
      imageResIds = listOf(
        R.drawable.img_hero_duhok,
        R.drawable.img_villa_malta,
        R.drawable.img_apt_duhok
      ),
      agent = agentDilshad,
      latitude = 36.8790,
      longitude = 43.0250,
      isFavorite = false
    )
  )
}
