package com.example.data.model

import androidx.compose.ui.unit.LayoutDirection

enum class AppLanguage(
  val code: String,
  val displayName: String,
  val nativeName: String,
  val subtitle: String,
  val isRtl: Boolean
) {
  BADINI(
    code = "bad",
    displayName = "Badini",
    nativeName = "بادینی (کورمانجی)",
    subtitle = "زمانێ دهۆک و دەڤەرا بەهدینان",
    isRtl = true
  ),
  SORANI(
    code = "sor",
    displayName = "Sorani",
    nativeName = "سۆرانی (کوردی)",
    subtitle = "هەولێر، سلێمانی و دەوروبەر",
    isRtl = true
  ),
  ENGLISH(
    code = "en",
    displayName = "English",
    nativeName = "English",
    subtitle = "International & Business",
    isRtl = false
  ),
  ARABIC(
    code = "ar",
    displayName = "Arabic",
    nativeName = "العربية",
    subtitle = "عقارات إقليم كوردستان",
    isRtl = true
  );

  val layoutDirection: LayoutDirection
    get() = if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr
}
