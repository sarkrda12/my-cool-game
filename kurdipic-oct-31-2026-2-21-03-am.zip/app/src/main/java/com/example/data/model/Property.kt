package com.example.data.model

enum class PropertyType(
  val labelEn: String,
  val labelBadini: String,
  val labelSorani: String,
  val labelArabic: String
) {
  ALL("All", "هەمی", "هەموو", "الكل"),
  VILLA("Villa", "ڤێلا", "ڤێلا", "فلل"),
  APARTMENT("Apartment", "شوقە", "شوقە", "شقق"),
  LAND("Land", "ئەرد", "زەوی", "أراضي"),
  COMMERCIAL("Commercial", "بازرگانی", "بازرگانی", "تجاري"),
  DUPLEX("Duplex", "دۆپلێکس", "دۆپلێکس", "دوبلكس");

  fun getLabel(lang: AppLanguage): String = when (lang) {
    AppLanguage.BADINI -> labelBadini
    AppLanguage.SORANI -> labelSorani
    AppLanguage.ARABIC -> labelArabic
    AppLanguage.ENGLISH -> labelEn
  }
}

enum class ListingType(
  val labelEn: String,
  val labelBadini: String,
  val labelSorani: String,
  val labelArabic: String
) {
  FOR_SALE("For Sale", "بۆ فڕۆشتنێ", "بۆ فرۆشتن", "للبيع"),
  FOR_RENT("For Rent", "بۆ کرێ", "بۆ کرێ", "للإيجار");

  fun getLabel(lang: AppLanguage): String = when (lang) {
    AppLanguage.BADINI -> labelBadini
    AppLanguage.SORANI -> labelSorani
    AppLanguage.ARABIC -> labelArabic
    AppLanguage.ENGLISH -> labelEn
  }
}

enum class CurrencyMode {
  USD,
  IQD,
  DAFTAR; // 1 Daftar = $10,000 USD (Kurdistan Real Estate Standard)

  fun formatPrice(usdAmount: Double, isRent: Boolean = false, lang: AppLanguage = AppLanguage.ENGLISH): String {
    val suffix = if (isRent) {
      when (lang) {
        AppLanguage.BADINI -> "/مەهانە"
        AppLanguage.SORANI -> "/مانگانە"
        AppLanguage.ARABIC -> "/شهرياً"
        AppLanguage.ENGLISH -> "/mo"
      }
    } else ""

    return when (this) {
      USD -> {
        val formatted = String.format("%,.0f", usdAmount)
        "$$formatted$suffix"
      }
      IQD -> {
        val iqdAmount = usdAmount * 1500.0
        val formatted = if (iqdAmount >= 1_000_000) {
          String.format("%,.1fM IQD", iqdAmount / 1_000_000.0)
        } else {
          String.format("%,.0f IQD", iqdAmount)
        }
        "$formatted$suffix"
      }
      DAFTAR -> {
        val daftars = usdAmount / 10000.0
        if (isRent) {
          "$$${String.format("%,.0f", usdAmount)}$suffix"
        } else {
          val daftarWord = when (lang) {
            AppLanguage.BADINI -> "دەفتەر"
            AppLanguage.SORANI -> "دەفتەر"
            AppLanguage.ARABIC -> "دفتر"
            AppLanguage.ENGLISH -> "Daftars"
          }
          "${String.format("%.1f", daftars)} $daftarWord"
        }
      }
    }
  }
}

data class Agent(
  val id: String,
  val name: String,
  val agency: String,
  val phone: String,
  val whatsapp: String,
  val rating: Float,
  val reviewsCount: Int,
  val verified: Boolean = true
)

data class Property(
  val id: String,
  val titleEn: String,
  val titleBadini: String,
  val titleSorani: String,
  val titleArabic: String,
  val neighborhoodEn: String,
  val neighborhoodKu: String,
  val neighborhoodArabic: String,
  val city: String = "Duhok",
  val type: PropertyType,
  val listingType: ListingType,
  val priceUsd: Double,
  val areaSqm: Int,
  val bedrooms: Int,
  val bathrooms: Int,
  val parkingSpaces: Int = 1,
  val yearBuilt: Int = 2023,
  val isFeatured: Boolean = false,
  val isTapuVerified: Boolean = true, // Verified Title Deed
  val descriptionEn: String,
  val descriptionBadini: String,
  val descriptionSorani: String,
  val descriptionArabic: String,
  val amenities: List<String>,
  val imageResIds: List<Int> = emptyList(),
  val imageUris: List<String> = emptyList(),
  val agent: Agent,
  val latitude: Double = 36.8679,
  val longitude: Double = 42.9886,
  val isFavorite: Boolean = false
) {
  // Backwards compatibility
  val titleKu: String get() = titleBadini
  val neighborhood: String get() = neighborhoodEn
  val description: String get() = descriptionEn

  fun getImageSources(): List<Any> {
    val list = mutableListOf<Any>()
    list.addAll(imageUris)
    list.addAll(imageResIds)
    if (list.isEmpty()) {
      list.add(com.example.R.drawable.img_hero_duhok)
    }
    return list
  }

  fun getTitle(lang: AppLanguage): String = when (lang) {
    AppLanguage.BADINI -> titleBadini
    AppLanguage.SORANI -> titleSorani
    AppLanguage.ARABIC -> titleArabic
    AppLanguage.ENGLISH -> titleEn
  }

  fun getDescription(lang: AppLanguage): String = when (lang) {
    AppLanguage.BADINI -> descriptionBadini
    AppLanguage.SORANI -> descriptionSorani
    AppLanguage.ARABIC -> descriptionArabic
    AppLanguage.ENGLISH -> descriptionEn
  }

  fun getNeighborhood(lang: AppLanguage): String = when (lang) {
    AppLanguage.BADINI, AppLanguage.SORANI -> neighborhoodKu
    AppLanguage.ARABIC -> neighborhoodArabic
    AppLanguage.ENGLISH -> neighborhoodEn
  }
}

data class VisitBooking(
  val propertyId: String,
  val propertyTitle: String,
  val date: String,
  val timeSlot: String,
  val tourType: String,
  val visitorName: String,
  val visitorPhone: String,
  val notes: String = ""
)
