package com.example.data

import android.content.Context
import android.net.Uri
import com.example.data.model.Agent
import com.example.data.model.ListingType
import com.example.data.model.Property
import com.example.data.model.PropertyType
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

object PropertyStorage {
  private const val PROPERTIES_FILE = "properties_data.json"
  private const val PREFS_NAME = "duhok_aqar_prefs"
  private const val KEY_OFFICE_PHONE = "office_phone"
  private const val KEY_OFFICE_NAME = "office_name"

  fun saveImageUriToInternalStorage(context: Context, uri: Uri): String? {
    return try {
      val imagesDir = File(context.filesDir, "property_images").apply {
        if (!exists()) mkdirs()
      }
      val fileName = "img_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(6)}.jpg"
      val destinationFile = File(imagesDir, fileName)

      context.contentResolver.openInputStream(uri)?.use { inputStream ->
        FileOutputStream(destinationFile).use { outputStream ->
          inputStream.copyTo(outputStream)
        }
      }
      destinationFile.absolutePath
    } catch (e: Exception) {
      e.printStackTrace()
      null
    }
  }

  fun saveProperties(context: Context, properties: List<Property>) {
    try {
      val jsonArray = JSONArray()
      for (property in properties) {
        val obj = JSONObject().apply {
          put("id", property.id)
          put("titleEn", property.titleEn)
          put("titleBadini", property.titleBadini)
          put("titleSorani", property.titleSorani)
          put("titleArabic", property.titleArabic)
          put("neighborhoodEn", property.neighborhoodEn)
          put("neighborhoodKu", property.neighborhoodKu)
          put("neighborhoodArabic", property.neighborhoodArabic)
          put("city", property.city)
          put("type", property.type.name)
          put("listingType", property.listingType.name)
          put("priceUsd", property.priceUsd)
          put("areaSqm", property.areaSqm)
          put("bedrooms", property.bedrooms)
          put("bathrooms", property.bathrooms)
          put("parkingSpaces", property.parkingSpaces)
          put("yearBuilt", property.yearBuilt)
          put("isFeatured", property.isFeatured)
          put("isTapuVerified", property.isTapuVerified)
          put("descriptionEn", property.descriptionEn)
          put("descriptionBadini", property.descriptionBadini)
          put("descriptionSorani", property.descriptionSorani)
          put("descriptionArabic", property.descriptionArabic)
          put("amenities", JSONArray(property.amenities))
          put("imageResIds", JSONArray(property.imageResIds))
          put("imageUris", JSONArray(property.imageUris))
          put("latitude", property.latitude)
          put("longitude", property.longitude)
          put("isFavorite", property.isFavorite)

          val agentObj = JSONObject().apply {
            put("id", property.agent.id)
            put("name", property.agent.name)
            put("agency", property.agent.agency)
            put("phone", property.agent.phone)
            put("whatsapp", property.agent.whatsapp)
            put("rating", property.agent.rating.toDouble())
            put("reviewsCount", property.agent.reviewsCount)
            put("verified", property.agent.verified)
          }
          put("agent", agentObj)
        }
        jsonArray.put(obj)
      }

      val file = File(context.filesDir, PROPERTIES_FILE)
      file.writeText(jsonArray.toString())
    } catch (e: Exception) {
      e.printStackTrace()
    }
  }

  fun loadProperties(context: Context): List<Property>? {
    return try {
      val file = File(context.filesDir, PROPERTIES_FILE)
      if (!file.exists()) return null
      val jsonContent = file.readText()
      if (jsonContent.isBlank()) return null
      val jsonArray = JSONArray(jsonContent)
      val list = mutableListOf<Property>()

      for (i in 0 until jsonArray.length()) {
        val obj = jsonArray.getJSONObject(i)
        val amenities = mutableListOf<String>()
        val amenitiesArr = obj.optJSONArray("amenities")
        if (amenitiesArr != null) {
          for (j in 0 until amenitiesArr.length()) {
            amenities.add(amenitiesArr.getString(j))
          }
        }

        val imageResIds = mutableListOf<Int>()
        val resArr = obj.optJSONArray("imageResIds")
        if (resArr != null) {
          for (j in 0 until resArr.length()) {
            imageResIds.add(resArr.getInt(j))
          }
        }

        val imageUris = mutableListOf<String>()
        val urisArr = obj.optJSONArray("imageUris")
        if (urisArr != null) {
          for (j in 0 until urisArr.length()) {
            imageUris.add(urisArr.getString(j))
          }
        }

        val agentObj = obj.optJSONObject("agent")
        val agent = if (agentObj != null) {
          Agent(
            id = agentObj.optString("id", "agent_default"),
            name = agentObj.optString("name", "The Duhok-Aqar Agent"),
            agency = agentObj.optString("agency", "The Duhok-Aqar"),
            phone = agentObj.optString("phone", "07514036954"),
            whatsapp = agentObj.optString("whatsapp", "+9647514036954"),
            rating = agentObj.optDouble("rating", 5.0).toFloat(),
            reviewsCount = agentObj.optInt("reviewsCount", 45),
            verified = agentObj.optBoolean("verified", true)
          )
        } else {
          SampleProperties.defaultAgent
        }

        val typeStr = obj.optString("type", PropertyType.VILLA.name)
        val type = try { PropertyType.valueOf(typeStr) } catch (_: Exception) { PropertyType.VILLA }

        val listingStr = obj.optString("listingType", ListingType.FOR_SALE.name)
        val listingType = try { ListingType.valueOf(listingStr) } catch (_: Exception) { ListingType.FOR_SALE }

        val prop = Property(
          id = obj.optString("id", UUID.randomUUID().toString()),
          titleEn = obj.optString("titleEn", ""),
          titleBadini = obj.optString("titleBadini", ""),
          titleSorani = obj.optString("titleSorani", ""),
          titleArabic = obj.optString("titleArabic", ""),
          neighborhoodEn = obj.optString("neighborhoodEn", "Duhok"),
          neighborhoodKu = obj.optString("neighborhoodKu", "دهۆک"),
          neighborhoodArabic = obj.optString("neighborhoodArabic", "دهوك"),
          city = obj.optString("city", "Duhok"),
          type = type,
          listingType = listingType,
          priceUsd = obj.optDouble("priceUsd", 100000.0),
          areaSqm = obj.optInt("areaSqm", 200),
          bedrooms = obj.optInt("bedrooms", 3),
          bathrooms = obj.optInt("bathrooms", 2),
          parkingSpaces = obj.optInt("parkingSpaces", 1),
          yearBuilt = obj.optInt("yearBuilt", 2024),
          isFeatured = obj.optBoolean("isFeatured", false),
          isTapuVerified = obj.optBoolean("isTapuVerified", true),
          descriptionEn = obj.optString("descriptionEn", ""),
          descriptionBadini = obj.optString("descriptionBadini", ""),
          descriptionSorani = obj.optString("descriptionSorani", ""),
          descriptionArabic = obj.optString("descriptionArabic", ""),
          amenities = amenities,
          imageResIds = imageResIds,
          imageUris = imageUris,
          agent = agent,
          latitude = obj.optDouble("latitude", 36.8679),
          longitude = obj.optDouble("longitude", 42.9886),
          isFavorite = obj.optBoolean("isFavorite", false)
        )
        list.add(prop)
      }
      list
    } catch (e: Exception) {
      e.printStackTrace()
      null
    }
  }

  fun saveOfficeInfo(context: Context, phone: String, name: String) {
    try {
      val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
      prefs.edit()
        .putString(KEY_OFFICE_PHONE, phone)
        .putString(KEY_OFFICE_NAME, name)
        .apply()
    } catch (e: Exception) {
      e.printStackTrace()
    }
  }

  fun loadOfficePhone(context: Context): String {
    return try {
      val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
      prefs.getString(KEY_OFFICE_PHONE, "07514036954") ?: "07514036954"
    } catch (_: Exception) {
      "07514036954"
    }
  }

  private const val KEY_USER_NAME = "user_name"
  private const val KEY_USER_EMAIL = "user_email"
  private const val KEY_USER_AGE = "user_age"
  private const val KEY_USER_PASSWORD = "user_password"
  private const val KEY_USER_PHOTO = "user_photo"
  private const val KEY_USER_SIGNED_IN = "user_signed_in"
  private const val KEY_CUSTOM_NEIGHBORHOODS = "custom_neighborhoods"

  fun saveUserProfile(context: Context, profile: UserProfile) {
    try {
      val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
      prefs.edit()
        .putString(KEY_USER_NAME, profile.name)
        .putString(KEY_USER_EMAIL, profile.email)
        .putInt(KEY_USER_AGE, profile.age)
        .putString(KEY_USER_PASSWORD, profile.password)
        .putString(KEY_USER_PHOTO, profile.photoUrl)
        .putBoolean(KEY_USER_SIGNED_IN, profile.isSignedIn)
        .apply()
    } catch (e: Exception) {
      e.printStackTrace()
    }
  }

  fun loadUserProfile(context: Context): UserProfile? {
    return try {
      val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
      val isSignedIn = prefs.getBoolean(KEY_USER_SIGNED_IN, false)
      if (!isSignedIn) return null
      val name = prefs.getString(KEY_USER_NAME, "") ?: ""
      val email = prefs.getString(KEY_USER_EMAIL, "") ?: ""
      val age = prefs.getInt(KEY_USER_AGE, 25)
      val password = prefs.getString(KEY_USER_PASSWORD, "") ?: ""
      val photo = prefs.getString(KEY_USER_PHOTO, "") ?: ""
      if (email.isBlank() && name.isBlank()) null else UserProfile(
        name = name,
        email = email,
        age = if (age > 0) age else 25,
        password = password,
        photoUrl = photo,
        isSignedIn = true
      )
    } catch (_: Exception) {
      null
    }
  }

  fun clearUserProfile(context: Context) {
    try {
      val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
      prefs.edit()
        .remove(KEY_USER_NAME)
        .remove(KEY_USER_EMAIL)
        .remove(KEY_USER_AGE)
        .remove(KEY_USER_PASSWORD)
        .remove(KEY_USER_PHOTO)
        .putBoolean(KEY_USER_SIGNED_IN, false)
        .apply()
    } catch (e: Exception) {
      e.printStackTrace()
    }
  }

  fun saveCustomNeighborhoods(context: Context, neighborhoods: List<String>) {
    try {
      val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
      val jsonArray = JSONArray(neighborhoods)
      prefs.edit().putString(KEY_CUSTOM_NEIGHBORHOODS, jsonArray.toString()).apply()
    } catch (e: Exception) {
      e.printStackTrace()
    }
  }

  fun loadCustomNeighborhoods(context: Context): List<String> {
    return try {
      val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
      val jsonString = prefs.getString(KEY_CUSTOM_NEIGHBORHOODS, null) ?: return emptyList()
      val jsonArray = JSONArray(jsonString)
      val list = mutableListOf<String>()
      for (i in 0 until jsonArray.length()) {
        val item = jsonArray.optString(i)
        if (item.isNotBlank()) list.add(item)
      }
      list
    } catch (_: Exception) {
      emptyList()
    }
  }

  fun loadOfficeName(context: Context): String {
    return try {
      val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
      prefs.getString(KEY_OFFICE_NAME, "The Duhok-Aqar") ?: "The Duhok-Aqar"
    } catch (_: Exception) {
      "The Duhok-Aqar"
    }
  }

  private const val KEY_REGISTERED_USERS = "registered_users_json"
  private const val KEY_APP_ANNOUNCEMENT = "app_announcement"

  fun saveRegisteredUsers(context: Context, users: List<UserProfile>) {
    try {
      val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
      val array = JSONArray()
      for (u in users) {
        val obj = JSONObject().apply {
          put("name", u.name)
          put("email", u.email)
          put("age", u.age)
          put("password", u.password)
          put("photoUrl", u.photoUrl)
          put("isSignedIn", u.isSignedIn)
          put("registeredDate", u.registeredDate)
        }
        array.put(obj)
      }
      prefs.edit().putString(KEY_REGISTERED_USERS, array.toString()).apply()
    } catch (e: Exception) {
      e.printStackTrace()
    }
  }

  fun loadRegisteredUsers(context: Context): List<UserProfile> {
    return try {
      val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
      val json = prefs.getString(KEY_REGISTERED_USERS, null)
      if (json != null) {
        val array = JSONArray(json)
        val list = mutableListOf<UserProfile>()
        for (i in 0 until array.length()) {
          val obj = array.getJSONObject(i)
          list.add(
            UserProfile(
              name = obj.optString("name", "User"),
              email = obj.optString("email", ""),
              age = obj.optInt("age", 25),
              password = obj.optString("password", ""),
              photoUrl = obj.optString("photoUrl", ""),
              isSignedIn = obj.optBoolean("isSignedIn", true),
              registeredDate = obj.optString("registeredDate", "2026-10-30")
            )
          )
        }
        if (list.isNotEmpty()) return list
      }
      listOf(
        UserProfile("Snerway Duhoki", "snerway66@gmail.com", 28, "Duhok#2026", "", true, "2026-10-28"),
        UserProfile("Dilshad Zakholi", "dilshad.z@gmail.com", 34, "Zakho*Pass", "", true, "2026-10-25"),
        UserProfile("Rojin Semeli", "rojin.s@gmail.com", 26, "Semel@99", "", true, "2026-10-29"),
        UserProfile("Karwan Amedi", "karwan.amedi@gmail.com", 41, "Amedi#Vip", "", true, "2026-10-27")
      )
    } catch (_: Exception) {
      emptyList()
    }
  }

  fun saveAppAnnouncement(context: Context, text: String) {
    try {
      context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        .edit().putString(KEY_APP_ANNOUNCEMENT, text).apply()
    } catch (e: Exception) {
      e.printStackTrace()
    }
  }

  fun loadAppAnnouncement(context: Context): String {
    return try {
      context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        .getString(KEY_APP_ANNOUNCEMENT, "بخێرهاتن بۆ ناڤەندا فەرمی یا خانووبەرێن دهۆکێ")
        ?: "بخێرهاتن بۆ ناڤەندا فەرمی یا خانووبەرێن دهۆکێ"
    } catch (_: Exception) {
      "بخێرهاتن بۆ ناڤەندا فەرمی یا خانووبەرێن دهۆکێ"
    }
  }
}

data class UserProfile(
  val name: String,
  val email: String,
  val age: Int = 25,
  val password: String = "",
  val photoUrl: String = "",
  val isSignedIn: Boolean = true,
  val registeredDate: String = "2026-10-30"
)
