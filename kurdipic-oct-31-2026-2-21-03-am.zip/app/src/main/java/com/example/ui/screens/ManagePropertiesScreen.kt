package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.data.PropertyStorage
import com.example.data.SampleProperties
import com.example.data.model.Agent
import com.example.data.model.AppLanguage
import com.example.data.model.CurrencyMode
import com.example.data.model.ListingType
import com.example.data.model.LocaleStrings
import com.example.data.model.Property
import com.example.data.model.PropertyType
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.RentBadgeBg
import com.example.ui.theme.RentBadgeText
import com.example.ui.theme.SaleBadgeBg
import com.example.data.UserProfile
import com.example.ui.theme.SaleBadgeText
import java.util.UUID

@Composable
fun ManagePropertiesScreen(
  properties: List<Property>,
  currencyMode: CurrencyMode,
  appLanguage: AppLanguage,
  officePhone: String = "07514036954",
  officeName: String = "The Duhok-Aqar",
  officeWhatsapp: String = "07514036954",
  appAnnouncement: String = "",
  loanInterestRate: Float = 5.0f,
  registeredUsers: List<UserProfile> = emptyList(),
  isUnlocked: Boolean = true,
  customNeighborhoods: List<String> = emptyList(),
  onAddNeighborhood: (String) -> Unit = {},
  onUnlock: (String) -> Boolean = { false },
  onLock: () -> Unit = {},
  onAddProperty: (Property) -> Unit,
  onEditProperty: (Property) -> Unit = {},
  onUpdateOfficeInfo: (String, String) -> Unit = { _, _ -> },
  onUpdateMasterSettings: (name: String, phone: String, whatsapp: String, announcement: String, defaultCurrency: CurrencyMode, loanRate: Float) -> Unit = { _, _, _, _, _, _ -> },
  onDeleteUserAccount: (String) -> Unit = {},
  onDeleteProperty: (String) -> Unit,
  onClearAll: () -> Unit,
  onLoadDemoProperties: () -> Unit,
  onPropertyClick: (Property) -> Unit,
  onBack: () -> Unit = {},
  modifier: Modifier = Modifier
) {
  val strings = LocaleStrings.get(appLanguage)
  var showAddDialog by remember { mutableStateOf(false) }
  var showAddPlaceDialog by remember { mutableStateOf(false) }
  var newPlaceNameInput by remember { mutableStateOf("") }
  var propertyToEdit by remember { mutableStateOf<Property?>(null) }
  var showEditOfficeDialog by remember { mutableStateOf(false) }
  var propertyToDeleteId by remember { mutableStateOf<String?>(null) }
  var userToDeleteEmail by remember { mutableStateOf<String?>(null) }

  // 3 Manager Tabs: 0 = Properties & Places, 1 = User Accounts, 2 = Master App Control
  var selectedAdminTab by remember { mutableIntStateOf(0) }

  // Master settings local state
  var masterName by remember(officeName) { mutableStateOf(officeName) }
  var masterPhone by remember(officePhone) { mutableStateOf(officePhone) }
  var masterWhatsapp by remember(officeWhatsapp) { mutableStateOf(officeWhatsapp) }
  var masterAnnouncement by remember(appAnnouncement) { mutableStateOf(appAnnouncement) }
  var masterCurrency by remember(currencyMode) { mutableStateOf(currencyMode) }
  var masterLoanRateText by remember(loanInterestRate) { mutableStateOf(loanInterestRate.toString()) }
  var masterSavedSuccess by remember { mutableStateOf(false) }

  // User accounts password visibility map
  var visiblePasswordMap by remember { mutableStateOf<Map<String, Boolean>>(emptyMap()) }

  BackHandler {
    onBack()
  }

  // Strict passcode lock screen with NO bypass - Only manager can unlock
  if (!isUnlocked) {
    AdminPasscodeLockScreen(
      appLanguage = appLanguage,
      onUnlock = onUnlock,
      onBack = onBack,
      modifier = modifier
    )
    return
  }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .testTag("manage_properties_screen"),
    contentPadding = PaddingValues(bottom = 96.dp)
  ) {
    // Header Section
    item {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(start = 20.dp, end = 20.dp, top = 20.dp, bottom = 8.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            IconButton(
              onClick = onBack,
              modifier = Modifier.testTag("manage_back_button")
            ) {
              Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Back",
                tint = MaterialTheme.colorScheme.onSurface
              )
            }
            Surface(
              shape = CircleShape,
              color = EmeraldPrimary.copy(alpha = 0.12f),
              modifier = Modifier.size(40.dp)
            ) {
              Box(contentAlignment = Alignment.Center) {
                Icon(
                  imageVector = Icons.Default.AdminPanelSettings,
                  contentDescription = null,
                  tint = EmeraldPrimary,
                  modifier = Modifier.size(22.dp)
                )
              }
            }
            Column {
              Text(
                text = strings.manageTitle,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
              )
              Text(
                text = strings.manageSubtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }

          // Lock button
          Button(
            onClick = onLock,
            colors = ButtonDefaults.buttonColors(
              containerColor = MaterialTheme.colorScheme.surfaceVariant,
              contentColor = MaterialTheme.colorScheme.onSurfaceVariant
            ),
            shape = RoundedCornerShape(12.dp),
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
            modifier = Modifier.testTag("manage_lock_button")
          ) {
            Icon(
              imageVector = Icons.Default.Lock,
              contentDescription = strings.lockManage,
              modifier = Modifier.size(15.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = strings.lockManage,
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Bold
            )
          }
        }
      }
    }

    // 3 Manager Tabs Bar
    item {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        // Tab 0: Properties & Places
        val isTab0 = selectedAdminTab == 0
        Surface(
          shape = RoundedCornerShape(12.dp),
          color = if (isTab0) EmeraldPrimary else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
          border = if (isTab0) null else androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
          modifier = Modifier
            .weight(1f)
            .clickable { selectedAdminTab = 0 }
            .testTag("admin_tab_properties")
        ) {
          Row(
            modifier = Modifier.padding(vertical = 10.dp, horizontal = 6.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(
              imageVector = Icons.Default.Home,
              contentDescription = null,
              tint = if (isTab0) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.size(15.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = strings.tabPropertiesAndPlaces,
              fontSize = 11.sp,
              fontWeight = if (isTab0) FontWeight.Bold else FontWeight.Medium,
              color = if (isTab0) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
              textAlign = TextAlign.Center,
              maxLines = 1
            )
          }
        }

        // Tab 1: User Accounts
        val isTab1 = selectedAdminTab == 1
        Surface(
          shape = RoundedCornerShape(12.dp),
          color = if (isTab1) EmeraldPrimary else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
          border = if (isTab1) null else androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
          modifier = Modifier
            .weight(1f)
            .clickable { selectedAdminTab = 1 }
            .testTag("admin_tab_users")
        ) {
          Row(
            modifier = Modifier.padding(vertical = 10.dp, horizontal = 6.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(
              imageVector = Icons.Default.AdminPanelSettings,
              contentDescription = null,
              tint = if (isTab1) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.size(15.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = "${strings.tabUserAccounts} (${registeredUsers.size})",
              fontSize = 11.sp,
              fontWeight = if (isTab1) FontWeight.Bold else FontWeight.Medium,
              color = if (isTab1) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
              textAlign = TextAlign.Center,
              maxLines = 1
            )
          }
        }

        // Tab 2: Master App Control
        val isTab2 = selectedAdminTab == 2
        Surface(
          shape = RoundedCornerShape(12.dp),
          color = if (isTab2) EmeraldPrimary else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
          border = if (isTab2) null else androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
          modifier = Modifier
            .weight(1f)
            .clickable { selectedAdminTab = 2 }
            .testTag("admin_tab_master")
        ) {
          Row(
            modifier = Modifier.padding(vertical = 10.dp, horizontal = 6.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(
              imageVector = Icons.Default.Edit,
              contentDescription = null,
              tint = if (isTab2) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.size(15.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = strings.tabMasterAppControl,
              fontSize = 11.sp,
              fontWeight = if (isTab2) FontWeight.Bold else FontWeight.Medium,
              color = if (isTab2) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
              textAlign = TextAlign.Center,
              maxLines = 1
            )
          }
        }
      }
    }

    // ----------------------------------------------------
    // TAB 0: Properties and Places
    // ----------------------------------------------------
    if (selectedAdminTab == 0) {
      item {
        Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp)) {
          // Agency & Contact Phone Card
          Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = EmeraldPrimary.copy(alpha = 0.08f)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
              ) {
                Icon(
                  imageVector = Icons.Default.Phone,
                  contentDescription = null,
                  tint = EmeraldPrimary,
                  modifier = Modifier.size(20.dp)
                )
                Column {
                  Text(
                    text = officeName.ifBlank { "The Duhok-Aqar" },
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = EmeraldPrimary
                  )
                  Text(
                    text = "$officePhone (+964 ${officePhone.removePrefix("+964").removePrefix("0")})",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.onSurface
                  )
                }
              }
              IconButton(
                onClick = { showEditOfficeDialog = true },
                modifier = Modifier.testTag("admin_edit_office_button")
              ) {
                Icon(
                  imageVector = Icons.Default.Edit,
                  contentDescription = strings.editAgencyInfo,
                  tint = EmeraldPrimary,
                  modifier = Modifier.size(20.dp)
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(12.dp))

          // Protected Admin Notice
          Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = GoldPrimary.copy(alpha = 0.12f)),
            modifier = Modifier
              .fillMaxWidth()
              .testTag("admin_protected_notice")
          ) {
            Row(
              modifier = Modifier.padding(12.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
              Icon(
                imageVector = Icons.Default.Lock,
                contentDescription = null,
                tint = GoldPrimary,
                modifier = Modifier.size(20.dp)
              )
              Text(
                text = strings.onlyAdminCanAddNote,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface,
                lineHeight = 17.sp
              )
            }
          }

          Spacer(modifier = Modifier.height(12.dp))

          // Primary "Add Property & Photos" Action Button
          Button(
            onClick = { showAddDialog = true },
            modifier = Modifier
              .fillMaxWidth()
              .height(52.dp)
              .testTag("admin_add_property_btn"),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
          ) {
            Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, tint = Color.White)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = strings.addNewProperty,
              fontWeight = FontWeight.Bold,
              fontSize = 15.sp,
              color = Color.White
            )
          }

          Spacer(modifier = Modifier.height(8.dp))

          // Secondary "Add New Place in Duhok" Button
          OutlinedButton(
            onClick = { showAddPlaceDialog = true },
            modifier = Modifier
              .fillMaxWidth()
              .height(48.dp)
              .testTag("admin_add_place_btn"),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = EmeraldPrimary)
          ) {
            Icon(Icons.Default.LocationOn, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = strings.addNewPlaceBtn,
              fontWeight = FontWeight.Bold,
              fontSize = 14.sp,
              color = EmeraldPrimary
            )
          }

          if (customNeighborhoods.isNotEmpty()) {
            Spacer(modifier = Modifier.height(10.dp))
            Text(
              text = "${strings.quickPlaceSuggestions} (${customNeighborhoods.size})",
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(vertical = 4.dp),
              horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              customNeighborhoods.forEach { place ->
                Surface(
                  shape = RoundedCornerShape(10.dp),
                  color = EmeraldPrimary.copy(alpha = 0.12f),
                  border = androidx.compose.foundation.BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.3f))
                ) {
                  Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                  ) {
                    Icon(Icons.Default.LocationOn, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(13.dp))
                    Text(text = place, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = EmeraldPrimary)
                  }
                }
              }
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          // Demo Actions (Load / Clear)
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            OutlinedButton(
              onClick = onLoadDemoProperties,
              modifier = Modifier.weight(1f),
              shape = RoundedCornerShape(12.dp)
            ) {
              Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text(strings.loadDemoData, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
            }
            if (properties.isNotEmpty()) {
              OutlinedButton(
                onClick = onClearAll,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
              ) {
                Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(strings.clearAll, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
              }
            }
          }
        }
      }

      // Properties List
      if (properties.isEmpty()) {
        item {
          Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
            modifier = Modifier
              .fillMaxWidth()
              .padding(20.dp)
          ) {
            Column(
              modifier = Modifier.padding(28.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              Icon(
                imageVector = Icons.Default.AddPhotoAlternate,
                contentDescription = null,
                tint = EmeraldPrimary.copy(alpha = 0.5f),
                modifier = Modifier.size(48.dp)
              )
              Spacer(modifier = Modifier.height(12.dp))
              Text(
                text = strings.noPropertiesAdmin,
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
              Spacer(modifier = Modifier.height(16.dp))
              Button(
                onClick = { showAddDialog = true },
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
              ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(strings.addNewProperty, fontWeight = FontWeight.Bold)
              }
            }
          }
        }
      } else {
        item {
          Text(
            text = "${strings.latestListingsTitle} (${properties.size})",
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp)
          )
        }

        items(properties, key = { it.id }) { property ->
          AdminPropertyCard(
            property = property,
            currencyMode = currencyMode,
            appLanguage = appLanguage,
            onCardClick = { onPropertyClick(property) },
            onEditClick = { propertyToEdit = property },
            onDeleteClick = { propertyToDeleteId = property.id }
          )
        }
      }
    }

    // ----------------------------------------------------
    // TAB 1: Registered User Accounts
    // ----------------------------------------------------
    if (selectedAdminTab == 1) {
      item {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 8.dp)
        ) {
          Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = EmeraldPrimary.copy(alpha = 0.08f)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
              Surface(
                shape = CircleShape,
                color = EmeraldPrimary,
                modifier = Modifier.size(44.dp)
              ) {
                Box(contentAlignment = Alignment.Center) {
                  Icon(
                    imageVector = Icons.Default.AdminPanelSettings,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(24.dp)
                  )
                }
              }
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = strings.registeredUsersTitle,
                  style = MaterialTheme.typography.titleMedium,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                  text = strings.registeredUsersSubtitle,
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
              Surface(
                shape = RoundedCornerShape(10.dp),
                color = EmeraldPrimary,
                modifier = Modifier.padding(4.dp)
              ) {
                Text(
                  text = "${registeredUsers.size}",
                  color = Color.White,
                  fontSize = 14.sp,
                  fontWeight = FontWeight.Bold,
                  modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                )
              }
            }
          }
        }
      }

      if (registeredUsers.isEmpty()) {
        item {
          Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
            modifier = Modifier
              .fillMaxWidth()
              .padding(20.dp)
          ) {
            Column(
              modifier = Modifier.padding(32.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              Icon(
                imageVector = Icons.Default.AdminPanelSettings,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                modifier = Modifier.size(48.dp)
              )
              Spacer(modifier = Modifier.height(10.dp))
              Text(
                text = "چ ئەکاونت هێشتا نەهاتینە تۆمارکرن",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
              )
            }
          }
        }
      } else {
        items(registeredUsers, key = { it.email }) { user ->
          val isPasswordVisible = visiblePasswordMap[user.email] ?: false
          Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 20.dp, vertical = 6.dp)
              .testTag("admin_user_card_${user.email}")
          ) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
            ) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                  Surface(
                    shape = CircleShape,
                    color = EmeraldPrimary.copy(alpha = 0.15f),
                    modifier = Modifier.size(42.dp)
                  ) {
                    Box(contentAlignment = Alignment.Center) {
                      Text(
                        text = user.name.take(1).uppercase(),
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = EmeraldPrimary
                      )
                    }
                  }
                  Column {
                    Text(
                      text = user.name,
                      style = MaterialTheme.typography.titleMedium,
                      fontWeight = FontWeight.Bold,
                      color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                      text = user.email,
                      style = MaterialTheme.typography.bodySmall,
                      color = EmeraldPrimary,
                      fontWeight = FontWeight.Medium
                    )
                  }
                }

                // Delete account button
                IconButton(
                  onClick = { userToDeleteEmail = user.email },
                  modifier = Modifier.testTag("delete_user_${user.email}")
                ) {
                  Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Delete Account",
                    tint = MaterialTheme.colorScheme.error.copy(alpha = 0.8f),
                    modifier = Modifier.size(20.dp)
                  )
                }
              }

              Spacer(modifier = Modifier.height(10.dp))

              // User Info details row: Age, Status, Registered Date
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                // Age badge
                Surface(
                  shape = RoundedCornerShape(8.dp),
                  color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                  Text(
                    text = "${user.age} ${strings.ageYearsSuffix}",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                  )
                }

                // Member Status
                Surface(
                  shape = RoundedCornerShape(8.dp),
                  color = EmeraldPrimary.copy(alpha = 0.12f)
                ) {
                  Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                  ) {
                    Box(
                      modifier = Modifier
                        .size(6.dp)
                        .background(EmeraldPrimary, CircleShape)
                    )
                    Text(
                      text = strings.memberStatusActive,
                      fontSize = 11.sp,
                      fontWeight = FontWeight.Bold,
                      color = EmeraldPrimary
                    )
                  }
                }

                // Date
                Text(
                  text = user.registeredDate,
                  fontSize = 11.sp,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }

              // Password Viewer row for Admin
              Spacer(modifier = Modifier.height(10.dp))
              Surface(
                shape = RoundedCornerShape(10.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                modifier = Modifier.fillMaxWidth()
              ) {
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                  ) {
                    Icon(
                      imageVector = Icons.Default.Lock,
                      contentDescription = null,
                      tint = MaterialTheme.colorScheme.onSurfaceVariant,
                      modifier = Modifier.size(14.dp)
                    )
                    Text(
                      text = if (isPasswordVisible) {
                        user.password.ifBlank { "•••••••• (Google OAuth)" }
                      } else {
                        "••••••••"
                      },
                      fontSize = 12.sp,
                      fontWeight = FontWeight.Medium,
                      color = MaterialTheme.colorScheme.onSurface
                    )
                  }
                  IconButton(
                    onClick = {
                      val current = visiblePasswordMap[user.email] ?: false
                      visiblePasswordMap = visiblePasswordMap + (user.email to !current)
                    },
                    modifier = Modifier.size(28.dp)
                  ) {
                    Icon(
                      imageVector = if (isPasswordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                      contentDescription = if (isPasswordVisible) "Hide password" else "Show password",
                      tint = EmeraldPrimary,
                      modifier = Modifier.size(16.dp)
                    )
                  }
                }
              }
            }
          }
        }
      }
    }

    // ----------------------------------------------------
    // TAB 2: Master App Controls (دەستکاری د بەرنامەی دا)
    // ----------------------------------------------------
    if (selectedAdminTab == 2) {
      item {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 8.dp),
          verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
          // Master Header Card
          Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = GoldPrimary.copy(alpha = 0.12f)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
              Surface(
                shape = CircleShape,
                color = GoldPrimary,
                modifier = Modifier.size(44.dp)
              ) {
                Box(contentAlignment = Alignment.Center) {
                  Icon(
                    imageVector = Icons.Default.Edit,
                    contentDescription = null,
                    tint = EmeraldDark,
                    modifier = Modifier.size(24.dp)
                  )
                }
              }
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = strings.masterSettingsTitle,
                  style = MaterialTheme.typography.titleMedium,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                  text = strings.masterSettingsSubtitle,
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }
          }

          if (masterSavedSuccess) {
            Surface(
              shape = RoundedCornerShape(12.dp),
              color = EmeraldPrimary.copy(alpha = 0.15f),
              border = androidx.compose.foundation.BorderStroke(1.dp, EmeraldPrimary),
              modifier = Modifier.fillMaxWidth()
            ) {
              Text(
                text = "✓ دەستکاریێن بەرنامەی ب سەرکەفتیانە هاتنە پاراستن!",
                color = EmeraldPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(12.dp)
              )
            }
          }

          // 1. Office / App Name
          OutlinedTextField(
            value = masterName,
            onValueChange = { masterName = it; masterSavedSuccess = false },
            label = { Text(strings.agencyNameInput) },
            singleLine = true,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("input_master_office_name"),
            shape = RoundedCornerShape(12.dp)
          )

          // 2. Primary Contact Phone
          OutlinedTextField(
            value = masterPhone,
            onValueChange = { masterPhone = it; masterSavedSuccess = false },
            label = { Text(strings.agencyPhoneInput) },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            modifier = Modifier
              .fillMaxWidth()
              .testTag("input_master_phone"),
            shape = RoundedCornerShape(12.dp)
          )

          // 3. Official WhatsApp Number
          OutlinedTextField(
            value = masterWhatsapp,
            onValueChange = { masterWhatsapp = it; masterSavedSuccess = false },
            label = { Text(strings.whatsappInput) },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            modifier = Modifier
              .fillMaxWidth()
              .testTag("input_master_whatsapp"),
            shape = RoundedCornerShape(12.dp)
          )

          // 4. Welcome Announcement / Banner
          OutlinedTextField(
            value = masterAnnouncement,
            onValueChange = { masterAnnouncement = it; masterSavedSuccess = false },
            label = { Text(strings.appAnnouncementInput) },
            minLines = 2,
            maxLines = 4,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("input_master_announcement"),
            shape = RoundedCornerShape(12.dp)
          )

          // 5. Default Currency Selector
          Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
              text = strings.defaultCurrencyInput,
              style = MaterialTheme.typography.labelMedium,
              fontWeight = FontWeight.SemiBold,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
              val isUsd = masterCurrency == CurrencyMode.USD
              Surface(
                shape = RoundedCornerShape(12.dp),
                color = if (isUsd) EmeraldPrimary else MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier
                  .weight(1f)
                  .clickable { masterCurrency = CurrencyMode.USD; masterSavedSuccess = false }
                  .testTag("currency_select_usd")
              ) {
                Text(
                  text = "$ USD (دۆلار)",
                  fontWeight = FontWeight.Bold,
                  fontSize = 13.sp,
                  color = if (isUsd) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                  textAlign = TextAlign.Center,
                  modifier = Modifier.padding(vertical = 12.dp)
                )
              }
              val isIqd = masterCurrency == CurrencyMode.IQD
              Surface(
                shape = RoundedCornerShape(12.dp),
                color = if (isIqd) EmeraldPrimary else MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier
                  .weight(1f)
                  .clickable { masterCurrency = CurrencyMode.IQD; masterSavedSuccess = false }
                  .testTag("currency_select_iqd")
              ) {
                Text(
                  text = "د.ع IQD (دینار)",
                  fontWeight = FontWeight.Bold,
                  fontSize = 13.sp,
                  color = if (isIqd) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                  textAlign = TextAlign.Center,
                  modifier = Modifier.padding(vertical = 12.dp)
                )
              }
            }
          }

          // 6. Annual Loan / Mortgage Interest Rate %
          OutlinedTextField(
            value = masterLoanRateText,
            onValueChange = { masterLoanRateText = it; masterSavedSuccess = false },
            label = { Text(strings.loanInterestRateInput) },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            modifier = Modifier
              .fillMaxWidth()
              .testTag("input_master_loan_rate"),
            shape = RoundedCornerShape(12.dp)
          )

          Spacer(modifier = Modifier.height(4.dp))

          // Save Master Settings Button
          Button(
            onClick = {
              val rate = masterLoanRateText.toFloatOrNull() ?: 5.0f
              onUpdateMasterSettings(
                masterName.trim(),
                masterPhone.trim(),
                masterWhatsapp.trim(),
                masterAnnouncement.trim(),
                masterCurrency,
                rate
              )
              masterSavedSuccess = true
            },
            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
              .fillMaxWidth()
              .height(52.dp)
              .testTag("btn_save_master_settings")
          ) {
            Icon(Icons.Default.Edit, contentDescription = null, tint = Color.White)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = strings.saveMasterSettingsBtn,
              fontWeight = FontWeight.Bold,
              fontSize = 15.sp,
              color = Color.White
            )
          }
        }
      }
    }
  }

  // Edit Existing Property Bottom Sheet Dialog
  if (propertyToEdit != null) {
    EditPropertySheet(
      property = propertyToEdit!!,
      appLanguage = appLanguage,
      onDismiss = { propertyToEdit = null },
      onSave = { updatedProp ->
        propertyToEdit = null
        onEditProperty(updatedProp)
      }
    )
  }

  // Edit App / Office Contact Info Dialog
  if (showEditOfficeDialog) {
    EditOfficeInfoDialog(
      currentPhone = officePhone,
      currentName = officeName,
      appLanguage = appLanguage,
      onDismiss = { showEditOfficeDialog = false },
      onSave = { newPhone, newName ->
        onUpdateOfficeInfo(newPhone, newName)
      }
    )
  }

  // Add Property Bottom Sheet Dialog
  if (showAddDialog) {
    AddPropertySheet(
      appLanguage = appLanguage,
      onDismiss = { showAddDialog = false },
      onSave = { newProp ->
        showAddDialog = false
        onAddProperty(newProp)
      }
    )
  }

  // Add New Place in Duhok Dialog (Exclusively in Manage)
  if (showAddPlaceDialog) {
    AlertDialog(
      onDismissRequest = { showAddPlaceDialog = false },
      title = {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Icon(Icons.Default.LocationOn, contentDescription = null, tint = EmeraldPrimary)
          Text(
            text = strings.newPlaceDialogTitle,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
          )
        }
      },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Text(
            text = strings.enterPlaceNamePrompt,
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          OutlinedTextField(
            value = newPlaceNameInput,
            onValueChange = { newPlaceNameInput = it },
            label = { Text(strings.placeNameInput, fontSize = 12.sp) },
            singleLine = true,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("input_new_place_name"),
            shape = RoundedCornerShape(12.dp)
          )

          // Quick suggestions for Duhok
          Text(
            text = strings.quickPlaceSuggestions,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = EmeraldPrimary
          )
          Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            listOf("سێمێل (Semel)", "زاویتە (Zawita)", "ماسیک ٢ (Masik 2)", "شاخی دهۆک", "سندی ستی", "دهۆک مۆڵ").forEach { suggestion ->
              Surface(
                shape = RoundedCornerShape(8.dp),
                color = EmeraldPrimary.copy(alpha = 0.1f),
                modifier = Modifier.clickable {
                  newPlaceNameInput = suggestion.split(" ").first()
                }
              ) {
                Text(
                  text = suggestion,
                  fontSize = 11.sp,
                  fontWeight = FontWeight.SemiBold,
                  color = EmeraldPrimary,
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                )
              }
            }
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (newPlaceNameInput.isNotBlank()) {
              onAddNeighborhood(newPlaceNameInput.trim())
              newPlaceNameInput = ""
              showAddPlaceDialog = false
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
        ) {
          Text(strings.saveSettingsBtn, fontWeight = FontWeight.Bold, color = Color.White)
        }
      },
      dismissButton = {
        OutlinedButton(onClick = { showAddPlaceDialog = false }) {
          Text("پاشگەزبوون (Cancel)")
        }
      }
    )
  }

  // Delete Confirmation Alert Dialog
  if (propertyToDeleteId != null) {
    AlertDialog(
      onDismissRequest = { propertyToDeleteId = null },
      title = { Text(strings.deleteProperty, fontWeight = FontWeight.Bold) },
      text = { Text("ئەرێ تو پشتڕاستی تە دڤێت ڤی جهی ژێببەی؟ (Are you sure you want to delete this place?)") },
      confirmButton = {
        Button(
          onClick = {
            propertyToDeleteId?.let { onDeleteProperty(it) }
            propertyToDeleteId = null
          },
          colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
        ) {
          Text("بەلێ، ژێببە (Delete)", color = Color.White)
        }
      },
      dismissButton = {
        TextButton(onClick = { propertyToDeleteId = null }) {
          Text("پاشگەزبوون (Cancel)")
        }
      }
    )
  }

  // Delete User Account Alert Dialog
  if (userToDeleteEmail != null) {
    AlertDialog(
      onDismissRequest = { userToDeleteEmail = null },
      title = { Text("سڕینەوەی ئەکاونت", fontWeight = FontWeight.Bold) },
      text = { Text("ئەرێ تە دڤێت ئەکاونتێ $userToDeleteEmail ژێببەی؟ (Delete this registered account?)") },
      confirmButton = {
        Button(
          onClick = {
            userToDeleteEmail?.let { onDeleteUserAccount(it) }
            userToDeleteEmail = null
          },
          colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
        ) {
          Text("بەلێ، ژێببە (Delete)", color = Color.White)
        }
      },
      dismissButton = {
        TextButton(onClick = { userToDeleteEmail = null }) {
          Text("پاشگەزبوون (Cancel)")
        }
      }
    )
  }
}

@Composable
private fun AdminPropertyCard(
  property: Property,
  currencyMode: CurrencyMode,
  appLanguage: AppLanguage,
  onCardClick: () -> Unit,
  onEditClick: () -> Unit,
  onDeleteClick: () -> Unit
) {
  val strings = LocaleStrings.get(appLanguage)
  val isRent = property.listingType == ListingType.FOR_RENT

  Card(
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 20.dp, vertical = 8.dp)
      .clickable(onClick = onCardClick)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(12.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      // Thumbnail supports both custom files/URIs and resource IDs
      val imageSource = property.getImageSources().firstOrNull() ?: R.drawable.img_hero_duhok
      AsyncImage(
        model = imageSource,
        contentDescription = null,
        modifier = Modifier
          .size(80.dp)
          .clip(RoundedCornerShape(12.dp)),
        contentScale = ContentScale.Crop,
        placeholder = painterResource(id = R.drawable.img_hero_duhok),
        error = painterResource(id = R.drawable.img_hero_duhok)
      )

      Spacer(modifier = Modifier.width(12.dp))

      Column(modifier = Modifier.weight(1f)) {
        Row(
          horizontalArrangement = Arrangement.spacedBy(6.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Surface(
            shape = RoundedCornerShape(6.dp),
            color = if (isRent) RentBadgeBg else SaleBadgeBg
          ) {
            Text(
              text = if (isRent) strings.forRent else strings.forSale,
              color = if (isRent) RentBadgeText else SaleBadgeText,
              fontSize = 10.sp,
              fontWeight = FontWeight.Bold,
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
          }

          Text(
            text = property.getNeighborhood(appLanguage),
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            color = EmeraldPrimary
          )
        }

        Spacer(modifier = Modifier.height(4.dp))

        Text(
          text = property.getTitle(appLanguage),
          fontWeight = FontWeight.Bold,
          fontSize = 14.sp,
          maxLines = 1
        )

        Spacer(modifier = Modifier.height(2.dp))

        Text(
          text = currencyMode.formatPrice(property.priceUsd, isRent, appLanguage),
          color = EmeraldPrimary,
          fontWeight = FontWeight.ExtraBold,
          fontSize = 14.sp
        )
      }

      Row(verticalAlignment = Alignment.CenterVertically) {
        // Edit Action Button
        IconButton(
          onClick = onEditClick,
          modifier = Modifier.testTag("admin_edit_btn_${property.id}")
        ) {
          Icon(
            imageVector = Icons.Default.Edit,
            contentDescription = strings.editProperty,
            tint = EmeraldPrimary
          )
        }

        // Delete Action Button
        IconButton(
          onClick = onDeleteClick,
          modifier = Modifier.testTag("admin_delete_btn_${property.id}")
        ) {
          Icon(
            imageVector = Icons.Default.Delete,
            contentDescription = "Delete",
            tint = MaterialTheme.colorScheme.error.copy(alpha = 0.8f)
          )
        }
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddPropertySheet(
  appLanguage: AppLanguage,
  onDismiss: () -> Unit,
  onSave: (Property) -> Unit
) {
  val context = LocalContext.current
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
  val strings = LocaleStrings.get(appLanguage)

  var title by remember { mutableStateOf("") }
  var placeName by remember { mutableStateOf("") }
  var selectedType by remember { mutableStateOf(PropertyType.VILLA) }
  var selectedListingType by remember { mutableStateOf(ListingType.FOR_SALE) }
  var priceUsdText by remember { mutableStateOf("250000") }
  var areaSqmText by remember { mutableStateOf("300") }
  var bedrooms by remember { mutableIntStateOf(4) }
  var bathrooms by remember { mutableIntStateOf(3) }
  var parkingSpaces by remember { mutableIntStateOf(2) }
  var isTapuVerified by remember { mutableStateOf(true) }
  var description by remember { mutableStateOf("") }
  var contactPhone by remember { mutableStateOf("07514036954") }

  // Custom user photos picked from gallery
  var customImageUris by remember { mutableStateOf<List<String>>(emptyList()) }
  var selectedPresetRes by remember { mutableIntStateOf(R.drawable.img_hero_duhok) }

  var errorMessage by remember { mutableStateOf<String?>(null) }

  // Photo Picker Launcher
  val photoPickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.PickMultipleVisualMedia(maxItems = 10)
  ) { uris: List<Uri> ->
    if (uris.isNotEmpty()) {
      val savedPaths = uris.mapNotNull { uri ->
        PropertyStorage.saveImageUriToInternalStorage(context, uri)
      }
      customImageUris = (customImageUris + savedPaths).distinct()
    }
  }

  val popularDuhokPlaces = listOf(
    "مالتا (Malta)",
    "ماسیک (Masik)",
    "ئەڤرۆ ستی (Avro City)",
    "گرێ باسی (Gre Basi)",
    "کڕۆ (KRO)",
    "ئازادی (Azadi)",
    "شۆڕش (Shorsh)",
    "نزارکێ (Nizarke)",
    "زاویته (Zawita)",
    "سێمێل (Semel)",
    "شاخکێ (Shakhke)",
    "بەرۆشکێ (Baroshke)",
    "گەلیێ دهۆکێ (Galiye Duhok)"
  )

  val presetOptions = listOf(
    Pair("Hillside Villa", R.drawable.img_hero_duhok),
    Pair("Stone Villa", R.drawable.img_villa_malta),
    Pair("Luxury Penthouse", R.drawable.img_apt_duhok)
  )

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = MaterialTheme.colorScheme.surface,
    shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 24.dp)
        .padding(bottom = 36.dp)
        .verticalScroll(rememberScrollState())
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = strings.addNewProperty,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = "وێنە و ناڤێ جهی و هویرکاریان ل خوارێ پربکە",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
        IconButton(onClick = onDismiss) {
          Icon(Icons.Default.Close, contentDescription = "Close")
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      // 1. PLACE NAME INPUT ("ناڤێن جهان بکەمە تێدا")
      Text(
        text = strings.placeNameInput,
        fontWeight = FontWeight.Bold,
        fontSize = 14.sp,
        color = EmeraldDark
      )
      Spacer(modifier = Modifier.height(4.dp))
      OutlinedTextField(
        value = placeName,
        onValueChange = { placeName = it },
        label = { Text(strings.placeNameInput) },
        placeholder = { Text(strings.placeNameHelper, fontSize = 12.sp) },
        leadingIcon = {
          Icon(Icons.Default.LocationOn, contentDescription = null, tint = EmeraldPrimary)
        },
        trailingIcon = {
          if (placeName.isNotEmpty()) {
            IconButton(onClick = { placeName = "" }) {
              Icon(Icons.Default.Close, contentDescription = "Clear", modifier = Modifier.size(18.dp))
            }
          }
        },
        modifier = Modifier
          .fillMaxWidth()
          .testTag("admin_input_place_name"),
        singleLine = true,
        shape = RoundedCornerShape(14.dp)
      )

      Spacer(modifier = Modifier.height(6.dp))
      Text(
        text = strings.quickPlaceSuggestions,
        fontSize = 11.sp,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
      Spacer(modifier = Modifier.height(4.dp))
      // Horizontal scrollable suggestions chips
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        popularDuhokPlaces.forEach { placeStr ->
          val cleanPlace = placeStr.substringBefore(" (").trim()
          val isSelected = placeName.trim().equals(cleanPlace, ignoreCase = true)
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = if (isSelected) GoldPrimary else MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier
              .clip(RoundedCornerShape(10.dp))
              .clickable { placeName = cleanPlace }
          ) {
            Text(
              text = placeStr,
              color = if (isSelected) EmeraldDark else MaterialTheme.colorScheme.onSurface,
              fontSize = 11.sp,
              fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(18.dp))

      // 2. PHOTO PICKER ("ئەز خو وێنا بکەمە تێدا")
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = strings.addPhotosFromGallery,
          fontWeight = FontWeight.Bold,
          fontSize = 14.sp,
          color = EmeraldDark
        )
        if (customImageUris.isNotEmpty()) {
          Text(
            text = "${customImageUris.size} ${strings.selectedPhotosCount}",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = EmeraldPrimary
          )
        }
      }
      Spacer(modifier = Modifier.height(8.dp))

      // Button to pick images from phone gallery
      Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = EmeraldPrimary.copy(alpha = 0.08f)),
        modifier = Modifier
          .fillMaxWidth()
          .clickable {
            photoPickerLauncher.launch(
              PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
            )
          }
          .testTag("admin_pick_photos_button")
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(14.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.Center
        ) {
          Icon(
            imageVector = Icons.Default.AddPhotoAlternate,
            contentDescription = null,
            tint = EmeraldPrimary,
            modifier = Modifier.size(24.dp)
          )
          Spacer(modifier = Modifier.width(10.dp))
          Text(
            text = strings.addPhotosFromGallery,
            fontWeight = FontWeight.Bold,
            color = EmeraldPrimary,
            fontSize = 14.sp
          )
        }
      }

      // Display picked photos in thumbnail strip with delete option
      if (customImageUris.isNotEmpty()) {
        Spacer(modifier = Modifier.height(10.dp))
        Text(
          text = strings.selectedPhotosCount,
          fontSize = 11.sp,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(6.dp))
        LazyRow(
          horizontalArrangement = Arrangement.spacedBy(10.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          items(customImageUris) { path ->
            Box(
              modifier = Modifier
                .size(86.dp)
                .clip(RoundedCornerShape(12.dp))
            ) {
              AsyncImage(
                model = path,
                contentDescription = "Selected Photo",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
              )
              // Delete badge on thumbnail
              Surface(
                shape = CircleShape,
                color = Color.Black.copy(alpha = 0.65f),
                modifier = Modifier
                  .align(Alignment.TopEnd)
                  .padding(4.dp)
                  .size(22.dp)
                  .clickable {
                    customImageUris = customImageUris.filterNot { it == path }
                  }
              ) {
                Box(contentAlignment = Alignment.Center) {
                  Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Remove photo",
                    tint = Color.White,
                    modifier = Modifier.size(14.dp)
                  )
                }
              }
            }
          }
        }
      } else {
        // Option to choose from high quality curated preset drawables
        Spacer(modifier = Modifier.height(10.dp))
        Text(
          text = strings.choosePresetOrGallery,
          fontSize = 11.sp,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(6.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          presetOptions.forEach { (label, res) ->
            val isSelected = selectedPresetRes == res
            Column(
              horizontalAlignment = Alignment.CenterHorizontally,
              modifier = Modifier
                .weight(1f)
                .clip(RoundedCornerShape(12.dp))
                .clickable { selectedPresetRes = res }
                .border(
                  width = if (isSelected) 2.5.dp else 0.5.dp,
                  color = if (isSelected) EmeraldPrimary else MaterialTheme.colorScheme.outline,
                  shape = RoundedCornerShape(12.dp)
                )
            ) {
              Image(
                painter = painterResource(id = res),
                contentDescription = label,
                modifier = Modifier
                  .height(64.dp)
                  .fillMaxWidth()
                  .clip(RoundedCornerShape(topStart = 11.dp, topEnd = 11.dp)),
                contentScale = ContentScale.Crop
              )
              Text(
                text = label,
                fontSize = 10.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                color = if (isSelected) EmeraldPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(vertical = 4.dp)
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(18.dp))

      // 3. PROPERTY TITLE
      Text("ناڤێ خانووبەرەی • Title", fontWeight = FontWeight.Bold, fontSize = 13.sp)
      Spacer(modifier = Modifier.height(4.dp))
      OutlinedTextField(
        value = title,
        onValueChange = { title = it },
        label = { Text(strings.propertyTitleInput) },
        modifier = Modifier
          .fillMaxWidth()
          .testTag("admin_input_title"),
        singleLine = true,
        shape = RoundedCornerShape(12.dp)
      )

      Spacer(modifier = Modifier.height(14.dp))

      // 4. Listing Type (For Sale / For Rent)
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        listOf(ListingType.FOR_SALE, ListingType.FOR_RENT).forEach { type ->
          val isSelected = selectedListingType == type
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = if (isSelected) EmeraldPrimary else MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(10.dp))
              .clickable { selectedListingType = type }
          ) {
            Text(
              text = if (type == ListingType.FOR_SALE) strings.forSale else strings.forRent,
              color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
              fontWeight = FontWeight.Bold,
              fontSize = 13.sp,
              modifier = Modifier.padding(vertical = 10.dp),
              textAlign = TextAlign.Center
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // 5. Category Chips
      Text("جۆرێ خانووبەرەی • Category", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
      Spacer(modifier = Modifier.height(6.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        listOf(PropertyType.VILLA, PropertyType.APARTMENT, PropertyType.LAND, PropertyType.COMMERCIAL).forEach { type ->
          val isSelected = selectedType == type
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = if (isSelected) EmeraldPrimary else MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(10.dp))
              .clickable { selectedType = type }
          ) {
            Text(
              text = type.getLabel(appLanguage),
              color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
              fontSize = 11.sp,
              fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
              modifier = Modifier.padding(vertical = 8.dp),
              textAlign = TextAlign.Center
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // 6. Price & Area
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        OutlinedTextField(
          value = priceUsdText,
          onValueChange = { priceUsdText = it },
          label = { Text("Price ($ USD)") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          modifier = Modifier
            .weight(1f)
            .testTag("admin_input_price"),
          singleLine = true,
          shape = RoundedCornerShape(12.dp)
        )
        OutlinedTextField(
          value = areaSqmText,
          onValueChange = { areaSqmText = it },
          label = { Text("Area (m²)") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          modifier = Modifier
            .weight(1f)
            .testTag("admin_input_area"),
          singleLine = true,
          shape = RoundedCornerShape(12.dp)
        )
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Bedrooms, Bathrooms, Parking
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        OutlinedTextField(
          value = bedrooms.toString(),
          onValueChange = { bedrooms = it.toIntOrNull() ?: 0 },
          label = { Text("Beds") },
          modifier = Modifier.weight(1f),
          singleLine = true,
          shape = RoundedCornerShape(12.dp)
        )
        OutlinedTextField(
          value = bathrooms.toString(),
          onValueChange = { bathrooms = it.toIntOrNull() ?: 0 },
          label = { Text("Baths") },
          modifier = Modifier.weight(1f),
          singleLine = true,
          shape = RoundedCornerShape(12.dp)
        )
        OutlinedTextField(
          value = parkingSpaces.toString(),
          onValueChange = { parkingSpaces = it.toIntOrNull() ?: 0 },
          label = { Text("Parking") },
          modifier = Modifier.weight(1f),
          singleLine = true,
          shape = RoundedCornerShape(12.dp)
        )
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Agent Contact Phone
      OutlinedTextField(
        value = contactPhone,
        onValueChange = { contactPhone = it },
        label = { Text("Agent Phone / WhatsApp (07514036954)") },
        leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null, tint = EmeraldPrimary) },
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
        shape = RoundedCornerShape(12.dp)
      )

      Spacer(modifier = Modifier.height(14.dp))

      // Tapu Certified Switch
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text("تاپۆیا باوەرپێکری • Tapu Certified", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
        Switch(
          checked = isTapuVerified,
          onCheckedChange = { isTapuVerified = it },
          colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = EmeraldPrimary)
        )
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Description
      OutlinedTextField(
        value = description,
        onValueChange = { description = it },
        label = { Text("وصف و هویرکاری • Description") },
        modifier = Modifier.fillMaxWidth(),
        maxLines = 3,
        shape = RoundedCornerShape(12.dp)
      )

      if (errorMessage != null) {
        Spacer(modifier = Modifier.height(8.dp))
        Text(text = errorMessage!!, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
      }

      Spacer(modifier = Modifier.height(20.dp))

      // Save & Publish Button
      Button(
        onClick = {
          if (title.isBlank()) {
            errorMessage = "Please enter property title"
            return@Button
          }
          val resolvedPlace = if (placeName.isNotBlank()) placeName.trim() else "Duhok"
          val price = priceUsdText.toDoubleOrNull() ?: 0.0
          if (price <= 0) {
            errorMessage = "Please enter a valid price in USD"
            return@Button
          }
          val area = areaSqmText.toIntOrNull() ?: 100

          val newProperty = Property(
            id = "user_prop_${UUID.randomUUID().toString().take(6)}",
            titleEn = title,
            titleBadini = title,
            titleSorani = title,
            titleArabic = title,
            neighborhoodEn = resolvedPlace,
            neighborhoodKu = resolvedPlace,
            neighborhoodArabic = resolvedPlace,
            type = selectedType,
            listingType = selectedListingType,
            priceUsd = price,
            areaSqm = area,
            bedrooms = bedrooms,
            bathrooms = bathrooms,
            parkingSpaces = parkingSpaces,
            yearBuilt = 2024,
            isFeatured = true,
            isTapuVerified = isTapuVerified,
            descriptionEn = if (description.isBlank()) "High quality property in $resolvedPlace, Duhok. Contact $contactPhone for inquiries." else description,
            descriptionBadini = if (description.isBlank()) "خانووبەرەکێ ئاست بەرز ل $resolvedPlace ل دهۆکێ. پەیوەندیێ ب $contactPhone بکە." else description,
            descriptionSorani = if (description.isBlank()) "موڵکێکی کوالیتی بەرز لە $resolvedPlace. پەیوەندی بکە بە $contactPhone." else description,
            descriptionArabic = if (description.isBlank()) "عقار راقٍ ومميز في $resolvedPlace بدهوك. للتواصل والاستفسار: $contactPhone." else description,
            amenities = listOf("Prime Location in $resolvedPlace", "Tapu Verified", "Modern Architecture", "Direct Contact: $contactPhone"),
            imageResIds = if (customImageUris.isEmpty()) listOf(selectedPresetRes) else emptyList(),
            imageUris = customImageUris,
            agent = Agent(
              id = "user_agent",
              name = "The Duhok-Aqar Agent",
              agency = "The Duhok-Aqar Real Estate",
              phone = contactPhone.ifBlank { "07514036954" },
              whatsapp = "+964" + (contactPhone.ifBlank { "07514036954" }).removePrefix("+964").removePrefix("0"),
              rating = 5.0f,
              reviewsCount = 1,
              verified = true
            )
          )

          onSave(newProperty)
        },
        modifier = Modifier
          .fillMaxWidth()
          .height(54.dp)
          .testTag("save_property_button"),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
      ) {
        Icon(Icons.Default.Add, contentDescription = null, tint = Color.White)
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = strings.savePropertyBtn,
          fontWeight = FontWeight.Bold,
          fontSize = 15.sp,
          color = Color.White
        )
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EditPropertySheet(
  property: Property,
  appLanguage: AppLanguage,
  onDismiss: () -> Unit,
  onSave: (Property) -> Unit
) {
  val context = LocalContext.current
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
  val strings = LocaleStrings.get(appLanguage)

  var title by remember { mutableStateOf(property.getTitle(appLanguage)) }
  var placeName by remember { mutableStateOf(property.neighborhoodEn) }
  var selectedType by remember { mutableStateOf(property.type) }
  var selectedListingType by remember { mutableStateOf(property.listingType) }
  var priceUsdText by remember { mutableStateOf(property.priceUsd.toLong().toString()) }
  var areaSqmText by remember { mutableStateOf(property.areaSqm.toString()) }
  var bedrooms by remember { mutableIntStateOf(property.bedrooms) }
  var bathrooms by remember { mutableIntStateOf(property.bathrooms) }
  var parkingSpaces by remember { mutableIntStateOf(property.parkingSpaces) }
  var isTapuVerified by remember { mutableStateOf(property.isTapuVerified) }
  var description by remember { mutableStateOf(property.getDescription(appLanguage)) }
  var contactPhone by remember { mutableStateOf(property.agent.phone) }

  var customImageUris by remember { mutableStateOf(property.imageUris) }
  var selectedPresetRes by remember { mutableIntStateOf(property.imageResIds.firstOrNull() ?: R.drawable.img_hero_duhok) }

  var errorMessage by remember { mutableStateOf<String?>(null) }

  val photoPickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.PickMultipleVisualMedia(maxItems = 10)
  ) { uris: List<Uri> ->
    if (uris.isNotEmpty()) {
      val savedPaths = uris.mapNotNull { uri ->
        PropertyStorage.saveImageUriToInternalStorage(context, uri)
      }
      customImageUris = (customImageUris + savedPaths).distinct()
    }
  }

  val popularDuhokPlaces = listOf(
    "مالتا (Malta)",
    "ماسیک (Masik)",
    "ئەڤرۆ ستی (Avro City)",
    "گرێ باسی (Gre Basi)",
    "کڕۆ (KRO)",
    "ئازادی (Azadi)",
    "شۆڕش (Shorsh)",
    "نزارکێ (Nizarke)",
    "زاویته (Zawita)",
    "سێمێل (Semel)",
    "شاخکێ (Shakhke)",
    "بەرۆشکێ (Baroshke)"
  )

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = MaterialTheme.colorScheme.surface,
    shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 24.dp)
        .padding(bottom = 36.dp)
        .verticalScroll(rememberScrollState())
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = strings.editPropertyTitle,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = "${property.getTitle(appLanguage)} • ID: ${property.id.take(8)}",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
        IconButton(onClick = onDismiss) {
          Icon(Icons.Default.Close, contentDescription = "Close")
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      // Place Name
      Text(text = strings.placeNameInput, fontWeight = FontWeight.Bold, fontSize = 13.sp)
      Spacer(modifier = Modifier.height(4.dp))
      OutlinedTextField(
        value = placeName,
        onValueChange = { placeName = it },
        label = { Text(strings.placeNameInput) },
        placeholder = { Text(strings.placeNameHelper) },
        leadingIcon = { Icon(Icons.Default.LocationOn, contentDescription = null, tint = EmeraldPrimary) },
        modifier = Modifier
          .fillMaxWidth()
          .testTag("admin_edit_input_place_name"),
        singleLine = true,
        shape = RoundedCornerShape(12.dp)
      )

      Spacer(modifier = Modifier.height(6.dp))
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        popularDuhokPlaces.forEach { placeStr ->
          val cleanPlace = placeStr.substringBefore(" (").trim()
          val isSelected = placeName.trim().equals(cleanPlace, ignoreCase = true)
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = if (isSelected) GoldPrimary else MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier
              .clip(RoundedCornerShape(10.dp))
              .clickable { placeName = cleanPlace }
          ) {
            Text(
              text = placeStr,
              color = if (isSelected) EmeraldDark else MaterialTheme.colorScheme.onSurface,
              fontSize = 11.sp,
              fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      // Photos management
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(text = strings.addPhotosFromGallery, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        if (customImageUris.isNotEmpty()) {
          Text(text = "${customImageUris.size} ${strings.selectedPhotosCount}", fontSize = 12.sp, color = EmeraldPrimary)
        }
      }
      Spacer(modifier = Modifier.height(8.dp))

      Button(
        onClick = {
          photoPickerLauncher.launch(
            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
          )
        },
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary.copy(alpha = 0.12f), contentColor = EmeraldDark),
        modifier = Modifier.fillMaxWidth()
      ) {
        Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, tint = EmeraldPrimary)
        Spacer(modifier = Modifier.width(8.dp))
        Text(strings.addPhotosFromGallery, fontWeight = FontWeight.Bold)
      }

      if (customImageUris.isNotEmpty()) {
        Spacer(modifier = Modifier.height(10.dp))
        LazyRow(
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          items(customImageUris) { path ->
            Box(
              modifier = Modifier
                .size(80.dp)
                .clip(RoundedCornerShape(12.dp))
            ) {
              AsyncImage(
                model = path,
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
              )
              Surface(
                shape = CircleShape,
                color = Color.Black.copy(alpha = 0.65f),
                modifier = Modifier
                  .align(Alignment.TopEnd)
                  .padding(4.dp)
                  .size(22.dp)
                  .clickable {
                    customImageUris = customImageUris.filterNot { it == path }
                  }
              ) {
                Box(contentAlignment = Alignment.Center) {
                  Icon(Icons.Default.Close, contentDescription = "Remove", tint = Color.White, modifier = Modifier.size(14.dp))
                }
              }
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      // Title
      OutlinedTextField(
        value = title,
        onValueChange = { title = it },
        label = { Text(strings.propertyTitleInput) },
        modifier = Modifier
          .fillMaxWidth()
          .testTag("admin_edit_input_title"),
        singleLine = true,
        shape = RoundedCornerShape(12.dp)
      )

      Spacer(modifier = Modifier.height(12.dp))

      // Purpose
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        listOf(ListingType.FOR_SALE, ListingType.FOR_RENT).forEach { type ->
          val isSelected = selectedListingType == type
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = if (isSelected) EmeraldPrimary else MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(10.dp))
              .clickable { selectedListingType = type }
          ) {
            Text(
              text = if (type == ListingType.FOR_SALE) strings.forSale else strings.forRent,
              color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
              fontWeight = FontWeight.Bold,
              fontSize = 13.sp,
              modifier = Modifier.padding(vertical = 10.dp),
              textAlign = TextAlign.Center
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Category Chips
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        listOf(PropertyType.VILLA, PropertyType.APARTMENT, PropertyType.LAND, PropertyType.COMMERCIAL).forEach { type ->
          val isSelected = selectedType == type
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = if (isSelected) EmeraldPrimary else MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(10.dp))
              .clickable { selectedType = type }
          ) {
            Text(
              text = type.getLabel(appLanguage),
              color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
              fontSize = 11.sp,
              fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
              modifier = Modifier.padding(vertical = 8.dp),
              textAlign = TextAlign.Center
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Price & Area
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        OutlinedTextField(
          value = priceUsdText,
          onValueChange = { priceUsdText = it },
          label = { Text(strings.propertyPriceUsdInput) },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          modifier = Modifier
            .weight(1.2f)
            .testTag("admin_edit_input_price"),
          singleLine = true,
          shape = RoundedCornerShape(12.dp)
        )
        OutlinedTextField(
          value = areaSqmText,
          onValueChange = { areaSqmText = it },
          label = { Text(strings.propertyAreaInput) },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          modifier = Modifier
            .weight(1f)
            .testTag("admin_edit_input_area"),
          singleLine = true,
          shape = RoundedCornerShape(12.dp)
        )
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Bedrooms, Bathrooms, Parking
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        OutlinedTextField(
          value = bedrooms.toString(),
          onValueChange = { bedrooms = it.toIntOrNull() ?: 0 },
          label = { Text("Beds") },
          modifier = Modifier.weight(1f),
          singleLine = true,
          shape = RoundedCornerShape(12.dp)
        )
        OutlinedTextField(
          value = bathrooms.toString(),
          onValueChange = { bathrooms = it.toIntOrNull() ?: 0 },
          label = { Text("Baths") },
          modifier = Modifier.weight(1f),
          singleLine = true,
          shape = RoundedCornerShape(12.dp)
        )
        OutlinedTextField(
          value = parkingSpaces.toString(),
          onValueChange = { parkingSpaces = it.toIntOrNull() ?: 0 },
          label = { Text("Parking") },
          modifier = Modifier.weight(1f),
          singleLine = true,
          shape = RoundedCornerShape(12.dp)
        )
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Agent Contact Phone
      OutlinedTextField(
        value = contactPhone,
        onValueChange = { contactPhone = it },
        label = { Text("Agent Phone / WhatsApp (07514036954)") },
        leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null, tint = EmeraldPrimary) },
        modifier = Modifier.fillMaxWidth().testTag("admin_edit_input_phone"),
        singleLine = true,
        shape = RoundedCornerShape(12.dp)
      )

      Spacer(modifier = Modifier.height(14.dp))

      // Tapu Certified Switch
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text("تاپۆیا باوەرپێکری • Tapu Certified", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
        Switch(
          checked = isTapuVerified,
          onCheckedChange = { isTapuVerified = it },
          colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = EmeraldPrimary)
        )
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Description
      OutlinedTextField(
        value = description,
        onValueChange = { description = it },
        label = { Text("وصف و هویرکاری • Description") },
        modifier = Modifier
          .fillMaxWidth()
          .testTag("admin_edit_input_description"),
        minLines = 3,
        shape = RoundedCornerShape(12.dp)
      )

      if (errorMessage != null) {
        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = errorMessage!!,
          color = MaterialTheme.colorScheme.error,
          fontSize = 12.sp
        )
      }

      Spacer(modifier = Modifier.height(20.dp))

      // Save Changes Button
      Button(
        onClick = {
          if (title.isBlank()) {
            errorMessage = "Please enter a property title"
            return@Button
          }
          val resolvedPlace = if (placeName.isNotBlank()) placeName.trim() else property.neighborhoodEn
          val price = priceUsdText.toDoubleOrNull() ?: 0.0
          if (price <= 0) {
            errorMessage = "Please enter a valid price in USD"
            return@Button
          }
          val area = areaSqmText.toIntOrNull() ?: 100

          val updatedProperty = property.copy(
            titleEn = if (appLanguage == AppLanguage.ENGLISH) title else property.titleEn,
            titleBadini = if (appLanguage == AppLanguage.BADINI) title else property.titleBadini,
            titleSorani = if (appLanguage == AppLanguage.SORANI) title else property.titleSorani,
            titleArabic = if (appLanguage == AppLanguage.ARABIC) title else property.titleArabic,
            neighborhoodEn = resolvedPlace,
            neighborhoodKu = resolvedPlace,
            neighborhoodArabic = resolvedPlace,
            type = selectedType,
            listingType = selectedListingType,
            priceUsd = price,
            areaSqm = area,
            bedrooms = bedrooms,
            bathrooms = bathrooms,
            parkingSpaces = parkingSpaces,
            isTapuVerified = isTapuVerified,
            imageUris = customImageUris,
            imageResIds = if (customImageUris.isEmpty()) listOf(selectedPresetRes) else property.imageResIds,
            descriptionEn = if (appLanguage == AppLanguage.ENGLISH) description else property.descriptionEn,
            descriptionBadini = if (appLanguage == AppLanguage.BADINI) description else property.descriptionBadini,
            descriptionSorani = if (appLanguage == AppLanguage.SORANI) description else property.descriptionSorani,
            descriptionArabic = if (appLanguage == AppLanguage.ARABIC) description else property.descriptionArabic,
            agent = property.agent.copy(
              phone = contactPhone.ifBlank { "07514036954" },
              whatsapp = "+964" + (contactPhone.ifBlank { "07514036954" }).removePrefix("+964").removePrefix("0")
            )
          )

          onSave(updatedProperty)
        },
        modifier = Modifier
          .fillMaxWidth()
          .height(52.dp)
          .testTag("save_edited_property_button"),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
      ) {
        Text(
          text = strings.saveChanges,
          fontWeight = FontWeight.Bold,
          fontSize = 15.sp,
          color = Color.White
        )
      }
    }
  }
}

@Composable
private fun EditOfficeInfoDialog(
  currentPhone: String,
  currentName: String,
  appLanguage: AppLanguage,
  onDismiss: () -> Unit,
  onSave: (phone: String, name: String) -> Unit
) {
  val strings = LocaleStrings.get(appLanguage)
  var phone by remember { mutableStateOf(currentPhone) }
  var name by remember { mutableStateOf(currentName) }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text(strings.editAgencyInfo, fontWeight = FontWeight.Bold) },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedTextField(
          value = name,
          onValueChange = { name = it },
          label = { Text(strings.agencyNameInput) },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("admin_office_name_input")
        )
        OutlinedTextField(
          value = phone,
          onValueChange = { phone = it },
          label = { Text(strings.agencyPhoneInput) },
          singleLine = true,
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
          modifier = Modifier.fillMaxWidth().testTag("admin_office_phone_input")
        )
      }
    },
    confirmButton = {
      Button(
        onClick = {
          onSave(phone, name)
          onDismiss()
        },
        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
        modifier = Modifier.testTag("admin_save_office_button")
      ) {
        Text(strings.saveSettingsBtn, color = Color.White)
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("پاشگەزبوون (Cancel)")
      }
    }
  )
}

@Composable
fun AdminPasscodeLockScreen(
  appLanguage: AppLanguage,
  onUnlock: (String) -> Boolean,
  onBack: () -> Unit,
  modifier: Modifier = Modifier
) {
  val strings = LocaleStrings.get(appLanguage)
  var passcode by remember { mutableStateOf("") }
  var isError by remember { mutableStateOf(false) }
  var passwordVisible by remember { mutableStateOf(false) }

  BackHandler {
    onBack()
  }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .padding(24.dp),
    contentAlignment = Alignment.Center
  ) {
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .testTag("admin_passcode_card"),
      shape = RoundedCornerShape(24.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Surface(
          shape = CircleShape,
          color = EmeraldPrimary.copy(alpha = 0.12f),
          modifier = Modifier.size(76.dp)
        ) {
          Box(contentAlignment = Alignment.Center) {
            Icon(
              imageVector = Icons.Default.Lock,
              contentDescription = null,
              tint = GoldPrimary,
              modifier = Modifier.size(38.dp)
            )
          }
        }

        Spacer(modifier = Modifier.height(18.dp))

        Text(
          text = strings.adminLockTitle,
          style = MaterialTheme.typography.titleLarge,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurface,
          textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
          text = strings.adminLockSubtitle,
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(24.dp))

        OutlinedTextField(
          value = passcode,
          onValueChange = {
            passcode = it
            if (isError) isError = false
          },
          label = { Text(strings.adminPasscodePlaceholder) },
          singleLine = true,
          isError = isError,
          visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
          trailingIcon = {
            IconButton(onClick = { passwordVisible = !passwordVisible }) {
              Icon(
                imageVector = if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                contentDescription = if (passwordVisible) "Hide password" else "Show password"
              )
            }
          },
          supportingText = {
            if (isError) {
              Text(
                text = strings.wrongPasscode,
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodySmall
              )
            }
          },
          modifier = Modifier
            .fillMaxWidth()
            .testTag("admin_passcode_input")
        )

        Spacer(modifier = Modifier.height(20.dp))

        Button(
          onClick = {
            val success = onUnlock(passcode)
            if (!success) {
              isError = true
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier
            .fillMaxWidth()
            .height(52.dp)
            .testTag("admin_unlock_button")
        ) {
          Text(
            text = strings.unlockBtn,
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp,
            color = Color.White
          )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Security Notice for Visitors
        Surface(
          shape = RoundedCornerShape(10.dp),
          color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
          modifier = Modifier.fillMaxWidth()
        ) {
          Text(
            text = strings.onlyAdminCanAddNote,
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(8.dp),
            lineHeight = 16.sp
          )
        }

        Spacer(modifier = Modifier.height(10.dp))

        TextButton(
          onClick = onBack,
          modifier = Modifier.testTag("admin_cancel_button")
        ) {
          Text(
            text = when (appLanguage) {
              AppLanguage.BADINI -> "زڤڕین بۆ سەرەکی"
              AppLanguage.SORANI -> "گەڕانەوە بۆ سەرەکی"
              AppLanguage.ARABIC -> "العودة للرئيسية"
              AppLanguage.ENGLISH -> "Return to Home"
            },
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }
    }
  }
}
