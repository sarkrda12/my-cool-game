package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Apartment
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Landscape
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Villa
import androidx.compose.material.icons.outlined.CurrencyExchange
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.SampleProperties
import com.example.data.UserProfile
import com.example.data.model.AppLanguage
import com.example.data.model.CurrencyMode
import com.example.data.model.ListingType
import com.example.data.model.LocaleStrings
import com.example.data.model.Property
import com.example.data.model.PropertyType
import com.example.ui.components.FeaturedCarousel
import com.example.ui.components.GoogleIconGraphic
import com.example.ui.components.PropertyCard
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.GoldPrimary

@Composable
fun HomeScreen(
  properties: List<Property>,
  currencyMode: CurrencyMode,
  appLanguage: AppLanguage,
  selectedType: PropertyType,
  selectedListingType: ListingType?,
  selectedNeighborhood: String,
  allNeighborhoods: List<String> = emptyList(),
  searchQuery: String,
  onSearchChange: (String) -> Unit,
  onTypeSelect: (PropertyType) -> Unit,
  onListingTypeSelect: (ListingType?) -> Unit,
  onNeighborhoodSelect: (String) -> Unit,
  onCurrencyToggle: () -> Unit,
  onOpenLanguageSelector: () -> Unit,
  onPropertyClick: (Property) -> Unit,
  onFavoriteClick: (String) -> Unit,
  onOpenFilter: () -> Unit,
  onOpenCalculator: () -> Unit,
  onOpenManage: () -> Unit,
  userProfile: UserProfile? = null,
  onGoogleAccountClick: () -> Unit = {},
  appAnnouncement: String = "",
  modifier: Modifier = Modifier
) {
  val strings = LocaleStrings.get(appLanguage)
  val featuredList = properties.filter { it.isFeatured }

  Box(
    modifier = modifier
      .fillMaxSize()
      .testTag("home_screen")
  ) {
    LazyColumn(
      modifier = Modifier.fillMaxSize(),
      contentPadding = PaddingValues(bottom = 110.dp)
    ) {
    // Top Bar Header
    item {
      TopBrandBar(
        currencyMode = currencyMode,
        appLanguage = appLanguage,
        userProfile = userProfile,
        onGoogleAccountClick = onGoogleAccountClick,
        onCurrencyToggle = onCurrencyToggle,
        onOpenLanguageSelector = onOpenLanguageSelector,
        onOpenCalculator = onOpenCalculator,
        onOpenManage = onOpenManage
      )
    }

    // App Announcement Banner (if set by Manager in Manage)
    if (appAnnouncement.isNotBlank()) {
      item {
        Card(
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = GoldPrimary.copy(alpha = 0.14f)),
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 6.dp)
            .testTag("app_announcement_banner")
        ) {
          Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            Surface(
              shape = CircleShape,
              color = GoldPrimary,
              modifier = Modifier.size(32.dp)
            ) {
              Box(contentAlignment = Alignment.Center) {
                Icon(
                  imageVector = Icons.Default.LocationOn,
                  contentDescription = null,
                  tint = EmeraldDark,
                  modifier = Modifier.size(18.dp)
                )
              }
            }
            Text(
              text = appAnnouncement,
              fontSize = 12.sp,
              fontWeight = FontWeight.SemiBold,
              color = MaterialTheme.colorScheme.onSurface,
              lineHeight = 17.sp,
              modifier = Modifier.weight(1f)
            )
          }
        }
      }
    }

    // Hero Search Bar & Filter Button
    item {
      SearchFilterHeader(
        searchQuery = searchQuery,
        searchPlaceholder = strings.searchPlaceholder,
        onSearchChange = onSearchChange,
        onOpenFilter = onOpenFilter
      )
    }

    // Rent / Buy Toggle Bar
    item {
      ListingTypeSegmentedControl(
        selectedListingType = selectedListingType,
        allText = strings.allListings,
        buyText = strings.forSale,
        rentText = strings.forRent,
        onSelect = onListingTypeSelect
      )
    }

    // Category Filter Chips
    item {
      CategoryHorizontalChips(
        selectedType = selectedType,
        appLanguage = appLanguage,
        onTypeSelect = onTypeSelect
      )
    }

    // Featured Carousel Header & Cards (shown when properties exist)
    if (featuredList.isNotEmpty()) {
      item {
        SectionTitle(
          title = strings.featuredSectionTitle,
          subtitle = strings.featuredSectionSubtitle
        )
      }
      item {
        FeaturedCarousel(
          featuredProperties = featuredList,
          currencyMode = currencyMode,
          appLanguage = appLanguage,
          onPropertyClick = onPropertyClick
        )
      }
    }

    // Neighborhood Quick Filter Strip
    item {
      Spacer(modifier = Modifier.height(8.dp))
      SectionTitle(
        title = strings.neighborhoodsTitle,
        subtitle = strings.neighborhoodsSubtitle
      )
      NeighborhoodHorizontalChips(
        selectedNeighborhood = selectedNeighborhood,
        allNeighborhoods = allNeighborhoods,
        appLanguage = appLanguage,
        onNeighborhoodSelect = onNeighborhoodSelect
      )
    }

    // Property List Feed Header
    item {
      Spacer(modifier = Modifier.height(14.dp))
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 20.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = strings.latestListingsTitle,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
          )
          Text(
            text = "${properties.size} ${strings.propertiesCountSuffix}",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }
    }

    // List of Properties
    if (properties.isEmpty()) {
      item {
        EmptyListingState(
          appLanguage = appLanguage,
          onOpenManage = onOpenManage
        )
      }
    } else {
      items(properties, key = { it.id }) { property ->
        PropertyCard(
          property = property,
          currencyMode = currencyMode,
          appLanguage = appLanguage,
          onClick = { onPropertyClick(property) },
          onFavoriteClick = { onFavoriteClick(property.id) },
          modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp)
        )
      }
    }
  }
}
}

@Composable
private fun TopBrandBar(
  currencyMode: CurrencyMode,
  appLanguage: AppLanguage,
  userProfile: UserProfile? = null,
  onGoogleAccountClick: () -> Unit = {},
  onCurrencyToggle: () -> Unit,
  onOpenLanguageSelector: () -> Unit,
  onOpenCalculator: () -> Unit,
  onOpenManage: () -> Unit
) {
  val strings = LocaleStrings.get(appLanguage)

  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 8.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      Image(
        painter = painterResource(id = R.drawable.img_logo_gold),
        contentDescription = "Logo",
        modifier = Modifier
          .size(40.dp)
          .clip(CircleShape)
      )
      Column {
        Text(
          text = strings.appTitle,
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Black,
          color = MaterialTheme.colorScheme.onSurface
        )
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
          Icon(
            imageVector = Icons.Default.LocationOn,
            contentDescription = null,
            tint = EmeraldPrimary,
            modifier = Modifier.size(13.dp)
          )
          Text(
            text = strings.appSubtitle,
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }
    }

    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
      // Google Account Profile Button
      Surface(
        shape = RoundedCornerShape(12.dp),
        color = if (userProfile != null && userProfile.isSignedIn) EmeraldPrimary.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant,
        border = if (userProfile != null && userProfile.isSignedIn) androidx.compose.foundation.BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.4f)) else null,
        modifier = Modifier
          .clip(RoundedCornerShape(12.dp))
          .clickable(onClick = onGoogleAccountClick)
          .testTag("google_account_top_btn")
      ) {
        Box(
          modifier = Modifier.size(34.dp),
          contentAlignment = Alignment.Center
        ) {
          if (userProfile != null && userProfile.isSignedIn) {
            Text(
              text = userProfile.name.take(1).uppercase(),
              fontSize = 14.sp,
              fontWeight = FontWeight.Black,
              color = EmeraldPrimary
            )
          } else {
            GoogleIconGraphic(modifier = Modifier.size(16.dp))
          }
        }
      }
      // Language Switcher Button (Badini / Sorani / English / Arabic)
      Surface(
        shape = RoundedCornerShape(12.dp),
        color = EmeraldPrimary.copy(alpha = 0.12f),
        modifier = Modifier
          .clip(RoundedCornerShape(12.dp))
          .clickable(onClick = onOpenLanguageSelector)
          .testTag("language_toggle_button")
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 8.dp, vertical = 7.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
          Icon(
            imageVector = Icons.Default.Language,
            contentDescription = "Language",
            tint = EmeraldPrimary,
            modifier = Modifier.size(15.dp)
          )
          Text(
            text = appLanguage.code.uppercase(),
            fontSize = 11.sp,
            fontWeight = FontWeight.ExtraBold,
            color = EmeraldPrimary
          )
        }
      }

      // Currency Switcher Button
      Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        modifier = Modifier
          .clip(RoundedCornerShape(12.dp))
          .clickable(onClick = onCurrencyToggle)
          .testTag("currency_toggle_button")
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 8.dp, vertical = 7.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
          Icon(
            imageVector = Icons.Outlined.CurrencyExchange,
            contentDescription = "Currency",
            tint = EmeraldPrimary,
            modifier = Modifier.size(15.dp)
          )
          Text(
            text = currencyMode.name,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = EmeraldPrimary
          )
        }
      }

      // Admin / Manage Panel Quick Trigger
      Surface(
        shape = RoundedCornerShape(12.dp),
        color = GoldPrimary.copy(alpha = 0.2f),
        modifier = Modifier
          .clip(RoundedCornerShape(12.dp))
          .clickable(onClick = onOpenManage)
          .testTag("home_admin_btn")
      ) {
        Box(
          modifier = Modifier.size(34.dp),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.AdminPanelSettings,
            contentDescription = "Manage",
            tint = GoldPrimary,
            modifier = Modifier.size(18.dp)
          )
        }
      }

      // Mortgage Calculator Trigger
      Surface(
        shape = RoundedCornerShape(12.dp),
        color = EmeraldPrimary.copy(alpha = 0.1f),
        modifier = Modifier
          .clip(RoundedCornerShape(12.dp))
          .clickable(onClick = onOpenCalculator)
          .testTag("home_calculator_button")
      ) {
        Box(
          modifier = Modifier.size(34.dp),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.Calculate,
            contentDescription = "Calculator",
            tint = EmeraldPrimary,
            modifier = Modifier.size(18.dp)
          )
        }
      }
    }
  }
}

@Composable
private fun SearchFilterHeader(
  searchQuery: String,
  searchPlaceholder: String,
  onSearchChange: (String) -> Unit,
  onOpenFilter: () -> Unit
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 20.dp, vertical = 8.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    OutlinedTextField(
      value = searchQuery,
      onValueChange = onSearchChange,
      modifier = Modifier
        .weight(1f)
        .testTag("home_search_input"),
      placeholder = {
        Text(searchPlaceholder, fontSize = 12.sp, maxLines = 1)
      },
      leadingIcon = {
        Icon(
          Icons.Default.Search,
          contentDescription = "Search",
          tint = MaterialTheme.colorScheme.onSurfaceVariant
        )
      },
      trailingIcon = {
        if (searchQuery.isNotEmpty()) {
          IconButton(onClick = { onSearchChange("") }) {
            Icon(Icons.Default.Close, contentDescription = "Clear", modifier = Modifier.size(18.dp))
          }
        }
      },
      singleLine = true,
      shape = RoundedCornerShape(16.dp),
      colors = OutlinedTextFieldDefaults.colors(
        focusedContainerColor = MaterialTheme.colorScheme.surface,
        unfocusedContainerColor = MaterialTheme.colorScheme.surface
      )
    )

    Surface(
      shape = RoundedCornerShape(16.dp),
      color = EmeraldPrimary,
      modifier = Modifier
        .size(52.dp)
        .clip(RoundedCornerShape(16.dp))
        .clickable(onClick = onOpenFilter)
        .testTag("filter_icon_button")
    ) {
      Box(contentAlignment = Alignment.Center) {
        Icon(
          imageVector = Icons.Default.FilterList,
          contentDescription = "Filter",
          tint = Color.White,
          modifier = Modifier.size(24.dp)
        )
      }
    }
  }
}

@Composable
private fun ListingTypeSegmentedControl(
  selectedListingType: ListingType?,
  allText: String,
  buyText: String,
  rentText: String,
  onSelect: (ListingType?) -> Unit
) {
  Card(
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 20.dp, vertical = 6.dp),
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(4.dp)
    ) {
      SegmentButton(
        label = allText,
        isSelected = selectedListingType == null,
        onClick = { onSelect(null) },
        modifier = Modifier.weight(1f)
      )
      SegmentButton(
        label = buyText,
        isSelected = selectedListingType == ListingType.FOR_SALE,
        onClick = { onSelect(ListingType.FOR_SALE) },
        modifier = Modifier.weight(1.1f)
      )
      SegmentButton(
        label = rentText,
        isSelected = selectedListingType == ListingType.FOR_RENT,
        onClick = { onSelect(ListingType.FOR_RENT) },
        modifier = Modifier.weight(1f)
      )
    }
  }
}

@Composable
private fun SegmentButton(
  label: String,
  isSelected: Boolean,
  onClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  Surface(
    shape = RoundedCornerShape(10.dp),
    color = if (isSelected) EmeraldPrimary else Color.Transparent,
    modifier = modifier
      .clip(RoundedCornerShape(10.dp))
      .clickable(onClick = onClick)
  ) {
    Text(
      text = label,
      modifier = Modifier.padding(vertical = 8.dp),
      fontSize = 12.sp,
      fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
      color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
      textAlign = androidx.compose.ui.text.style.TextAlign.Center
    )
  }
}

@Composable
private fun CategoryHorizontalChips(
  selectedType: PropertyType,
  appLanguage: AppLanguage,
  onTypeSelect: (PropertyType) -> Unit
) {
  val categories = listOf(
    PropertyType.ALL,
    PropertyType.VILLA,
    PropertyType.APARTMENT,
    PropertyType.LAND,
    PropertyType.COMMERCIAL,
    PropertyType.DUPLEX
  )

  Row(
    modifier = Modifier
      .fillMaxWidth()
      .horizontalScroll(rememberScrollState())
      .padding(horizontal = 20.dp, vertical = 8.dp),
    horizontalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    categories.forEach { type ->
      val isSelected = selectedType == type
      val icon = when (type) {
        PropertyType.ALL -> Icons.Default.Search
        PropertyType.VILLA -> Icons.Default.Villa
        PropertyType.APARTMENT -> Icons.Default.Apartment
        PropertyType.LAND -> Icons.Default.Landscape
        PropertyType.COMMERCIAL -> Icons.Default.Business
        PropertyType.DUPLEX -> Icons.Default.Villa
      }

      Surface(
        shape = RoundedCornerShape(14.dp),
        color = if (isSelected) EmeraldPrimary else MaterialTheme.colorScheme.surface,
        border = if (isSelected) null else androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        modifier = Modifier
          .clip(RoundedCornerShape(14.dp))
          .clickable { onTypeSelect(type) }
          .testTag("category_chip_${type.name}")
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          Icon(
            imageVector = icon,
            contentDescription = null,
            tint = if (isSelected) Color.White else EmeraldPrimary,
            modifier = Modifier.size(16.dp)
          )
          Text(
            text = type.getLabel(appLanguage),
            fontSize = 12.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
          )
        }
      }
    }
  }
}

@Composable
private fun NeighborhoodHorizontalChips(
  selectedNeighborhood: String,
  allNeighborhoods: List<String>,
  appLanguage: AppLanguage,
  onNeighborhoodSelect: (String) -> Unit
) {
  val hoods = if (allNeighborhoods.isNotEmpty()) allNeighborhoods else SampleProperties.duhokNeighborhoods
  val allNeighborhoodLabel = when (appLanguage) {
    AppLanguage.BADINI -> "هەمی دهۆک"
    AppLanguage.SORANI -> "هەموو دهۆک"
    AppLanguage.ARABIC -> "كل أحياء دهوك"
    AppLanguage.ENGLISH -> "All Duhok"
  }

  Row(
    modifier = Modifier
      .fillMaxWidth()
      .horizontalScroll(rememberScrollState())
      .padding(horizontal = 20.dp, vertical = 6.dp),
    horizontalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    hoods.forEach { hood ->
      val isSelected = selectedNeighborhood.equals(hood, ignoreCase = true)
      val displayHood = if (hood == "All Duhok") allNeighborhoodLabel else hood

      Surface(
        shape = RoundedCornerShape(20.dp),
        color = if (isSelected) GoldPrimary else MaterialTheme.colorScheme.surfaceVariant,
        modifier = Modifier
          .clip(RoundedCornerShape(20.dp))
          .clickable { onNeighborhoodSelect(hood) }
      ) {
        Text(
          text = displayHood,
          modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
          fontSize = 12.sp,
          fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
          color = if (isSelected) EmeraldDark else MaterialTheme.colorScheme.onSurface
        )
      }
    }
  }
}

@Composable
private fun SectionTitle(
  title: String,
  subtitle: String
) {
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .padding(start = 20.dp, end = 20.dp, top = 14.dp, bottom = 6.dp)
  ) {
    Text(
      text = title,
      style = MaterialTheme.typography.titleMedium,
      fontWeight = FontWeight.Bold,
      color = MaterialTheme.colorScheme.onSurface
    )
    Text(
      text = subtitle,
      style = MaterialTheme.typography.bodySmall,
      color = MaterialTheme.colorScheme.onSurfaceVariant
    )
  }
}

@Composable
private fun EmptyListingState(
  appLanguage: AppLanguage,
  onOpenManage: () -> Unit
) {
  val strings = LocaleStrings.get(appLanguage)
  val (msg, tip) = when (appLanguage) {
    AppLanguage.BADINI -> Pair(
      "هێشتا چ جهـ و وێنە نەهاتینە زێدەکرن",
      "تۆ دشێی ب ساناهی وێنەیێن خو و ناڤێن جهێن خو ل دەڤەرا دهۆکێ ل ڤێرە زێدە بکەی"
    )
    AppLanguage.SORANI -> Pair(
      "هێشتا هیچ شوێن و وێنەیەک زیاد نەکراوە",
      "دەتوانیت بە ئاسانی وێنەکانی خۆت و ناوی شوێنەکان لێرە زیاد بکەیت"
    )
    AppLanguage.ARABIC -> Pair(
      "لم تتم إضافة أي أماكن أو صور بعد",
      "يمكنك بسهولة إضافة صورك الخاصة وأسماء الأماكن والعقارات في دهوك"
    )
    AppLanguage.ENGLISH -> Pair(
      "No places or photos added yet",
      "You can easily add your own photos and place names in Duhok"
    )
  }

  Column(
    modifier = Modifier
      .fillMaxWidth()
      .padding(36.dp),
    horizontalAlignment = Alignment.CenterHorizontally
  ) {
    Surface(
      shape = CircleShape,
      color = EmeraldPrimary.copy(alpha = 0.12f),
      modifier = Modifier.size(72.dp)
    ) {
      Box(contentAlignment = Alignment.Center) {
        Icon(
          imageVector = Icons.Default.AddPhotoAlternate,
          contentDescription = null,
          tint = EmeraldPrimary,
          modifier = Modifier.size(36.dp)
        )
      }
    }
    Spacer(modifier = Modifier.height(14.dp))
    Text(
      text = msg,
      style = MaterialTheme.typography.titleMedium,
      fontWeight = FontWeight.Bold,
      textAlign = androidx.compose.ui.text.style.TextAlign.Center
    )
    Spacer(modifier = Modifier.height(6.dp))
    Text(
      text = tip,
      style = MaterialTheme.typography.bodySmall,
      color = MaterialTheme.colorScheme.onSurfaceVariant,
      textAlign = androidx.compose.ui.text.style.TextAlign.Center
    )
    Spacer(modifier = Modifier.height(20.dp))
    Button(
      onClick = onOpenManage,
      shape = RoundedCornerShape(14.dp),
      colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
    ) {
      Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
      Spacer(modifier = Modifier.width(8.dp))
      Text(strings.fabAddPlace, fontWeight = FontWeight.Bold)
    }
  }
}
