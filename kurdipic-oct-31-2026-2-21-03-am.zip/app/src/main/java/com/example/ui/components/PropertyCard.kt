package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bathtub
import androidx.compose.material.icons.filled.Bed
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.SquareFoot
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.data.model.CurrencyMode
import com.example.data.model.ListingType
import com.example.data.model.LocaleStrings
import com.example.data.model.Property
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.RentBadgeBg
import com.example.ui.theme.RentBadgeText
import com.example.ui.theme.SaleBadgeBg
import com.example.ui.theme.SaleBadgeText

@Composable
fun PropertyCard(
  property: Property,
  currencyMode: CurrencyMode,
  appLanguage: AppLanguage = AppLanguage.BADINI,
  onClick: () -> Unit,
  onFavoriteClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  val isRent = property.listingType == ListingType.FOR_RENT
  val strings = LocaleStrings.get(appLanguage)

  Card(
    modifier = modifier
      .fillMaxWidth()
      .testTag("property_card_${property.id}")
      .clickable(onClick = onClick),
    shape = RoundedCornerShape(22.dp),
    colors = CardDefaults.cardColors(
      containerColor = MaterialTheme.colorScheme.surface
    ),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column {
      // Image container with badges
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(210.dp)
      ) {
        val imageSource = property.getImageSources().firstOrNull() ?: com.example.R.drawable.img_hero_duhok
        coil.compose.AsyncImage(
          model = imageSource,
          contentDescription = property.getTitle(appLanguage),
          modifier = Modifier.fillMaxSize(),
          contentScale = ContentScale.Crop,
          placeholder = painterResource(id = com.example.R.drawable.img_hero_duhok),
          error = painterResource(id = com.example.R.drawable.img_hero_duhok)
        )

        // Gradient overlay
        Box(
          modifier = Modifier
            .fillMaxSize()
            .background(
              Brush.verticalGradient(
                colors = listOf(
                  Color.Black.copy(alpha = 0.45f),
                  Color.Transparent,
                  Color.Black.copy(alpha = 0.65f)
                ),
                startY = 0f,
                endY = Float.POSITIVE_INFINITY
              )
            )
        )

        // Top Badges Row
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(14.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          // Listing type pill (Rent / Sale in active language)
          Surface(
            shape = RoundedCornerShape(12.dp),
            color = if (isRent) RentBadgeBg else SaleBadgeBg,
            shadowElevation = 2.dp
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = if (isRent) strings.forRent else strings.forSale,
                color = if (isRent) RentBadgeText else SaleBadgeText,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
              )
            }
          }

          // Favorite Button
          Surface(
            modifier = Modifier.size(38.dp),
            shape = CircleShape,
            color = Color.Black.copy(alpha = 0.4f)
          ) {
            IconButton(
              onClick = onFavoriteClick,
              modifier = Modifier
                .fillMaxSize()
                .testTag("favorite_button_${property.id}")
            ) {
              Icon(
                imageVector = if (property.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                contentDescription = "Toggle Favorite",
                tint = if (property.isFavorite) Color(0xFFFF5252) else Color.White,
                modifier = Modifier.size(20.dp)
              )
            }
          }
        }

        // Bottom Image Overlay: Price Tag & Tapu verified
        Row(
          modifier = Modifier
            .align(Alignment.BottomStart)
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 10.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.Bottom
        ) {
          Column {
            Text(
              text = currencyMode.formatPrice(property.priceUsd, isRent, appLanguage),
              color = Color.White,
              fontSize = 20.sp,
              fontWeight = FontWeight.ExtraBold
            )
            if (currencyMode != CurrencyMode.USD && !isRent) {
              Text(
                text = "≈ $${String.format("%,.0f", property.priceUsd)} USD",
                color = Color.White.copy(alpha = 0.8f),
                fontSize = 11.sp
              )
            }
          }

          if (property.isTapuVerified) {
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = EmeraldDark.copy(alpha = 0.85f),
              border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.5f))
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
              ) {
                Icon(
                  imageVector = Icons.Default.Verified,
                  contentDescription = "Tapu Verified",
                  tint = GoldPrimary,
                  modifier = Modifier.size(14.dp)
                )
                Text(
                  text = strings.tapuVerified,
                  color = Color.White,
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold
                )
              }
            }
          }
        }
      }

      // Details Content Body
      Column(
        modifier = Modifier.padding(16.dp)
      ) {
        // Neighborhood and City
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
          Icon(
            imageVector = Icons.Default.LocationOn,
            contentDescription = null,
            tint = EmeraldPrimary,
            modifier = Modifier.size(16.dp)
          )
          Text(
            text = "${property.getNeighborhood(appLanguage)}, ${strings.appSubtitle}",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontWeight = FontWeight.Medium
          )
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Property Title in selected language
        Text(
          text = property.getTitle(appLanguage),
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurface,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Specifications Row (Beds, Baths, Sqm)
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
            .padding(horizontal = 12.dp, vertical = 8.dp),
          horizontalArrangement = Arrangement.SpaceAround,
          verticalAlignment = Alignment.CenterVertically
        ) {
          if (property.bedrooms > 0) {
            SpecPill(icon = Icons.Default.Bed, label = "${property.bedrooms} ${strings.beds}")
          }
          if (property.bathrooms > 0) {
            SpecPill(icon = Icons.Default.Bathtub, label = "${property.bathrooms} ${strings.baths}")
          }
          SpecPill(icon = Icons.Default.SquareFoot, label = "${property.areaSqm} m² ${strings.area}")
        }
      }
    }
  }
}

@Composable
private fun SpecPill(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  label: String
) {
  Row(
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.spacedBy(4.dp)
  ) {
    Icon(
      imageVector = icon,
      contentDescription = null,
      tint = EmeraldPrimary,
      modifier = Modifier.size(16.dp)
    )
    Text(
      text = label,
      fontSize = 12.sp,
      fontWeight = FontWeight.SemiBold,
      color = MaterialTheme.colorScheme.onSurface
    )
  }
}
