package com.example.ui.components

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.data.model.LocaleStrings
import com.example.data.model.Property
import com.example.data.model.VisitBooking
import com.example.ui.theme.EmeraldPrimary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScheduleVisitSheet(
  property: Property,
  appLanguage: AppLanguage = AppLanguage.BADINI,
  onDismiss: () -> Unit,
  onConfirm: (VisitBooking) -> Unit
) {
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
  val strings = LocaleStrings.get(appLanguage)

  var selectedDate by remember { mutableStateOf("Tomorrow") }
  var selectedTimeSlot by remember { mutableStateOf("02:00 PM - 03:30 PM") }
  var selectedTourType by remember { mutableStateOf(strings.inPersonVisit) }
  var visitorName by remember { mutableStateOf("") }
  var visitorPhone by remember { mutableStateOf("+964 750 ") }
  var errorMessage by remember { mutableStateOf<String?>(null) }

  val dateOptions = when (appLanguage) {
    AppLanguage.BADINI -> listOf("ئەڤرۆ (ئێڤاری)", "سوبەهی", "شەمبی", "ئێک شەمب")
    AppLanguage.SORANI -> listOf("ئەمڕۆ (ئێوارە)", "بەیانی", "شەممە", "یەکشەممە")
    AppLanguage.ARABIC -> listOf("اليوم (مساءً)", "غداً", "السبت", "الأحد")
    AppLanguage.ENGLISH -> listOf("Today (Eve)", "Tomorrow", "Saturday", "Sunday")
  }
  val timeOptions = listOf("10:00 AM - 11:30 AM", "02:00 PM - 03:30 PM", "05:00 PM - 06:30 PM")

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = MaterialTheme.colorScheme.surface,
    shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 24.dp)
        .padding(bottom = 32.dp)
    ) {
      // Header
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = strings.scheduleVisitTitle,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
          )
          Text(
            text = "${property.getNeighborhood(appLanguage)}, Duhok • ${property.agent.name}",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
        IconButton(onClick = onDismiss) {
          Icon(Icons.Default.Close, contentDescription = "Close")
        }
      }

      Spacer(modifier = Modifier.height(18.dp))

      // Tour Type Selector
      Text(
        text = strings.visitType,
        fontWeight = FontWeight.SemiBold,
        fontSize = 14.sp,
        color = MaterialTheme.colorScheme.onSurface
      )
      Spacer(modifier = Modifier.height(8.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        listOf(strings.inPersonVisit, strings.videoTour).forEach { type ->
          val isSelected = selectedTourType == type
          Surface(
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(12.dp))
              .clickable { selectedTourType = type }
              .border(
                width = if (isSelected) 2.dp else 1.dp,
                color = if (isSelected) EmeraldPrimary else MaterialTheme.colorScheme.outline,
                shape = RoundedCornerShape(12.dp)
              ),
            color = if (isSelected) EmeraldPrimary.copy(alpha = 0.08f) else Color.Transparent
          ) {
            Row(
              modifier = Modifier.padding(vertical = 12.dp, horizontal = 10.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.Center
            ) {
              Icon(
                imageVector = if (type == strings.inPersonVisit) Icons.Default.LocationOn else Icons.Default.Videocam,
                contentDescription = null,
                tint = if (isSelected) EmeraldPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(16.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = type,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                fontSize = 12.sp,
                color = if (isSelected) EmeraldPrimary else MaterialTheme.colorScheme.onSurface
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      // Date Selection
      Text(
        text = strings.preferredDay,
        fontWeight = FontWeight.SemiBold,
        fontSize = 14.sp,
        color = MaterialTheme.colorScheme.onSurface
      )
      Spacer(modifier = Modifier.height(8.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        dateOptions.forEach { date ->
          val isSelected = selectedDate == date
          Surface(
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(10.dp))
              .clickable { selectedDate = date },
            color = if (isSelected) EmeraldPrimary else MaterialTheme.colorScheme.surfaceVariant
          ) {
            Text(
              text = date,
              modifier = Modifier.padding(vertical = 8.dp),
              fontSize = 11.sp,
              fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
              color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
              textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      // Time Slot Selection
      Text(
        text = strings.timeWindow,
        fontWeight = FontWeight.SemiBold,
        fontSize = 14.sp,
        color = MaterialTheme.colorScheme.onSurface
      )
      Spacer(modifier = Modifier.height(8.dp))
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        timeOptions.forEach { slot ->
          val isSelected = selectedTimeSlot == slot
          Surface(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(10.dp))
              .clickable { selectedTimeSlot = slot }
              .border(
                width = if (isSelected) 1.5.dp else 0.5.dp,
                color = if (isSelected) EmeraldPrimary else MaterialTheme.colorScheme.outline,
                shape = RoundedCornerShape(10.dp)
              ),
            color = if (isSelected) EmeraldPrimary.copy(alpha = 0.08f) else Color.Transparent
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(
                text = slot,
                fontSize = 13.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) EmeraldPrimary else MaterialTheme.colorScheme.onSurface
              )
              if (isSelected) {
                Icon(
                  Icons.Default.CheckCircle,
                  contentDescription = null,
                  tint = EmeraldPrimary,
                  modifier = Modifier.size(16.dp)
                )
              }
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      // Visitor Contact Inputs
      OutlinedTextField(
        value = visitorName,
        onValueChange = { visitorName = it },
        label = { Text(strings.yourName) },
        leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
        singleLine = true,
        modifier = Modifier
          .fillMaxWidth()
          .testTag("visitor_name_input"),
        shape = RoundedCornerShape(12.dp)
      )

      Spacer(modifier = Modifier.height(10.dp))

      OutlinedTextField(
        value = visitorPhone,
        onValueChange = { visitorPhone = it },
        label = { Text(strings.yourPhone) },
        leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) },
        singleLine = true,
        modifier = Modifier
          .fillMaxWidth()
          .testTag("visitor_phone_input"),
        shape = RoundedCornerShape(12.dp)
      )

      if (errorMessage != null) {
        Spacer(modifier = Modifier.height(6.dp))
        Text(
          text = errorMessage!!,
          color = MaterialTheme.colorScheme.error,
          fontSize = 12.sp
        )
      }

      Spacer(modifier = Modifier.height(20.dp))

      Button(
        onClick = {
          if (visitorName.isBlank()) {
            errorMessage = "Please enter your name"
            return@Button
          }
          if (visitorPhone.length < 8) {
            errorMessage = "Please enter a valid phone number"
            return@Button
          }
          errorMessage = null
          onConfirm(
            VisitBooking(
              propertyId = property.id,
              propertyTitle = property.getTitle(appLanguage),
              date = selectedDate,
              timeSlot = selectedTimeSlot,
              tourType = selectedTourType,
              visitorName = visitorName,
              visitorPhone = visitorPhone
            )
          )
        },
        modifier = Modifier
          .fillMaxWidth()
          .height(52.dp)
          .testTag("confirm_schedule_button"),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
      ) {
        Icon(Icons.Default.CalendarToday, contentDescription = null, tint = Color.White)
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = strings.confirmBooking,
          fontWeight = FontWeight.Bold,
          fontSize = 14.sp,
          color = Color.White
        )
      }
    }
  }
}
