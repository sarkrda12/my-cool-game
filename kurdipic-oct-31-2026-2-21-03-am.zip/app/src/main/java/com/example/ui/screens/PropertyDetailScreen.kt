package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Bathtub
import androidx.compose.material.icons.filled.Bed
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.SquareFoot
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Whatsapp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.AppLanguage
import com.example.data.model.CurrencyMode
import com.example.data.model.ListingType
import com.example.data.model.LocaleStrings
import com.example.data.model.Property
import com.example.data.model.VisitBooking
import com.example.ui.components.AgentContactHelper
import com.example.ui.components.ScheduleVisitSheet
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.RentBadgeBg
import com.example.ui.theme.RentBadgeText
import com.example.ui.theme.SaleBadgeBg
import com.example.ui.theme.SaleBadgeText
import com.example.ui.theme.WhatsAppGreen

@Composable
fun PropertyDetailScreen(
  property: Property,
  currencyMode: CurrencyMode,
  appLanguage: AppLanguage = AppLanguage.BADINI,
  onBack: () -> Unit,
  onFavoriteToggle: () -> Unit,
  onScheduleVisitConfirmed: (VisitBooking) -> Unit,
  modifier: Modifier = Modifier
) {
  BackHandler(onBack = onBack)

  val context = LocalContext.current
  val strings = LocaleStrings.get(appLanguage)
  var showScheduleSheet by remember { mutableStateOf(false) }
  var isDescriptionExpanded by remember { mutableStateOf(false) }

  val imageSources = property.getImageSources()
  val pagerState = rememberPagerState(pageCount = { imageSources.size })
  val isRent = property.listingType == ListingType.FOR_RENT

  val daftarsWord = when (appLanguage) {
    AppLanguage.BADINI, AppLanguage.SORANI -> "دەفتەر"
    AppLanguage.ARABIC -> "دفتر"
    AppLanguage.ENGLISH -> "Daftars"
  }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .testTag("property_detail_screen")
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .verticalScroll(rememberScrollState())
        .padding(bottom = 100.dp)
    ) {
      // 1. Image Gallery Slider
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(340.dp)
      ) {
        HorizontalPager(
          state = pagerState,
          modifier = Modifier.fillMaxSize()
        ) { page ->
          val source = imageSources.getOrElse(page) { R.drawable.img_hero_duhok }
          coil.compose.AsyncImage(
            model = source,
            contentDescription = "Property photo ${page + 1}",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop,
            placeholder = painterResource(id = R.drawable.img_hero_duhok),
            error = painterResource(id = R.drawable.img_hero_duhok)
          )
        }

        // Top Gradient for button visibility
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(100.dp)
            .background(
              Brush.verticalGradient(
                colors = listOf(Color.Black.copy(alpha = 0.6f), Color.Transparent)
              )
            )
        )

        // Top Bar (Back, Favorite)
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 32.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Surface(
            modifier = Modifier.size(42.dp),
            shape = CircleShape,
            color = Color.Black.copy(alpha = 0.45f)
          ) {
            IconButton(onClick = onBack, modifier = Modifier.testTag("detail_back_button")) {
              Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Back",
                tint = Color.White
              )
            }
          }

          Surface(
            modifier = Modifier.size(42.dp),
            shape = CircleShape,
            color = Color.Black.copy(alpha = 0.45f)
          ) {
            IconButton(onClick = onFavoriteToggle, modifier = Modifier.testTag("detail_favorite_button")) {
              Icon(
                imageVector = if (property.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                contentDescription = "Favorite",
                tint = if (property.isFavorite) Color(0xFFFF5252) else Color.White
              )
            }
          }
        }

        // Page Indicator Dots
        Row(
          modifier = Modifier
            .align(Alignment.BottomCenter)
            .padding(bottom = 16.dp),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          repeat(imageSources.size) { index ->
            val isCurrent = pagerState.currentPage == index
            Box(
              modifier = Modifier
                .height(8.dp)
                .width(if (isCurrent) 22.dp else 8.dp)
                .clip(CircleShape)
                .background(if (isCurrent) GoldPrimary else Color.White.copy(alpha = 0.5f))
            )
          }
        }
      }

      // 2. Main Content Card
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(20.dp)
      ) {
        // Rent/Sale pill + Neighborhood
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = if (isRent) RentBadgeBg else SaleBadgeBg
          ) {
            Text(
              text = if (isRent) strings.forRent else strings.forSale,
              color = if (isRent) RentBadgeText else SaleBadgeText,
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold
            )
          }

          if (property.isTapuVerified) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
              Icon(
                imageVector = Icons.Default.Verified,
                contentDescription = null,
                tint = EmeraldPrimary,
                modifier = Modifier.size(16.dp)
              )
              Text(
                text = strings.tapuVerified,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = EmeraldPrimary
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Price Section
        Text(
          text = currencyMode.formatPrice(property.priceUsd, isRent, appLanguage),
          fontSize = 28.sp,
          fontWeight = FontWeight.Black,
          color = EmeraldDark
        )

        // Subprice info
        if (!isRent) {
          val pricePerSqm = property.priceUsd / property.areaSqm
          Text(
            text = "$${String.format("%,.0f", property.priceUsd)} USD • ~$${String.format("%,.0f", pricePerSqm)}/m² (${String.format("%.1f", property.priceUsd / 10000)} $daftarsWord)",
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Property Title in active language
        Text(
          text = property.getTitle(appLanguage),
          style = MaterialTheme.typography.titleLarge,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurface
        )

        Spacer(modifier = Modifier.height(6.dp))

        // Location Info
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          Icon(
            imageVector = Icons.Default.LocationOn,
            contentDescription = null,
            tint = EmeraldPrimary,
            modifier = Modifier.size(18.dp)
          )
          Text(
            text = "${property.getNeighborhood(appLanguage)}, ${strings.appSubtitle}",
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface
          )
        }

        Spacer(modifier = Modifier.height(18.dp))

        // 3. Key Specifications Grid
        Card(
          shape = RoundedCornerShape(18.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Text(
              text = strings.specifications,
              fontWeight = FontWeight.Bold,
              fontSize = 14.sp,
              color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(12.dp))
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceAround
            ) {
              SpecItem(icon = Icons.Default.Bed, value = "${property.bedrooms}", label = strings.beds)
              SpecItem(icon = Icons.Default.Bathtub, value = "${property.bathrooms}", label = strings.baths)
              SpecItem(icon = Icons.Default.SquareFoot, value = "${property.areaSqm} m²", label = strings.area)
              SpecItem(icon = Icons.Default.DirectionsCar, value = "${property.parkingSpaces}", label = strings.parking)
            }
          }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // 4. Description
        Text(
          text = strings.overviewAndDetails,
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
          text = property.getDescription(appLanguage),
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          lineHeight = 22.sp,
          maxLines = if (isDescriptionExpanded) Int.MAX_VALUE else 4
        )
        Text(
          text = if (isDescriptionExpanded) strings.showLess else strings.readMore,
          color = EmeraldPrimary,
          fontWeight = FontWeight.Bold,
          fontSize = 13.sp,
          modifier = Modifier
            .clickable { isDescriptionExpanded = !isDescriptionExpanded }
            .padding(vertical = 4.dp)
        )

        Spacer(modifier = Modifier.height(20.dp))

        // 5. Amenities & Features Chips
        Text(
          text = strings.amenitiesAndFeatures,
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.height(10.dp))
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          property.amenities.chunked(2).forEach { rowItems ->
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              rowItems.forEach { amenity ->
                Surface(
                  shape = RoundedCornerShape(12.dp),
                  color = MaterialTheme.colorScheme.surfaceVariant,
                  modifier = Modifier.weight(1f)
                ) {
                  Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                  ) {
                    Icon(
                      imageVector = Icons.Default.Star,
                      contentDescription = null,
                      tint = GoldPrimary,
                      modifier = Modifier.size(15.dp)
                    )
                    Text(
                      text = amenity,
                      fontSize = 12.sp,
                      fontWeight = FontWeight.Medium,
                      color = MaterialTheme.colorScheme.onSurface
                    )
                  }
                }
              }
              if (rowItems.size == 1) {
                Spacer(modifier = Modifier.weight(1f))
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // 6. Location Map Preview Card
        Card(
          shape = RoundedCornerShape(18.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              Icon(
                imageVector = Icons.Default.Map,
                contentDescription = null,
                tint = EmeraldPrimary,
                modifier = Modifier.size(18.dp)
              )
              Text(
                text = strings.locationTitle,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
              )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
              text = "GPS: ${property.latitude}° N, ${property.longitude}° E • ${property.getNeighborhood(appLanguage)}",
              fontSize = 12.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(10.dp))
            val (uod, dam, souq) = when (appLanguage) {
              AppLanguage.BADINI -> Triple("زانکۆیا دهۆکێ", "بەنداڤا دهۆکێ", "بازاڕێ ناڤەندی یێ دهۆکێ")
              AppLanguage.SORANI -> Triple("زانکۆی دهۆک", "بنداوی دهۆک", "بازاڕی ناوەندی")
              AppLanguage.ARABIC -> Triple("جامعة دهوك", "سد دهوك السياحي", "السوق المركزي")
              AppLanguage.ENGLISH -> Triple("University of Duhok", "Duhok Dam Recreation", "Central Bazaar (Souq)")
            }
            DistanceRow(landmark = uod, distance = "3.2 km")
            DistanceRow(landmark = dam, distance = "4.8 km")
            DistanceRow(landmark = souq, distance = "2.1 km")
          }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // 7. Agent Card
        Card(
          shape = RoundedCornerShape(18.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Surface(
              shape = CircleShape,
              color = EmeraldPrimary,
              modifier = Modifier.size(48.dp)
            ) {
              Box(contentAlignment = Alignment.Center) {
                Text(
                  text = property.agent.name.take(2).uppercase(),
                  color = Color.White,
                  fontWeight = FontWeight.Bold,
                  fontSize = 18.sp
                )
              }
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                  text = property.agent.name,
                  fontWeight = FontWeight.Bold,
                  fontSize = 15.sp
                )
                Spacer(modifier = Modifier.width(4.dp))
                Icon(
                  imageVector = Icons.Default.Verified,
                  contentDescription = "Verified Agent",
                  tint = EmeraldPrimary,
                  modifier = Modifier.size(14.dp)
                )
              }
              Text(
                text = property.agent.agency,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
              ) {
                Icon(
                  imageVector = Icons.Default.Star,
                  contentDescription = null,
                  tint = GoldPrimary,
                  modifier = Modifier.size(13.dp)
                )
                Text(
                  text = "${property.agent.rating} (${property.agent.reviewsCount} reviews)",
                  fontSize = 11.sp,
                  fontWeight = FontWeight.SemiBold
                )
              }
            }
          }
        }
      }
    }

    // 8. Sticky Bottom Action Bar: Call, WhatsApp, Schedule a Visit
    Surface(
      modifier = Modifier
        .align(Alignment.BottomCenter)
        .fillMaxWidth()
        .navigationBarsPadding(),
      color = MaterialTheme.colorScheme.surface,
      shadowElevation = 12.dp
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Phone Call Button
        Surface(
          shape = RoundedCornerShape(14.dp),
          color = MaterialTheme.colorScheme.surfaceVariant,
          modifier = Modifier
            .size(50.dp)
            .clip(RoundedCornerShape(14.dp))
            .clickable {
              AgentContactHelper.callAgent(context, property.agent.phone)
            }
            .testTag("detail_call_button")
        ) {
          Box(contentAlignment = Alignment.Center) {
            Icon(
              imageVector = Icons.Default.Call,
              contentDescription = strings.callAgent,
              tint = EmeraldPrimary,
              modifier = Modifier.size(22.dp)
            )
          }
        }

        // WhatsApp Button
        Surface(
          shape = RoundedCornerShape(14.dp),
          color = WhatsAppGreen,
          modifier = Modifier
            .size(50.dp)
            .clip(RoundedCornerShape(14.dp))
            .clickable {
              AgentContactHelper.openWhatsApp(context, property.agent.whatsapp, property.getTitle(appLanguage))
            }
            .testTag("detail_whatsapp_button")
        ) {
          Box(contentAlignment = Alignment.Center) {
            Icon(
              imageVector = Icons.Default.Whatsapp,
              contentDescription = strings.whatsApp,
              tint = Color.White,
              modifier = Modifier.size(24.dp)
            )
          }
        }

        // Schedule Visit Primary Button
        Button(
          onClick = { showScheduleSheet = true },
          modifier = Modifier
            .weight(1f)
            .height(50.dp)
            .testTag("detail_schedule_visit_button"),
          shape = RoundedCornerShape(14.dp),
          colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
        ) {
          Icon(
            imageVector = Icons.Default.CalendarToday,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(18.dp)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = strings.scheduleVisit,
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp,
            color = Color.White
          )
        }
      }
    }

    // Schedule Visit Bottom Sheet
    if (showScheduleSheet) {
      ScheduleVisitSheet(
        property = property,
        appLanguage = appLanguage,
        onDismiss = { showScheduleSheet = false },
        onConfirm = { booking ->
          showScheduleSheet = false
          onScheduleVisitConfirmed(booking)
        }
      )
    }
  }
}

@Composable
private fun SpecItem(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  value: String,
  label: String
) {
  Column(horizontalAlignment = Alignment.CenterHorizontally) {
    Surface(
      shape = CircleShape,
      color = EmeraldPrimary.copy(alpha = 0.1f),
      modifier = Modifier.size(36.dp)
    ) {
      Box(contentAlignment = Alignment.Center) {
        Icon(
          imageVector = icon,
          contentDescription = null,
          tint = EmeraldPrimary,
          modifier = Modifier.size(18.dp)
        )
      }
    }
    Spacer(modifier = Modifier.height(4.dp))
    Text(text = value, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    Text(text = label, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
  }
}

@Composable
private fun DistanceRow(landmark: String, distance: String) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 3.dp),
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Text(
      text = landmark,
      fontSize = 12.sp,
      color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    Text(
      text = distance,
      fontSize = 12.sp,
      fontWeight = FontWeight.SemiBold,
      color = EmeraldPrimary
    )
  }
}
