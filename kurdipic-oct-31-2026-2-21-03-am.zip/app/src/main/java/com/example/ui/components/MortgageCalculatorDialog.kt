package com.example.ui.components

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Percent
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.outlined.Chat
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.data.model.LocaleStrings
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.GoldPrimary
import java.text.NumberFormat
import java.util.Locale
import kotlin.math.pow
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MortgageCalculatorSheet(
  propertyPriceUsd: Double = 250000.0,
  appLanguage: AppLanguage = AppLanguage.BADINI,
  officePhone: String = "07514036954",
  onDismiss: () -> Unit
) {
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
  val strings = LocaleStrings.get(appLanguage)
  val context = LocalContext.current

  var price by remember { mutableDoubleStateOf(if (propertyPriceUsd > 0) propertyPriceUsd else 250000.0) }
  var downPaymentPercent by remember { mutableFloatStateOf(20f) }
  var loanTenureYears by remember { mutableIntStateOf(10) }
  var annualInterestRate by remember { mutableFloatStateOf(5.0f) }

  // Financial Loan Calculations
  val downPaymentAmount = price * (downPaymentPercent / 100.0)
  val principal = price - downPaymentAmount
  val monthlyInterestRate = (annualInterestRate / 100.0) / 12.0
  val totalMonths = loanTenureYears * 12

  val monthlyPaymentUsd = if (monthlyInterestRate > 0) {
    val factor = (1.0 + monthlyInterestRate).pow(totalMonths.toDouble())
    principal * (monthlyInterestRate * factor) / (factor - 1.0)
  } else {
    principal / totalMonths
  }

  val totalPaymentUsd = (monthlyPaymentUsd * totalMonths) + downPaymentAmount
  val totalInterestUsd = totalPaymentUsd - price
  val monthlyPaymentIqd = monthlyPaymentUsd * 1500.0

  val numberFormat = NumberFormat.getNumberInstance(Locale.US).apply {
    maximumFractionDigits = 0
  }

  val yearsWord = when (appLanguage) {
    AppLanguage.BADINI, AppLanguage.SORANI -> "ساڵ"
    AppLanguage.ARABIC -> "سنوات"
    AppLanguage.ENGLISH -> "Years"
  }
  val monthsWord = when (appLanguage) {
    AppLanguage.BADINI, AppLanguage.SORANI -> "مەهـ"
    AppLanguage.ARABIC -> "شهر"
    AppLanguage.ENGLISH -> "months"
  }
  val daftarsWord = when (appLanguage) {
    AppLanguage.BADINI, AppLanguage.SORANI -> "دەفتەر"
    AppLanguage.ARABIC -> "دفتر"
    AppLanguage.ENGLISH -> "Daftars"
  }

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = MaterialTheme.colorScheme.surface,
    shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
    modifier = Modifier.testTag("mortgage_calculator_sheet")
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .verticalScroll(rememberScrollState())
        .padding(horizontal = 20.dp)
        .padding(bottom = 32.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      // Top Bar
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Surface(
            shape = CircleShape,
            color = EmeraldPrimary.copy(alpha = 0.15f),
            modifier = Modifier.size(38.dp)
          ) {
            Box(contentAlignment = Alignment.Center) {
              Icon(
                imageVector = Icons.Default.Calculate,
                contentDescription = null,
                tint = EmeraldPrimary,
                modifier = Modifier.size(22.dp)
              )
            }
          }
          Column {
            Text(
              text = strings.financeTitle,
              fontSize = 17.sp,
              fontWeight = FontWeight.Black,
              color = MaterialTheme.colorScheme.onSurface
            )
            Text(
              text = "حاسیبا پێشکەفتی یا قەر و قیستێن دهۆکێ",
              fontSize = 11.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }

        IconButton(onClick = onDismiss) {
          Icon(Icons.Default.Close, contentDescription = "Close")
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // 1. DIGITAL CALCULATOR RESULT CARD
      Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = EmeraldDark),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .background(
              Brush.verticalGradient(
                colors = listOf(EmeraldDark, Color(0xFF0F3D2E))
              )
            )
            .padding(18.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Text(
            text = strings.estimatedMonthlyInstallment,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = GoldPrimary,
            letterSpacing = 1.sp
          )

          Spacer(modifier = Modifier.height(6.dp))

          // Monthly Installment in USD
          Text(
            text = "$${numberFormat.format(monthlyPaymentUsd)}",
            fontSize = 36.sp,
            fontWeight = FontWeight.Black,
            color = Color.White,
            fontFamily = FontFamily.SansSerif
          )

          Text(
            text = "/ $monthsWord (هەر مەهەکێ)",
            fontSize = 12.sp,
            color = Color.White.copy(alpha = 0.7f)
          )

          Spacer(modifier = Modifier.height(10.dp))

          // Iraqi Dinar & Daftars Equivalence
          Surface(
            shape = RoundedCornerShape(12.dp),
            color = Color.Black.copy(alpha = 0.3f),
            modifier = Modifier.padding(horizontal = 8.dp)
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
              horizontalArrangement = Arrangement.spacedBy(12.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = "${numberFormat.format(monthlyPaymentIqd)} IQD",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
              )
              Text(text = "•", color = GoldPrimary)
              Text(
                text = "${String.format(Locale.US, "%.2f", monthlyPaymentUsd / 10000.0)} $daftarsWord",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = GoldPrimary
              )
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          // 3-Column Summary KPIs (Loan Principal, Down Payment, Total Repayment)
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Text("کۆژمێ قەری", fontSize = 10.sp, color = Color.White.copy(alpha = 0.7f))
              Text("$${numberFormat.format(principal)}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Text("پێشەکی (${downPaymentPercent.toInt()}%)", fontSize = 10.sp, color = Color.White.copy(alpha = 0.7f))
              Text("$${numberFormat.format(downPaymentAmount)}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = GoldPrimary)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Text("کۆما گشتی", fontSize = 10.sp, color = Color.White.copy(alpha = 0.7f))
              Text("$${numberFormat.format(totalPaymentUsd)}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      // 2. INTERACTIVE CALCULATOR KEYPAD & PRESETS FOR PROPERTY PRICE
      Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = strings.propertyPrice,
              fontSize = 13.sp,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onSurface
            )
            Text(
              text = "$${numberFormat.format(price)} (${String.format(Locale.US, "%.1f", price / 10000.0)} $daftarsWord)",
              fontSize = 14.sp,
              fontWeight = FontWeight.Black,
              color = EmeraldPrimary
            )
          }

          Spacer(modifier = Modifier.height(10.dp))

          // Quick calculator add buttons (+10k, +50k, +100k, Daftars, Reset)
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            listOf(
              "+10K $" to 10000.0,
              "+25K $" to 25000.0,
              "+50K $" to 50000.0,
              "+10 دەفتەر" to 100000.0,
              "+20 دەفتەر" to 200000.0
            ).forEach { (label, addAmount) ->
              Surface(
                shape = RoundedCornerShape(10.dp),
                color = EmeraldPrimary.copy(alpha = 0.12f),
                modifier = Modifier
                  .clip(RoundedCornerShape(10.dp))
                  .clickable { price += addAmount }
              ) {
                Text(
                  text = label,
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  color = EmeraldPrimary,
                  modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                )
              }
            }

            Surface(
              shape = RoundedCornerShape(10.dp),
              color = MaterialTheme.colorScheme.error.copy(alpha = 0.12f),
              modifier = Modifier
                .clip(RoundedCornerShape(10.dp))
                .clickable { price = 100000.0 }
            ) {
              Text(
                text = "C (10 دەفتەر)",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // 3. DOWN PAYMENT SELECTOR (پێشەکی)
      Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = strings.downPayment,
              fontSize = 13.sp,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onSurface
            )
            Text(
              text = "$${numberFormat.format(downPaymentAmount)} (${downPaymentPercent.toInt()}%)",
              fontSize = 13.sp,
              fontWeight = FontWeight.Black,
              color = GoldPrimary
            )
          }

          Spacer(modifier = Modifier.height(10.dp))

          // Percentage chips
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            listOf(0f, 10f, 20f, 30f, 50f).forEach { pct ->
              val isSelected = downPaymentPercent == pct
              Surface(
                shape = RoundedCornerShape(10.dp),
                color = if (isSelected) GoldPrimary else MaterialTheme.colorScheme.surface,
                border = if (isSelected) null else androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
                modifier = Modifier
                  .weight(1f)
                  .clip(RoundedCornerShape(10.dp))
                  .clickable { downPaymentPercent = pct }
              ) {
                Box(
                  modifier = Modifier.padding(vertical = 8.dp),
                  contentAlignment = Alignment.Center
                ) {
                  Text(
                    text = "${pct.toInt()}%",
                    fontSize = 12.sp,
                    fontWeight = if (isSelected) FontWeight.Black else FontWeight.SemiBold,
                    color = if (isSelected) EmeraldDark else MaterialTheme.colorScheme.onSurface
                  )
                }
              }
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // 4. LOAN DURATION (ماوێ قستان ب سالان)
      Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = strings.loanPeriod,
              fontSize = 13.sp,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onSurface
            )
            Text(
              text = "$loanTenureYears $yearsWord ($totalMonths $monthsWord)",
              fontSize = 13.sp,
              fontWeight = FontWeight.Black,
              color = EmeraldPrimary
            )
          }

          Spacer(modifier = Modifier.height(10.dp))

          // Year chips
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            listOf(1, 3, 5, 10, 15, 20).forEach { yr ->
              val isSelected = loanTenureYears == yr
              Surface(
                shape = RoundedCornerShape(10.dp),
                color = if (isSelected) EmeraldPrimary else MaterialTheme.colorScheme.surface,
                border = if (isSelected) null else androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
                modifier = Modifier
                  .weight(1f)
                  .clip(RoundedCornerShape(10.dp))
                  .clickable { loanTenureYears = yr }
              ) {
                Box(
                  modifier = Modifier.padding(vertical = 8.dp),
                  contentAlignment = Alignment.Center
                ) {
                  Text(
                    text = "$yr $yearsWord",
                    fontSize = 11.sp,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                    color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                  )
                }
              }
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // 5. DETAILED INSIGHTS BREAKDOWN CARD (پێزانینێن هویر یێن قستان)
      Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = EmeraldPrimary.copy(alpha = 0.08f)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(
          modifier = Modifier.padding(14.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            Icon(Icons.Outlined.Info, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(16.dp))
            Text("پێزانینێن قەر و قیستێن تە ل دهۆکێ", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = EmeraldDark)
          }

          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("کۆژمێ پارەیێ مایی بۆ قیستان:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("$${numberFormat.format(principal)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
          }

          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("رێژەیا فایدەیێ سالانە:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("${annualInterestRate}%", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
          }

          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("کۆژمێ هەمی فایدەی ل درێژاهیا دەمی:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("$${numberFormat.format(totalInterestUsd)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GoldPrimary)
          }

          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("تەواوی قیستێن سالانە:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("$${numberFormat.format(monthlyPaymentUsd * 12.0)} / ساڵ", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = EmeraldPrimary)
          }

          Spacer(modifier = Modifier.height(4.dp))

          // Progress visual bar: Principal vs Interest
          val progressRatio = (principal / totalPaymentUsd).toFloat().coerceIn(0f, 1f)
          LinearProgressIndicator(
            progress = { progressRatio },
            modifier = Modifier
              .fillMaxWidth()
              .height(8.dp)
              .clip(RoundedCornerShape(4.dp)),
            color = EmeraldPrimary,
            trackColor = GoldPrimary
          )
        }
      }

      Spacer(modifier = Modifier.height(18.dp))

      // Direct WhatsApp Inquiry with loan calculation details
      Button(
        onClick = {
          val cleanPhone = officePhone.trim().removePrefix("0")
          val intlPhone = if (cleanPhone.startsWith("+")) cleanPhone else "+964$cleanPhone"
          val message = Uri.encode(
            "سڵاو ناڤەندا خانووبەرێن دهۆکێ، ئەز دخوازم دەربارەی قستێن خانووبەرەی بزانم:\n" +
              "• بهایێ گشتی: $${numberFormat.format(price)}\n" +
              "• پێشەکی (${downPaymentPercent.toInt()}%): $${numberFormat.format(downPaymentAmount)}\n" +
              "• قستا مەهانە: $${numberFormat.format(monthlyPaymentUsd)}\n" +
              "• ماوێ قستان: $loanTenureYears ساڵ\nسوپاس!"
          )
          val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$intlPhone?text=$message"))
          try {
            context.startActivity(intent)
          } catch (_: Exception) {}
        },
        modifier = Modifier
          .fillMaxWidth()
          .height(52.dp)
          .testTag("inquire_mortgage_whatsapp_btn"),
        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
        shape = RoundedCornerShape(14.dp)
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.Center
        ) {
          Icon(Icons.Outlined.Chat, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "داواکرنا قستان ب رێکا WhatsApp",
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            color = Color.White
          )
        }
      }
    }
  }
}
