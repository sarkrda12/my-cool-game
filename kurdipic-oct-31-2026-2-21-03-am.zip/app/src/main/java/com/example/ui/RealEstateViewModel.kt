package com.example.ui

import androidx.lifecycle.ViewModel
import android.content.Context
import com.example.data.PropertyStorage
import com.example.data.SampleProperties
import com.example.data.UserProfile
import com.example.data.model.AppLanguage
import com.example.data.model.CurrencyMode
import com.example.data.model.ListingType
import com.example.data.model.Property
import com.example.data.model.PropertyType
import com.example.data.model.VisitBooking
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

enum class NavigationDestination {
  HOME,
  EXPLORE_SEARCH,
  FAVORITES,
  MORTGAGE_CALC,
  PROPERTY_DETAILS,
  MANAGE,
  SCHEDULE_VISIT
}

data class FilterState(
  val searchQuery: String = "",
  val selectedType: PropertyType = PropertyType.ALL,
  val selectedListingType: ListingType? = null,
  val selectedNeighborhood: String = "All Duhok",
  val minPriceUsd: Double = 0.0,
  val maxPriceUsd: Double = 1_000_000.0,
  val minBedrooms: Int = 0,
  val minBathrooms: Int = 0,
  val minAreaSqm: Int = 0,
  val tapuOnly: Boolean = false,
  val sortBy: SortOption = SortOption.RECOMMENDED
)

enum class SortOption(
  val titleEn: String,
  val titleBadini: String,
  val titleSorani: String,
  val titleArabic: String
) {
  RECOMMENDED("Featured First", "خانووبەرێن تایبەت ل دەستپێکێ", "تایبەتەکان لە سەرەتا", "المميزة أولاً"),
  PRICE_LOW_TO_HIGH("Price: Low to High", "بها: ژ کێمترین بۆ زۆرترین", "نرخ: کەمترین بۆ زۆرترین", "السعر: من الأقل للأعلى"),
  PRICE_HIGH_TO_LOW("Price: High to Low", "بها: ژ زۆرترین بۆ کێمترین", "نرخ: زۆرترین بۆ کەمترین", "السعر: من الأعلى للأقل"),
  AREA_LARGE_TO_SMALL("Area: Largest First", "رووبەر: یێ مەزن ل دەستپێکێ", "ڕووبەر: گەورەترین سەرەتا", "المساحة: الأكبر أولاً");

  fun getTitle(lang: AppLanguage): String = when (lang) {
    AppLanguage.BADINI -> titleBadini
    AppLanguage.SORANI -> titleSorani
    AppLanguage.ARABIC -> titleArabic
    AppLanguage.ENGLISH -> titleEn
  }
}

data class RealEstateUiState(
  val properties: List<Property> = emptyList(),
  val filterState: FilterState = FilterState(),
  val currencyMode: CurrencyMode = CurrencyMode.USD,
  val appLanguage: AppLanguage = AppLanguage.BADINI, // Default to Badini (Duhok)
  val showLanguageDialog: Boolean = false,
  val selectedPropertyId: String? = null,
  val currentScreen: NavigationDestination = NavigationDestination.HOME,
  val showOnboarding: Boolean = false,
  val visitBookings: List<VisitBooking> = emptyList(),
  val showBookingSuccessDialog: Boolean = false,
  val lastBookedVisit: VisitBooking? = null,
  val isManageUnlocked: Boolean = false,
  val officePhone: String = "07514036954",
  val officeWhatsapp: String = "+9647514036954",
  val officeName: String = "The Duhok-Aqar",
  val userProfile: UserProfile? = null,
  val showGoogleSignInDialog: Boolean = false,
  val customNeighborhoods: List<String> = emptyList(),
  val registeredUsers: List<UserProfile> = emptyList(),
  val appAnnouncement: String = "بخێرهاتن بۆ ناڤەندا فەرمی یا خانووبەرێن دهۆکێ",
  val loanInterestRate: Float = 5.0f
)

class RealEstateViewModel : ViewModel() {

  companion object {
    const val ADMIN_PASSCODE = "DUHOK-AQAR-VIP-REVABAR98"
  }

  private var appContext: Context? = null
  private val _uiState = MutableStateFlow(RealEstateUiState())
  val uiState: StateFlow<RealEstateUiState> = _uiState.asStateFlow()

  fun initStorage(context: Context) {
    this.appContext = context.applicationContext
    val savedProps = PropertyStorage.loadProperties(context)
    val savedPhone = PropertyStorage.loadOfficePhone(context)
    val savedName = PropertyStorage.loadOfficeName(context)
    val savedProfile = PropertyStorage.loadUserProfile(context)
    val savedNeighborhoods = PropertyStorage.loadCustomNeighborhoods(context)
    val savedUsers = PropertyStorage.loadRegisteredUsers(context)
    val savedAnnouncement = PropertyStorage.loadAppAnnouncement(context)

    _uiState.update { current ->
      current.copy(
        properties = savedProps ?: current.properties,
        officePhone = savedPhone,
        officeName = savedName,
        userProfile = savedProfile,
        showGoogleSignInDialog = (savedProfile == null),
        customNeighborhoods = savedNeighborhoods,
        registeredUsers = savedUsers,
        appAnnouncement = savedAnnouncement
      )
    }
  }

  fun signInWithGoogle(name: String, email: String, photoUrl: String = "") {
    val cleanName = name.trim().ifBlank { "User" }
    val cleanEmail = email.trim().ifBlank { "user@gmail.com" }
    val profile = UserProfile(
      name = cleanName,
      email = cleanEmail,
      age = _uiState.value.userProfile?.age ?: 25,
      password = _uiState.value.userProfile?.password ?: "",
      photoUrl = photoUrl,
      isSignedIn = true
    )
    appContext?.let { PropertyStorage.saveUserProfile(it, profile) }
    _uiState.update { state ->
      val existing = state.registeredUsers.filterNot { it.email.equals(cleanEmail, ignoreCase = true) }
      val updatedList = listOf(profile) + existing
      appContext?.let { PropertyStorage.saveRegisteredUsers(it, updatedList) }
      state.copy(
        userProfile = profile,
        showGoogleSignInDialog = false,
        registeredUsers = updatedList
      )
    }
  }

  fun createOrUpdateAccount(name: String, email: String, age: Int, password: String, photoUrl: String = "") {
    val cleanName = name.trim().ifBlank { "User" }
    val cleanEmail = email.trim().ifBlank { "user@gmail.com" }
    val validAge = if (age in 10..120) age else 25
    val profile = UserProfile(
      name = cleanName,
      email = cleanEmail,
      age = validAge,
      password = password.trim(),
      photoUrl = photoUrl,
      isSignedIn = true,
      registeredDate = "2026-10-30"
    )
    appContext?.let { PropertyStorage.saveUserProfile(it, profile) }
    _uiState.update { state ->
      val existing = state.registeredUsers.filterNot { it.email.equals(cleanEmail, ignoreCase = true) }
      val updatedList = listOf(profile) + existing
      appContext?.let { PropertyStorage.saveRegisteredUsers(it, updatedList) }
      state.copy(
        userProfile = profile,
        showGoogleSignInDialog = false,
        registeredUsers = updatedList
      )
    }
  }

  fun deleteUserAccount(userEmail: String) {
    _uiState.update { state ->
      val filtered = state.registeredUsers.filterNot { it.email.equals(userEmail, ignoreCase = true) }
      appContext?.let { PropertyStorage.saveRegisteredUsers(it, filtered) }
      state.copy(registeredUsers = filtered)
    }
  }

  fun updateMasterSettings(
    newOfficeName: String,
    newOfficePhone: String,
    newWhatsapp: String,
    newAnnouncement: String,
    defaultCurrency: CurrencyMode,
    interestRate: Float
  ) {
    val phone = newOfficePhone.trim().ifBlank { "07514036954" }
    val name = newOfficeName.trim().ifBlank { "The Duhok-Aqar" }
    val announcement = newAnnouncement.trim().ifBlank { "بخێرهاتن بۆ ناڤەندا فەرمی یا خانووبەرێن دهۆکێ" }
    val cleanWhatsapp = if (newWhatsapp.isNotBlank()) newWhatsapp.trim() else "+9647514036954"

    appContext?.let {
      PropertyStorage.saveOfficeInfo(it, phone, name)
      PropertyStorage.saveAppAnnouncement(it, announcement)
    }

    _uiState.update { state ->
      val updatedProps = state.properties.map { prop ->
        prop.copy(
          agent = prop.agent.copy(
            phone = phone,
            whatsapp = cleanWhatsapp
          )
        )
      }
      appContext?.let { PropertyStorage.saveProperties(it, updatedProps) }
      state.copy(
        officeName = name,
        officePhone = phone,
        officeWhatsapp = cleanWhatsapp,
        appAnnouncement = announcement,
        currencyMode = defaultCurrency,
        loanInterestRate = interestRate,
        properties = updatedProps
      )
    }
  }

  fun signOut() {
    appContext?.let { PropertyStorage.clearUserProfile(it) }
    _uiState.update { it.copy(userProfile = null) }
  }

  fun toggleGoogleSignInDialog(show: Boolean) {
    _uiState.update { it.copy(showGoogleSignInDialog = show) }
  }

  fun addCustomNeighborhood(placeName: String): Boolean {
    val trimmed = placeName.trim()
    if (trimmed.isBlank()) return false
    val current = _uiState.value.customNeighborhoods
    if (current.any { it.equals(trimmed, ignoreCase = true) }) return false
    val updated = current + trimmed
    appContext?.let { PropertyStorage.saveCustomNeighborhoods(it, updated) }
    _uiState.update { it.copy(customNeighborhoods = updated) }
    return true
  }

  fun getAllNeighborhoods(): List<String> {
    val list = mutableListOf("All Duhok")
    val defaults = listOf(
      "Malta", "Masik", "Avro City", "Gre Basi", "Azadi", "Shorsh", "KRO", "Nizarke",
      "Zawita", "Semel", "Shakhke", "Baroshke", "Duhok Mall"
    )
    defaults.forEach {
      if (!list.contains(it)) list.add(it)
    }
    _uiState.value.customNeighborhoods.forEach { place ->
      if (!list.any { it.equals(place, ignoreCase = true) }) {
        list.add(place)
      }
    }
    _uiState.value.properties.forEach { prop ->
      val name = prop.neighborhoodEn.trim()
      if (name.isNotBlank() && !list.any { it.equals(name, ignoreCase = true) }) {
        list.add(name)
      }
    }
    return list
  }

  fun unlockManage(passcode: String): Boolean {
    val isMatch = passcode.trim() == ADMIN_PASSCODE
    if (isMatch) {
      _uiState.update { it.copy(isManageUnlocked = true) }
    }
    return isMatch
  }

  fun lockManage() {
    _uiState.update { it.copy(isManageUnlocked = false, currentScreen = NavigationDestination.HOME) }
  }

  fun navigateTo(destination: NavigationDestination) {
    _uiState.update { it.copy(currentScreen = destination) }
  }

  fun setLanguage(language: AppLanguage) {
    _uiState.update { it.copy(appLanguage = language, showLanguageDialog = false) }
  }

  fun toggleLanguageDialog(show: Boolean) {
    _uiState.update { it.copy(showLanguageDialog = show) }
  }

  fun selectProperty(propertyId: String) {
    _uiState.update {
      it.copy(
        selectedPropertyId = propertyId,
        currentScreen = NavigationDestination.PROPERTY_DETAILS
      )
    }
  }

  fun addProperty(property: Property) {
    _uiState.update { state ->
      val updated = listOf(property) + state.properties
      appContext?.let { PropertyStorage.saveProperties(it, updated) }
      state.copy(
        properties = updated,
        currentScreen = NavigationDestination.HOME
      )
    }
  }

  fun updateProperty(updatedProperty: Property) {
    _uiState.update { state ->
      val updatedList = state.properties.map { prop ->
        if (prop.id == updatedProperty.id) updatedProperty else prop
      }
      appContext?.let { PropertyStorage.saveProperties(it, updatedList) }
      state.copy(properties = updatedList)
    }
  }

  fun updateOfficeInfo(phone: String, name: String) {
    val cleanPhone = phone.trim()
    val cleanName = name.trim()
    _uiState.update { state ->
      val updatedProperties = state.properties.map { prop ->
        prop.copy(
          agent = prop.agent.copy(
            phone = cleanPhone,
            whatsapp = if (cleanPhone.startsWith("+")) cleanPhone else "+964" + cleanPhone.removePrefix("0"),
            agency = if (cleanName.isNotBlank()) cleanName else prop.agent.agency
          )
        )
      }
      appContext?.let {
        PropertyStorage.saveProperties(it, updatedProperties)
        PropertyStorage.saveOfficeInfo(it, cleanPhone, cleanName)
      }
      state.copy(
        officePhone = cleanPhone,
        officeName = cleanName,
        properties = updatedProperties
      )
    }
  }

  fun deleteProperty(propertyId: String) {
    _uiState.update { state ->
      val updated = state.properties.filterNot { it.id == propertyId }
      appContext?.let { PropertyStorage.saveProperties(it, updated) }
      state.copy(
        properties = updated,
        selectedPropertyId = if (state.selectedPropertyId == propertyId) null else state.selectedPropertyId
      )
    }
  }

  fun clearAllProperties() {
    _uiState.update { state ->
      appContext?.let { PropertyStorage.saveProperties(it, emptyList()) }
      state.copy(properties = emptyList())
    }
  }

  fun loadDemoProperties() {
    _uiState.update { state ->
      appContext?.let { PropertyStorage.saveProperties(it, SampleProperties.properties) }
      state.copy(properties = SampleProperties.properties)
    }
  }

  fun toggleFavorite(propertyId: String) {
    _uiState.update { state ->
      val updated = state.properties.map { prop ->
        if (prop.id == propertyId) {
          prop.copy(isFavorite = !prop.isFavorite)
        } else {
          prop
        }
      }
      appContext?.let { PropertyStorage.saveProperties(it, updated) }
      state.copy(properties = updated)
    }
  }

  fun cycleCurrency() {
    _uiState.update { state ->
      val next = when (state.currencyMode) {
        CurrencyMode.USD -> CurrencyMode.DAFTAR
        CurrencyMode.DAFTAR -> CurrencyMode.IQD
        CurrencyMode.IQD -> CurrencyMode.USD
      }
      state.copy(currencyMode = next)
    }
  }

  fun setCurrency(mode: CurrencyMode) {
    _uiState.update { it.copy(currencyMode = mode) }
  }

  fun updateSearchQuery(query: String) {
    _uiState.update { state ->
      state.copy(filterState = state.filterState.copy(searchQuery = query))
    }
  }

  fun updatePropertyType(type: PropertyType) {
    _uiState.update { state ->
      state.copy(filterState = state.filterState.copy(selectedType = type))
    }
  }

  fun updateListingType(listingType: ListingType?) {
    _uiState.update { state ->
      state.copy(filterState = state.filterState.copy(selectedListingType = listingType))
    }
  }

  fun updateNeighborhood(neighborhood: String) {
    _uiState.update { state ->
      state.copy(filterState = state.filterState.copy(selectedNeighborhood = neighborhood))
    }
  }

  fun updatePriceRange(min: Double, max: Double) {
    _uiState.update { state ->
      state.copy(filterState = state.filterState.copy(minPriceUsd = min, maxPriceUsd = max))
    }
  }

  fun updateMinBedrooms(bedrooms: Int) {
    _uiState.update { state ->
      state.copy(filterState = state.filterState.copy(minBedrooms = bedrooms))
    }
  }

  fun updateMinBathrooms(bathrooms: Int) {
    _uiState.update { state ->
      state.copy(filterState = state.filterState.copy(minBathrooms = bathrooms))
    }
  }

  fun updateTapuOnly(tapuOnly: Boolean) {
    _uiState.update { state ->
      state.copy(filterState = state.filterState.copy(tapuOnly = tapuOnly))
    }
  }

  fun updateSortBy(sortOption: SortOption) {
    _uiState.update { state ->
      state.copy(filterState = state.filterState.copy(sortBy = sortOption))
    }
  }

  fun resetFilters() {
    _uiState.update { state ->
      state.copy(filterState = FilterState())
    }
  }

  fun scheduleVisit(booking: VisitBooking) {
    _uiState.update { state ->
      state.copy(
        visitBookings = state.visitBookings + booking,
        showBookingSuccessDialog = true,
        lastBookedVisit = booking
      )
    }
  }

  fun dismissBookingSuccess() {
    _uiState.update { it.copy(showBookingSuccessDialog = false) }
  }

  fun toggleOnboarding(show: Boolean) {
    _uiState.update { it.copy(showOnboarding = show) }
  }

  fun getFilteredProperties(): List<Property> {
    val state = _uiState.value
    val filters = state.filterState

    return state.properties
      .filter { prop ->
        val matchesSearch = if (filters.searchQuery.isBlank()) {
          true
        } else {
          val q = filters.searchQuery.trim().lowercase()
          prop.titleEn.lowercase().contains(q) ||
            prop.titleBadini.contains(q) ||
            prop.titleSorani.contains(q) ||
            prop.titleArabic.contains(q) ||
            prop.neighborhoodEn.lowercase().contains(q) ||
            prop.neighborhoodKu.contains(q) ||
            prop.neighborhoodArabic.contains(q) ||
            prop.descriptionEn.lowercase().contains(q) ||
            prop.descriptionBadini.contains(q) ||
            prop.descriptionSorani.contains(q) ||
            prop.descriptionArabic.contains(q) ||
            prop.amenities.any { it.lowercase().contains(q) }
        }

        val matchesType = filters.selectedType == PropertyType.ALL || prop.type == filters.selectedType
        val matchesListing = filters.selectedListingType == null || prop.listingType == filters.selectedListingType
        val matchesNeighborhood = filters.selectedNeighborhood == "All Duhok" ||
          prop.neighborhoodEn.equals(filters.selectedNeighborhood, ignoreCase = true) ||
          prop.neighborhoodKu.equals(filters.selectedNeighborhood, ignoreCase = true)

        val matchesPrice = prop.priceUsd in filters.minPriceUsd..filters.maxPriceUsd
        val matchesBedrooms = filters.minBedrooms == 0 || prop.bedrooms >= filters.minBedrooms
        val matchesBathrooms = filters.minBathrooms == 0 || prop.bathrooms >= filters.minBathrooms
        val matchesArea = filters.minAreaSqm == 0 || prop.areaSqm >= filters.minAreaSqm
        val matchesTapu = !filters.tapuOnly || prop.isTapuVerified

        matchesSearch && matchesType && matchesListing && matchesNeighborhood &&
          matchesPrice && matchesBedrooms && matchesBathrooms && matchesArea && matchesTapu
      }
      .let { list ->
        when (filters.sortBy) {
          SortOption.RECOMMENDED -> list.sortedByDescending { it.isFeatured }
          SortOption.PRICE_LOW_TO_HIGH -> list.sortedBy { it.priceUsd }
          SortOption.PRICE_HIGH_TO_LOW -> list.sortedByDescending { it.priceUsd }
          SortOption.AREA_LARGE_TO_SMALL -> list.sortedByDescending { it.areaSqm }
        }
      }
  }
}
