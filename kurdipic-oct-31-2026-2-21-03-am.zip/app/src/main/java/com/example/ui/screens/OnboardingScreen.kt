package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.AppLanguage
import com.example.data.model.LocaleStrings
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.GoldPrimary

@Composable
fun OnboardingScreen(
  appLanguage: AppLanguage,
  onLanguageToggle: () -> Unit,
  onGetStarted: () -> Unit,
  modifier: Modifier = Modifier
) {
  val strings = LocaleStrings.get(appLanguage)

  val (mainHeading, subHeading) = when (appLanguage) {
    AppLanguage.BADINI -> Pair(
      "خانووبەرێ خەونا تە ل دهۆکێ",
      "خانووبەرێن دهۆکێ • ڤێلا، شوقێن لوکس و ئەردێ تاپۆیا باوەرپێکری"
    )
    AppLanguage.SORANI -> Pair(
      "خانووبەرەی خەونەکانت لە دهۆک",
      "خانووبەرەکانی دهۆک • ڤێلا، شوقەی لوکس و زەوی بە تاپۆی پەسەندکراو"
    )
    AppLanguage.ARABIC -> Pair(
      "اعثر على عقار أحلامك في دهوك",
      "عقارات دهوك • فلل وشقق راقية وأراضٍ بطابو ملك رسمي موثق"
    )
    AppLanguage.ENGLISH -> Pair(
      "Find Your Dream Residence in Duhok",
      "The Duhok-Aqar • Villas, Luxury Apartments, and Prime Land with verified Tapu deeds."
    )
  }

  val skipText = when (appLanguage) {
    AppLanguage.BADINI, AppLanguage.SORANI -> "دەربازبوون"
    AppLanguage.ARABIC -> "تخطي"
    AppLanguage.ENGLISH -> "Skip"
  }

  val p1 = when (appLanguage) {
    AppLanguage.BADINI -> Pair("تاپۆیا فەرمی یا باوەرپێکری", "تۆمارکری ل ڕێڤەبەریا تاپۆیا دهۆکێ")
    AppLanguage.SORANI -> Pair("تاپۆی فەرمی پەسەندکراو", "تۆمارکراو لە بەڕێوەبەرایەتی تۆماری دهۆک")
    AppLanguage.ARABIC -> Pair("طابو رسمي موثق", "مسجل رسمياً لدى مديرية التسجيل العقاري")
    AppLanguage.ENGLISH -> Pair("Verified Tapu Deeds", "Official registration with Duhok Real Estate Directorate")
  }

  val p2 = when (appLanguage) {
    AppLanguage.BADINI -> Pair("گەرەکێن سەرەکی یێن دهۆکێ", "مالتا، ماسیک، گرێ باسی، ئەڤرۆ ستی و ئازادی")
    AppLanguage.SORANI -> Pair("گەڕەکە سەرەکییەکانی دهۆک", "ماڵتا، ماسیک، گرێ باسی، ئەڤرۆ ستی و ئازادی")
    AppLanguage.ARABIC -> Pair("أرقى أحياء دهوك", "مالطا، ماسيك، كري باسي، أفرو سيتي وآزادي")
    AppLanguage.ENGLISH -> Pair("Top Duhok Neighborhoods", "Malta, Masik, Gre Basi, Avro City, Azadi & Shorsh")
  }

  val p3 = when (appLanguage) {
    AppLanguage.BADINI -> Pair("پەیوەندی ڕاستەوخۆ دگەل بریکاری", "واتسئەپ، تەلەفۆن و ژڤانێ دیتنێ سەر عەردی")
    AppLanguage.SORANI -> Pair("پەیوەندی ڕاستەوخۆ لەگەڵ بریکار", "واتسئەپ، پەیوەندی و دیاریکردنی کاتی سەردان")
    AppLanguage.ARABIC -> Pair("تواصل مباشر مع الوكلاء", "واتساب، اتصال هاتفي وحجز موعد معاينة ميدانية")
    AppLanguage.ENGLISH -> Pair("Direct Agent Connection", "Instant WhatsApp, Call & On-Site Guided Visits")
  }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(EmeraldDark)
      .testTag("onboarding_screen")
  ) {
    // Background hero image
    Image(
      painter = painterResource(id = R.drawable.img_hero_duhok),
      contentDescription = null,
      modifier = Modifier
        .fillMaxWidth()
        .height(440.dp),
      contentScale = ContentScale.Crop
    )

    // Dark gradient overlay
    Box(
      modifier = Modifier
        .fillMaxSize()
        .background(
          Brush.verticalGradient(
            colors = listOf(
              EmeraldDark.copy(alpha = 0.4f),
              EmeraldDark.copy(alpha = 0.85f),
              EmeraldDark
            ),
            startY = 100f
          )
        )
    )

    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(24.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.SpaceBetween
    ) {
      // Top Brand Header & Language Switcher
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(top = 28.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Surface(
          shape = RoundedCornerShape(12.dp),
          color = Color.Black.copy(alpha = 0.4f),
          border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.4f))
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            Image(
              painter = painterResource(id = R.drawable.img_logo_gold),
              contentDescription = "Logo",
              modifier = Modifier
                .size(24.dp)
                .clip(CircleShape)
            )
            Text(
              text = strings.appTitle,
              fontWeight = FontWeight.Bold,
              color = Color.White,
              fontSize = 13.sp
            )
          }
        }

        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = GoldPrimary.copy(alpha = 0.2f),
            modifier = Modifier
              .clip(RoundedCornerShape(10.dp))
              .clickable(onClick = onLanguageToggle)
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
              Icon(
                imageVector = Icons.Default.Language,
                contentDescription = "Language",
                tint = GoldPrimary,
                modifier = Modifier.size(15.dp)
              )
              Text(
                text = appLanguage.code.uppercase(),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = GoldPrimary
              )
            }
          }

          TextButton(onClick = onGetStarted) {
            Text(skipText, color = Color.White.copy(alpha = 0.8f), fontSize = 14.sp)
          }
        }
      }

      // Center Core Pitch
      Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Surface(
          shape = RoundedCornerShape(16.dp),
          color = GoldPrimary.copy(alpha = 0.15f),
          border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary)
        ) {
          Text(
            text = "DUHOK & KURDISTAN PREMIER REAL ESTATE",
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
            color = GoldPrimary,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
          )
        }

        Spacer(modifier = Modifier.height(14.dp))

        Text(
          text = mainHeading,
          fontSize = 26.sp,
          fontWeight = FontWeight.ExtraBold,
          color = Color.White,
          textAlign = TextAlign.Center,
          lineHeight = 34.sp
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
          text = subHeading,
          fontSize = 13.sp,
          color = Color.White.copy(alpha = 0.85f),
          textAlign = TextAlign.Center,
          lineHeight = 20.sp
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Three Value Pillars
        PillarItem(icon = Icons.Default.Shield, title = p1.first, subtitle = p1.second)
        Spacer(modifier = Modifier.height(8.dp))
        PillarItem(icon = Icons.Default.Home, title = p2.first, subtitle = p2.second)
        Spacer(modifier = Modifier.height(8.dp))
        PillarItem(icon = Icons.Default.SupportAgent, title = p3.first, subtitle = p3.second)
      }

      // Bottom CTA Button
      Button(
        onClick = onGetStarted,
        modifier = Modifier
          .fillMaxWidth()
          .height(56.dp)
          .testTag("onboarding_get_started_button"),
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary)
      ) {
        Text(
          text = strings.exploreDuhokBtn,
          fontWeight = FontWeight.Bold,
          fontSize = 15.sp,
          color = EmeraldDark
        )
        Spacer(modifier = Modifier.width(8.dp))
        Icon(
          imageVector = androidx.compose.material.icons.Icons.AutoMirrored.Filled.ArrowForward,
          contentDescription = null,
          tint = EmeraldDark
        )
      }
    }
  }
}

@Composable
private fun PillarItem(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  title: String,
  subtitle: String
) {
  Card(
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.08f)),
    modifier = Modifier.fillMaxWidth()
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Surface(
        shape = CircleShape,
        color = EmeraldPrimary,
        modifier = Modifier.size(36.dp)
      ) {
        Box(contentAlignment = Alignment.Center) {
          Icon(
            imageVector = icon,
            contentDescription = null,
            tint = GoldPrimary,
            modifier = Modifier.size(20.dp)
          )
        }
      }
      Spacer(modifier = Modifier.width(12.dp))
      Column {
        Text(
          text = title,
          fontWeight = FontWeight.Bold,
          fontSize = 13.sp,
          color = Color.White
        )
        Text(
          text = subtitle,
          fontSize = 11.sp,
          color = Color.White.copy(alpha = 0.7f)
        )
      }
    }
  }
}
