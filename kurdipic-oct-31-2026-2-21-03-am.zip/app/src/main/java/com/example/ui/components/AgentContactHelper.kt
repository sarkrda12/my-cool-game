package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast

object AgentContactHelper {

  fun callAgent(context: Context, phoneNumber: String) {
    try {
      val intent = Intent(Intent.ACTION_DIAL).apply {
        data = Uri.parse("tel:$phoneNumber")
      }
      context.startActivity(intent)
    } catch (e: Exception) {
      Toast.makeText(context, "Could not open dialer: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
    }
  }

  fun openWhatsApp(context: Context, phoneNumber: String, propertyTitle: String) {
    try {
      val cleanNumber = phoneNumber.replace("+", "").replace(" ", "").replace("-", "")
      val message = Uri.encode("Hello! I am interested in '$propertyTitle' listed on The Duhok-Aqar app.")
      val url = "https://api.whatsapp.com/send?phone=$cleanNumber&text=$message"
      val intent = Intent(Intent.ACTION_VIEW).apply {
        data = Uri.parse(url)
      }
      context.startActivity(intent)
    } catch (e: Exception) {
      Toast.makeText(context, "Could not open WhatsApp: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
    }
  }
}
