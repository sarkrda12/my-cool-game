package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SampleProperties
import com.example.data.model.AppLanguage
import com.example.data.model.ListingType
import com.example.data.model.LocaleStrings
import com.example.data.model.PropertyType
import com.example.ui.FilterState
import com.example.ui.SortOption
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.GoldPrimary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchFilterScreen(
  filterState: FilterState,
  matchingCount: Int,
  allNeighborhoods: List<String> = emptyList(),
  appLanguage: AppLanguage = AppLanguage.BADINI,
  onSearchQueryChange: (String) -> Unit,
  onPropertyTypeChange: (PropertyType) -> Unit,
  onListingTypeChange: (ListingType?) -> Unit,
  onNeighborhoodChange: (String) -> Unit,
  onPriceRangeChange: (Double, Double) -> Unit,
  onMinBedroomsChange: (Int) -> Unit,
  onMinBathroomsChange: (Int) -> Unit,
  onTapuOnlyChange: (Boolean) -> Unit,
  onSortByChange: (SortOption) -> Unit,
  onResetFilters: () -> Unit,
  onApplyAndClose: () -> Unit,
  modifier: Modifier = Modifier
) {
  BackHandler(onBack = onApplyAndClose)

  val strings = LocaleStrings.get(appLanguage)

  val anyWord = when (appLanguage) {
    AppLanguage.BADINI -> "هەمی"
    AppLanguage.SORANI -> "هەموو"
    AppLanguage.ARABIC -> "الكل"
    AppLanguage.ENGLISH -> "Any"
  }
  val allNeighborhoodLabel = when (appLanguage) {
    AppLanguage.BADINI -> "هەمی دهۆک"
    AppLanguage.SORANI -> "هەموو دهۆک"
    AppLanguage.ARABIC -> "كل أحياء دهوك"
    AppLanguage.ENGLISH -> "All Duhok"
  }
  val daftarsWord = when (appLanguage) {
    AppLanguage.BADINI, AppLanguage.SORANI -> "دەفتەر"
    AppLanguage.ARABIC -> "دفتر"
    AppLanguage.ENGLISH -> "Daftars"
  }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .testTag("search_filter_screen")
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .verticalScroll(rememberScrollState())
        .padding(bottom = 90.dp)
    ) {
      // Top Navigation Bar
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(start = 12.dp, end = 20.dp, top = 20.dp, bottom = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          IconButton(onClick = onApplyAndClose, modifier = Modifier.testTag("filter_back_button")) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
          }
          Text(
            text = strings.advancedFilters,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
          )
        }
        TextButton(onClick = onResetFilters, modifier = Modifier.testTag("reset_filters_button")) {
          Icon(Icons.Default.RestartAlt, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text(strings.reset, color = EmeraldPrimary, fontWeight = FontWeight.SemiBold)
        }
      }

      // 1. Search Query Box
      OutlinedTextField(
        value = filterState.searchQuery,
        onValueChange = onSearchQueryChange,
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 20.dp, vertical = 6.dp)
          .testTag("filter_search_input"),
        placeholder = { Text(strings.searchPlaceholder, maxLines = 1) },
        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
        trailingIcon = {
          if (filterState.searchQuery.isNotEmpty()) {
            IconButton(onClick = { onSearchQueryChange("") }) {
              Icon(Icons.Default.Close, contentDescription = "Clear", modifier = Modifier.size(18.dp))
            }
          }
        },
        singleLine = true,
        shape = RoundedCornerShape(14.dp)
      )

      Spacer(modifier = Modifier.height(14.dp))

      // 2. Transaction Type (Buy / Rent)
      FilterSection(title = strings.listingPurpose) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          listOf(
            null to strings.allListings,
            ListingType.FOR_SALE to strings.forSale,
            ListingType.FOR_RENT to strings.forRent
          ).forEach { (type, label) ->
            val isSelected = filterState.selectedListingType == type
            Surface(
              shape = RoundedCornerShape(12.dp),
              color = if (isSelected) EmeraldPrimary else MaterialTheme.colorScheme.surfaceVariant,
              modifier = Modifier
                .weight(1f)
                .clip(RoundedCornerShape(12.dp))
                .clickable { onListingTypeChange(type) }
            ) {
              Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.padding(vertical = 10.dp, horizontal = 4.dp),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // 3. Location in Duhok
      FilterSection(title = strings.locationInDuhok) {
        val hoods = if (allNeighborhoods.isNotEmpty()) allNeighborhoods else SampleProperties.duhokNeighborhoods
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          hoods.chunked(3).forEach { rowHoods ->
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              rowHoods.forEach { hood ->
                val isSelected = filterState.selectedNeighborhood.equals(hood, ignoreCase = true)
                val displayHood = if (hood == "All Duhok") allNeighborhoodLabel else hood

                Surface(
                  shape = RoundedCornerShape(12.dp),
                  color = if (isSelected) GoldPrimary else MaterialTheme.colorScheme.surfaceVariant,
                  modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .clickable { onNeighborhoodChange(hood) }
                ) {
                  Text(
                    text = displayHood,
                    fontSize = 12.sp,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                    color = if (isSelected) EmeraldDark else MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(vertical = 8.dp),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                  )
                }
              }
              if (rowHoods.size < 3) {
                repeat(3 - rowHoods.size) {
                  Spacer(modifier = Modifier.weight(1f))
                }
              }
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // 4. Property Type
      FilterSection(title = strings.propertyCategory) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          listOf(
            PropertyType.ALL,
            PropertyType.VILLA,
            PropertyType.APARTMENT,
            PropertyType.LAND
          ).forEach { type ->
            val isSelected = filterState.selectedType == type
            Surface(
              shape = RoundedCornerShape(12.dp),
              color = if (isSelected) EmeraldPrimary else MaterialTheme.colorScheme.surfaceVariant,
              modifier = Modifier
                .weight(1f)
                .clip(RoundedCornerShape(12.dp))
                .clickable { onPropertyTypeChange(type) }
            ) {
              Text(
                text = type.getLabel(appLanguage),
                fontSize = 12.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.padding(vertical = 8.dp),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // 5. Price Range
      FilterSection(title = strings.priceRange) {
        Column {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(
              text = "$${String.format("%,.0f", filterState.minPriceUsd)}",
              fontWeight = FontWeight.Bold,
              color = EmeraldPrimary,
              fontSize = 14.sp
            )
            Text(
              text = "$${String.format("%,.0f", filterState.maxPriceUsd)} (${String.format("%.0f", filterState.maxPriceUsd / 10000)} $daftarsWord)",
              fontWeight = FontWeight.Bold,
              color = EmeraldPrimary,
              fontSize = 14.sp
            )
          }

          RangeSlider(
            value = filterState.minPriceUsd.toFloat()..filterState.maxPriceUsd.toFloat(),
            onValueChange = { range ->
              onPriceRangeChange(range.start.toDouble(), range.endInclusive.toDouble())
            },
            valueRange = 0f..1000000f,
            colors = SliderDefaults.colors(
              thumbColor = EmeraldPrimary,
              activeTrackColor = EmeraldPrimary
            )
          )
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // 6. Number of Bedrooms
      FilterSection(title = strings.bedroomsFilter) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          listOf(0 to anyWord, 1 to "1+", 2 to "2+", 3 to "3+", 4 to "4+", 5 to "5+").forEach { (beds, label) ->
            val isSelected = filterState.minBedrooms == beds
            Surface(
              shape = RoundedCornerShape(10.dp),
              color = if (isSelected) EmeraldPrimary else MaterialTheme.colorScheme.surfaceVariant,
              modifier = Modifier
                .weight(1f)
                .clip(RoundedCornerShape(10.dp))
                .clickable { onMinBedroomsChange(beds) }
            ) {
              Text(
                text = label,
                fontSize = 12.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.padding(vertical = 8.dp),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // 7. Tapu Title Deed Toggle
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 20.dp),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text(
              text = strings.tapuOnlyTitle,
              fontWeight = FontWeight.Bold,
              fontSize = 13.sp
            )
            Text(
              text = strings.tapuOnlySubtitle,
              fontSize = 11.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
          Switch(
            checked = filterState.tapuOnly,
            onCheckedChange = onTapuOnlyChange,
            colors = SwitchDefaults.colors(
              checkedThumbColor = Color.White,
              checkedTrackColor = EmeraldPrimary
            )
          )
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // 8. Sorting
      FilterSection(title = strings.sortBy) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
          SortOption.values().forEach { option ->
            val isSelected = filterState.sortBy == option
            Surface(
              shape = RoundedCornerShape(10.dp),
              color = if (isSelected) EmeraldPrimary.copy(alpha = 0.1f) else Color.Transparent,
              border = androidx.compose.foundation.BorderStroke(
                width = if (isSelected) 1.5.dp else 0.5.dp,
                color = if (isSelected) EmeraldPrimary else MaterialTheme.colorScheme.outline
              ),
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .clickable { onSortByChange(option) }
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  text = option.getTitle(appLanguage),
                  fontSize = 13.sp,
                  fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                  color = if (isSelected) EmeraldPrimary else MaterialTheme.colorScheme.onSurface
                )
                if (isSelected) {
                  Text("✓", color = EmeraldPrimary, fontWeight = FontWeight.Bold)
                }
              }
            }
          }
        }
      }
    }

    // Bottom Sticky CTA Button: "Show X Properties"
    Surface(
      modifier = Modifier
        .align(Alignment.BottomCenter)
        .fillMaxWidth()
        .navigationBarsPadding(),
      color = MaterialTheme.colorScheme.surface,
      shadowElevation = 8.dp
    ) {
      Box(modifier = Modifier.padding(16.dp)) {
        Button(
          onClick = onApplyAndClose,
          modifier = Modifier
            .fillMaxWidth()
            .height(52.dp)
            .testTag("apply_filter_button"),
          shape = RoundedCornerShape(14.dp),
          colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
        ) {
          Text(
            text = "${strings.showPropertiesBtn} ($matchingCount)",
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            color = Color.White
          )
        }
      }
    }
  }
}

@Composable
private fun FilterSection(
  title: String,
  content: @Composable () -> Unit
) {
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 20.dp)
  ) {
    Text(
      text = title,
      fontWeight = FontWeight.Bold,
      fontSize = 14.sp,
      color = MaterialTheme.colorScheme.onSurface
    )
    Spacer(modifier = Modifier.height(8.dp))
    content()
  }
}
