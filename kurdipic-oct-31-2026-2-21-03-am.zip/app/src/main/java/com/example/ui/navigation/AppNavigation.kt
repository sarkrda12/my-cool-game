package com.example.ui.navigation

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.Calculate
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.AppLanguage
import com.example.data.model.LocaleStrings
import com.example.ui.NavigationDestination
import com.example.ui.RealEstateViewModel
import com.example.ui.components.GoogleSignInDialog
import com.example.ui.components.LanguageSelectorSheet
import com.example.ui.components.MortgageCalculatorSheet
import com.example.ui.screens.FavoritesScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ManagePropertiesScreen
import com.example.ui.screens.OnboardingScreen
import com.example.ui.screens.PropertyDetailScreen
import com.example.ui.screens.SearchFilterScreen
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.GoldPrimary

@Composable
fun AppNavigation(
  viewModel: RealEstateViewModel,
  modifier: Modifier = Modifier
) {
  val uiState by viewModel.uiState.collectAsStateWithLifecycle()
  val strings = LocaleStrings.get(uiState.appLanguage)
  var showMortgageSheet by remember { mutableStateOf(false) }

  val filteredProperties = viewModel.getFilteredProperties()
  val favoritesCount = uiState.properties.count { it.isFavorite }

  // Set Layout Direction based on selected language (RTL for Badini, Sorani, Arabic; LTR for English)
  CompositionLocalProvider(LocalLayoutDirection provides uiState.appLanguage.layoutDirection) {

    // Check if onboarding is open
    if (uiState.showOnboarding) {
      OnboardingScreen(
        appLanguage = uiState.appLanguage,
        onLanguageToggle = { viewModel.toggleLanguageDialog(true) },
        onGetStarted = { viewModel.toggleOnboarding(false) }
      )
      return@CompositionLocalProvider
    }

    Scaffold(
      modifier = modifier.fillMaxSize(),
      bottomBar = {
        // Hide bottom bar when inside full property details or advanced filter screen
        if (uiState.currentScreen != NavigationDestination.PROPERTY_DETAILS &&
          uiState.currentScreen != NavigationDestination.EXPLORE_SEARCH
        ) {
          NavigationBar(
            containerColor = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp,
            modifier = Modifier.testTag("bottom_navigation_bar")
          ) {
            // 1. Home
            NavigationBarItem(
              selected = uiState.currentScreen == NavigationDestination.HOME,
              onClick = { viewModel.navigateTo(NavigationDestination.HOME) },
              icon = {
                Icon(
                  imageVector = if (uiState.currentScreen == NavigationDestination.HOME) Icons.Filled.Home else Icons.Outlined.Home,
                  contentDescription = strings.navHome
                )
              },
              label = { Text(strings.navHome, fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
              colors = NavigationBarItemDefaults.colors(
                selectedIconColor = EmeraldPrimary,
                selectedTextColor = EmeraldPrimary,
                indicatorColor = EmeraldPrimary.copy(alpha = 0.12f)
              ),
              modifier = Modifier.testTag("nav_item_home")
            )

            // 2. Search / Explore
            NavigationBarItem(
              selected = uiState.currentScreen == NavigationDestination.EXPLORE_SEARCH,
              onClick = { viewModel.navigateTo(NavigationDestination.EXPLORE_SEARCH) },
              icon = {
                Icon(
                  imageVector = Icons.Default.Search,
                  contentDescription = strings.navExplore
                )
              },
              label = { Text(strings.navExplore, fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
              colors = NavigationBarItemDefaults.colors(
                selectedIconColor = EmeraldPrimary,
                selectedTextColor = EmeraldPrimary,
                indicatorColor = EmeraldPrimary.copy(alpha = 0.12f)
              ),
              modifier = Modifier.testTag("nav_item_explore")
            )

            // 3. Saved / Favorites
            NavigationBarItem(
              selected = uiState.currentScreen == NavigationDestination.FAVORITES,
              onClick = { viewModel.navigateTo(NavigationDestination.FAVORITES) },
              icon = {
                BadgedBox(
                  badge = {
                    if (favoritesCount > 0) {
                      Badge(containerColor = GoldPrimary, contentColor = EmeraldDark) {
                        Text("$favoritesCount")
                      }
                    }
                  }
                ) {
                  Icon(
                    imageVector = if (uiState.currentScreen == NavigationDestination.FAVORITES) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                    contentDescription = strings.navSaved
                  )
                }
              },
              label = { Text(strings.navSaved, fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
              colors = NavigationBarItemDefaults.colors(
                selectedIconColor = EmeraldPrimary,
                selectedTextColor = EmeraldPrimary,
                indicatorColor = EmeraldPrimary.copy(alpha = 0.12f)
              ),
              modifier = Modifier.testTag("nav_item_favorites")
            )

            // 4. Finance / Mortgage
            NavigationBarItem(
              selected = showMortgageSheet,
              onClick = { showMortgageSheet = true },
              icon = {
                Icon(
                  imageVector = Icons.Outlined.Calculate,
                  contentDescription = strings.navFinance
                )
              },
              label = { Text(strings.navFinance, fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
              colors = NavigationBarItemDefaults.colors(
                selectedIconColor = EmeraldPrimary,
                selectedTextColor = EmeraldPrimary,
                indicatorColor = EmeraldPrimary.copy(alpha = 0.12f)
              ),
              modifier = Modifier.testTag("nav_item_finance")
            )

            // 5. Manage / Admin (جهێ تایبەت)
            NavigationBarItem(
              selected = uiState.currentScreen == NavigationDestination.MANAGE,
              onClick = { viewModel.navigateTo(NavigationDestination.MANAGE) },
              icon = {
                Icon(
                  imageVector = Icons.Default.AdminPanelSettings,
                  contentDescription = strings.navManage
                )
              },
              label = { Text(strings.navManage, fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
              colors = NavigationBarItemDefaults.colors(
                selectedIconColor = EmeraldPrimary,
                selectedTextColor = EmeraldPrimary,
                indicatorColor = EmeraldPrimary.copy(alpha = 0.12f)
              ),
              modifier = Modifier.testTag("nav_item_manage")
            )
          }
        }
      }
    ) { paddingValues ->
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(paddingValues)
      ) {
        when (uiState.currentScreen) {
          NavigationDestination.HOME -> {
            HomeScreen(
              properties = filteredProperties,
              currencyMode = uiState.currencyMode,
              appLanguage = uiState.appLanguage,
              selectedType = uiState.filterState.selectedType,
              selectedListingType = uiState.filterState.selectedListingType,
              selectedNeighborhood = uiState.filterState.selectedNeighborhood,
              allNeighborhoods = viewModel.getAllNeighborhoods(),
              searchQuery = uiState.filterState.searchQuery,
              onSearchChange = { viewModel.updateSearchQuery(it) },
              onTypeSelect = { viewModel.updatePropertyType(it) },
              onListingTypeSelect = { viewModel.updateListingType(it) },
              onNeighborhoodSelect = { viewModel.updateNeighborhood(it) },
              onCurrencyToggle = { viewModel.cycleCurrency() },
              onOpenLanguageSelector = { viewModel.toggleLanguageDialog(true) },
              onPropertyClick = { prop -> viewModel.selectProperty(prop.id) },
              onFavoriteClick = { id -> viewModel.toggleFavorite(id) },
              onOpenFilter = { viewModel.navigateTo(NavigationDestination.EXPLORE_SEARCH) },
              onOpenCalculator = { showMortgageSheet = true },
              onOpenManage = { viewModel.navigateTo(NavigationDestination.MANAGE) },
              userProfile = uiState.userProfile,
              onGoogleAccountClick = { viewModel.toggleGoogleSignInDialog(true) },
              appAnnouncement = uiState.appAnnouncement
            )
          }

          NavigationDestination.EXPLORE_SEARCH -> {
            SearchFilterScreen(
              filterState = uiState.filterState,
              matchingCount = filteredProperties.size,
              allNeighborhoods = viewModel.getAllNeighborhoods(),
              appLanguage = uiState.appLanguage,
              onSearchQueryChange = { viewModel.updateSearchQuery(it) },
              onPropertyTypeChange = { viewModel.updatePropertyType(it) },
              onListingTypeChange = { viewModel.updateListingType(it) },
              onNeighborhoodChange = { viewModel.updateNeighborhood(it) },
              onPriceRangeChange = { min, max -> viewModel.updatePriceRange(min, max) },
              onMinBedroomsChange = { viewModel.updateMinBedrooms(it) },
              onMinBathroomsChange = { viewModel.updateMinBathrooms(it) },
              onTapuOnlyChange = { viewModel.updateTapuOnly(it) },
              onSortByChange = { viewModel.updateSortBy(it) },
              onResetFilters = { viewModel.resetFilters() },
              onApplyAndClose = { viewModel.navigateTo(NavigationDestination.HOME) }
            )
          }

          NavigationDestination.FAVORITES -> {
            val favoritesList = uiState.properties.filter { it.isFavorite }
            FavoritesScreen(
              favoriteProperties = favoritesList,
              currencyMode = uiState.currencyMode,
              appLanguage = uiState.appLanguage,
              onPropertyClick = { prop -> viewModel.selectProperty(prop.id) },
              onFavoriteClick = { id -> viewModel.toggleFavorite(id) },
              onExploreClick = { viewModel.navigateTo(NavigationDestination.HOME) }
            )
          }

          NavigationDestination.MANAGE -> {
            ManagePropertiesScreen(
              properties = uiState.properties,
              currencyMode = uiState.currencyMode,
              appLanguage = uiState.appLanguage,
              officePhone = uiState.officePhone,
              officeName = uiState.officeName,
              officeWhatsapp = uiState.officeWhatsapp,
              appAnnouncement = uiState.appAnnouncement,
              loanInterestRate = uiState.loanInterestRate,
              registeredUsers = uiState.registeredUsers,
              isUnlocked = uiState.isManageUnlocked,
              customNeighborhoods = uiState.customNeighborhoods,
              onAddNeighborhood = { viewModel.addCustomNeighborhood(it) },
              onUnlock = { code -> viewModel.unlockManage(code) },
              onLock = { viewModel.lockManage() },
              onAddProperty = { prop -> viewModel.addProperty(prop) },
              onEditProperty = { updated -> viewModel.updateProperty(updated) },
              onUpdateOfficeInfo = { phone, name -> viewModel.updateOfficeInfo(phone, name) },
              onUpdateMasterSettings = { name, phone, whatsapp, announcement, currency, rate ->
                viewModel.updateMasterSettings(name, phone, whatsapp, announcement, currency, rate)
              },
              onDeleteUserAccount = { email -> viewModel.deleteUserAccount(email) },
              onDeleteProperty = { id -> viewModel.deleteProperty(id) },
              onClearAll = { viewModel.clearAllProperties() },
              onLoadDemoProperties = { viewModel.loadDemoProperties() },
              onPropertyClick = { prop -> viewModel.selectProperty(prop.id) },
              onBack = { viewModel.navigateTo(NavigationDestination.HOME) }
            )
          }

          NavigationDestination.PROPERTY_DETAILS -> {
            val property = uiState.properties.find { it.id == uiState.selectedPropertyId }
              ?: uiState.properties.firstOrNull()
            if (property != null) {
              PropertyDetailScreen(
                property = property,
                currencyMode = uiState.currencyMode,
                appLanguage = uiState.appLanguage,
                onBack = { viewModel.navigateTo(NavigationDestination.HOME) },
                onFavoriteToggle = { viewModel.toggleFavorite(property.id) },
                onScheduleVisitConfirmed = { booking ->
                  viewModel.scheduleVisit(booking)
                }
              )
            } else {
              viewModel.navigateTo(NavigationDestination.HOME)
            }
          }

          else -> {
            viewModel.navigateTo(NavigationDestination.HOME)
          }
        }
      }

      // 4-Language Selector Bottom Sheet
      if (uiState.showLanguageDialog) {
        LanguageSelectorSheet(
          currentLanguage = uiState.appLanguage,
          onLanguageSelected = { lang -> viewModel.setLanguage(lang) },
          onDismiss = { viewModel.toggleLanguageDialog(false) }
        )
      }

      // Google Sign-In & Account Onboarding Dialog
      if (uiState.showGoogleSignInDialog) {
        GoogleSignInDialog(
          userProfile = uiState.userProfile,
          appLanguage = uiState.appLanguage,
          onSignIn = { name, email, age, password ->
            viewModel.createOrUpdateAccount(name, email, age, password)
          },
          onSignOut = {
            viewModel.signOut()
          },
          onDismiss = {
            viewModel.toggleGoogleSignInDialog(false)
          }
        )
      }

      // Mortgage calculator bottom sheet
      if (showMortgageSheet) {
        val selectedProp = uiState.properties.find { it.id == uiState.selectedPropertyId }
        MortgageCalculatorSheet(
          propertyPriceUsd = selectedProp?.priceUsd ?: 320000.0,
          appLanguage = uiState.appLanguage,
          officePhone = uiState.officePhone,
          onDismiss = { showMortgageSheet = false }
        )
      }

      // Visit Booking Confirmation Dialog
      if (uiState.showBookingSuccessDialog && uiState.lastBookedVisit != null) {
        val booking = uiState.lastBookedVisit!!
        val (dialogTitle, confirmBtnText) = when (uiState.appLanguage) {
          AppLanguage.BADINI -> Pair("ژڤان هاتە تۆمارکرن ب سەرکەفتیانە!", "باشە")
          AppLanguage.SORANI -> Pair("سەردان بە سەرکەوتوویی تۆمارکرا!", "تێگەیشتم")
          AppLanguage.ARABIC -> Pair("تم حجز موعد الزيارة بنجاح!", "حسناً")
          AppLanguage.ENGLISH -> Pair("Visit Scheduled Successfully!", "Got It")
        }

        AlertDialog(
          onDismissRequest = { viewModel.dismissBookingSuccess() },
          title = {
            Text(
              text = dialogTitle,
              fontWeight = FontWeight.Bold,
              color = EmeraldDark
            )
          },
          text = {
            Text(
              text = "${booking.tourType} • ${booking.propertyTitle}\n${booking.date} | ${booking.timeSlot}\nWhatsApp: ${booking.visitorPhone}"
            )
          },
          confirmButton = {
            Button(
              onClick = { viewModel.dismissBookingSuccess() },
              colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
            ) {
              Text(confirmBtnText, color = Color.White)
            }
          }
        )
      }
    }
  }
}
