package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bed
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.SquareFoot
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.data.model.CurrencyMode
import com.example.data.model.LocaleStrings
import com.example.data.model.Property
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.GoldPrimary

@Composable
fun FeaturedCarousel(
  featuredProperties: List<Property>,
  currencyMode: CurrencyMode,
  appLanguage: AppLanguage = AppLanguage.BADINI,
  onPropertyClick: (Property) -> Unit,
  modifier: Modifier = Modifier
) {
  LazyRow(
    modifier = modifier
      .fillMaxWidth()
      .testTag("featured_carousel"),
    contentPadding = PaddingValues(horizontal = 20.dp),
    horizontalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    items(featuredProperties, key = { it.id }) { property ->
      FeaturedCard(
        property = property,
        currencyMode = currencyMode,
        appLanguage = appLanguage,
        onClick = { onPropertyClick(property) }
      )
    }
  }
}

@Composable
private fun FeaturedCard(
  property: Property,
  currencyMode: CurrencyMode,
  appLanguage: AppLanguage,
  onClick: () -> Unit
) {
  val strings = LocaleStrings.get(appLanguage)

  Card(
    modifier = Modifier
      .width(310.dp)
      .height(260.dp)
      .testTag("featured_card_${property.id}")
      .clickable(onClick = onClick),
    shape = RoundedCornerShape(24.dp),
    elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
  ) {
    Box(modifier = Modifier.fillMaxSize()) {
      val imageSource = property.getImageSources().firstOrNull() ?: com.example.R.drawable.img_hero_duhok
      coil.compose.AsyncImage(
        model = imageSource,
        contentDescription = property.getTitle(appLanguage),
        modifier = Modifier.fillMaxSize(),
        contentScale = ContentScale.Crop,
        placeholder = painterResource(id = com.example.R.drawable.img_hero_duhok),
        error = painterResource(id = com.example.R.drawable.img_hero_duhok)
      )

      // Gradient shadow
      Box(
        modifier = Modifier
          .fillMaxSize()
          .background(
            Brush.verticalGradient(
              colors = listOf(
                Color.Black.copy(alpha = 0.5f),
                Color.Transparent,
                Color.Black.copy(alpha = 0.85f)
              )
            )
          )
      )

      // Top Tag: "Featured"
      Row(
        modifier = Modifier
          .align(Alignment.TopStart)
          .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Surface(
          shape = RoundedCornerShape(10.dp),
          color = EmeraldDark.copy(alpha = 0.9f),
          border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary)
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
          ) {
            Icon(
              imageVector = Icons.Default.AutoAwesome,
              contentDescription = null,
              tint = GoldPrimary,
              modifier = Modifier.size(13.dp)
            )
            Text(
              text = strings.premierListing,
              color = Color.White,
              fontSize = 10.sp,
              fontWeight = FontWeight.Bold,
              letterSpacing = 0.5.sp
            )
          }
        }
      }

      // Bottom Content
      Column(
        modifier = Modifier
          .align(Alignment.BottomStart)
          .padding(16.dp)
      ) {
        // Price Tag
        Text(
          text = currencyMode.formatPrice(property.priceUsd, false, appLanguage),
          color = Color.White,
          fontSize = 22.sp,
          fontWeight = FontWeight.Black
        )

        Spacer(modifier = Modifier.height(2.dp))

        // Title
        Text(
          text = property.getTitle(appLanguage),
          color = Color.White,
          fontSize = 15.sp,
          fontWeight = FontWeight.Bold,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )

        Spacer(modifier = Modifier.height(6.dp))

        // Location & Specs
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
          ) {
            Icon(
              imageVector = Icons.Default.LocationOn,
              contentDescription = null,
              tint = GoldPrimary,
              modifier = Modifier.size(14.dp)
            )
            Text(
              text = "${property.getNeighborhood(appLanguage)}, Duhok",
              color = Color.White.copy(alpha = 0.9f),
              fontSize = 12.sp,
              fontWeight = FontWeight.Medium
            )
          }

          Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            if (property.bedrooms > 0) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(2.dp)
              ) {
                Icon(
                  imageVector = Icons.Default.Bed,
                  contentDescription = null,
                  tint = Color.White.copy(alpha = 0.8f),
                  modifier = Modifier.size(13.dp)
                )
                Text(
                  text = "${property.bedrooms}",
                  color = Color.White,
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold
                )
              }
            }
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(2.dp)
            ) {
              Icon(
                imageVector = Icons.Default.SquareFoot,
                contentDescription = null,
                tint = Color.White.copy(alpha = 0.8f),
                modifier = Modifier.size(13.dp)
              )
              Text(
                text = "${property.areaSqm}m²",
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
              )
            }
          }
        }
      }
    }
  }
}
