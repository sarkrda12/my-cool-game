package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Cake
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.outlined.ExitToApp
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.UserProfile
import com.example.data.model.AppLanguage
import com.example.data.model.LocaleStrings
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.GoldPrimary

@Composable
fun GoogleSignInDialog(
  userProfile: UserProfile?,
  appLanguage: AppLanguage,
  onSignIn: (name: String, email: String, age: Int, password: String) -> Unit,
  onSignOut: () -> Unit,
  onDismiss: () -> Unit
) {
  val strings = LocaleStrings.get(appLanguage)

  var isEditMode by remember { mutableStateOf(false) }

  var inputName by remember {
    mutableStateOf(userProfile?.name?.ifBlank { "Snerway Duhoki" } ?: "Snerway Duhoki")
  }
  var inputEmail by remember {
    mutableStateOf(userProfile?.email?.ifBlank { "snerway66@gmail.com" } ?: "snerway66@gmail.com")
  }
  var inputAge by remember {
    mutableIntStateOf(if ((userProfile?.age ?: 25) > 0) (userProfile?.age ?: 25) else 25)
  }
  var inputPassword by remember {
    mutableStateOf(userProfile?.password?.ifBlank { "Duhok#2026" } ?: "Duhok#2026")
  }
  var isPasswordVisible by remember { mutableStateOf(false) }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(
      dismissOnBackPress = true,
      dismissOnClickOutside = true,
      usePlatformDefaultWidth = false
    )
  ) {
    Card(
      modifier = Modifier
        .fillMaxWidth(0.92f)
        .clip(RoundedCornerShape(28.dp))
        .testTag("google_sign_in_dialog"),
      shape = RoundedCornerShape(28.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      elevation = CardDefaults.cardElevation(defaultElevation = 10.dp)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState())
          .padding(22.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        // Top Bar: Google Badge & Close Button
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          GoogleBadge()

          IconButton(
            onClick = onDismiss,
            modifier = Modifier.testTag("close_google_dialog_btn")
          ) {
            Icon(
              imageVector = Icons.Default.Close,
              contentDescription = "Close",
              tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (userProfile != null && userProfile.isSignedIn && !isEditMode) {
          // ==========================================
          // 1. SIGNED-IN PROFILE VIEW (Most Beautiful VIP Layout)
          // ==========================================
          Box(
            modifier = Modifier
              .size(80.dp)
              .clip(CircleShape)
              .background(
                Brush.linearGradient(
                  colors = listOf(GoldPrimary, EmeraldPrimary)
                )
              )
              .padding(3.dp),
            contentAlignment = Alignment.Center
          ) {
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.surface),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = userProfile.name.take(1).uppercase(),
                fontSize = 34.sp,
                fontWeight = FontWeight.Black,
                color = EmeraldPrimary
              )
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            Text(
              text = userProfile.name,
              fontSize = 22.sp,
              fontWeight = FontWeight.Black,
              color = MaterialTheme.colorScheme.onSurface
            )
            Icon(
              imageVector = Icons.Default.CheckCircle,
              contentDescription = "Verified",
              tint = Color(0xFF34A853),
              modifier = Modifier.size(20.dp)
            )
          }

          // Member status chip
          Surface(
            shape = RoundedCornerShape(12.dp),
            color = GoldPrimary.copy(alpha = 0.18f),
            modifier = Modifier.padding(top = 4.dp)
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
              Icon(
                imageVector = Icons.Default.Star,
                contentDescription = null,
                tint = GoldPrimary,
                modifier = Modifier.size(13.dp)
              )
              Text(
                text = strings.memberStatusActive,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = EmeraldDark
              )
            }
          }

          Spacer(modifier = Modifier.height(16.dp))

          // Detailed Info Cards
          Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(
              modifier = Modifier.padding(14.dp),
              verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
              // Email
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
              ) {
                Surface(
                  shape = CircleShape,
                  color = Color(0xFF4285F4).copy(alpha = 0.15f),
                  modifier = Modifier.size(34.dp)
                ) {
                  Box(contentAlignment = Alignment.Center) {
                    Icon(
                      imageVector = Icons.Default.Email,
                      contentDescription = null,
                      tint = Color(0xFF4285F4),
                      modifier = Modifier.size(18.dp)
                    )
                  }
                }
                Column {
                  Text(
                    text = strings.googleAccountEmail,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                  )
                  Text(
                    text = userProfile.email,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                  )
                }
              }

              // Age (تەمەن)
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
              ) {
                Surface(
                  shape = CircleShape,
                  color = EmeraldPrimary.copy(alpha = 0.15f),
                  modifier = Modifier.size(34.dp)
                ) {
                  Box(contentAlignment = Alignment.Center) {
                    Icon(
                      imageVector = Icons.Default.Cake,
                      contentDescription = null,
                      tint = EmeraldPrimary,
                      modifier = Modifier.size(18.dp)
                    )
                  }
                }
                Column {
                  Text(
                    text = strings.accountAgeInput,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                  )
                  Text(
                    text = "${userProfile.age} ${strings.ageYearsSuffix}",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                  )
                }
              }

              // Password security indicator (پاسورد)
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
              ) {
                Surface(
                  shape = CircleShape,
                  color = GoldPrimary.copy(alpha = 0.2f),
                  modifier = Modifier.size(34.dp)
                ) {
                  Box(contentAlignment = Alignment.Center) {
                    Icon(
                      imageVector = Icons.Default.Lock,
                      contentDescription = null,
                      tint = GoldPrimary,
                      modifier = Modifier.size(18.dp)
                    )
                  }
                }
                Column {
                  Text(
                    text = strings.accountPasswordInput,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                  )
                  Text(
                    text = if (userProfile.password.isNotBlank()) "•••••••••••• (پاراستیە)" else "Google OAuth 2.0 (پاراستیە)",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                  )
                }
              }
            }
          }

          Spacer(modifier = Modifier.height(16.dp))

          // Edit Profile Button
          OutlinedButton(
            onClick = { isEditMode = true },
            modifier = Modifier
              .fillMaxWidth()
              .height(46.dp)
              .testTag("edit_profile_button"),
            shape = RoundedCornerShape(14.dp)
          ) {
            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp), tint = EmeraldPrimary)
            Spacer(modifier = Modifier.width(6.dp))
            Text(strings.editAccountDetails, fontWeight = FontWeight.Bold, color = EmeraldPrimary)
          }

          Spacer(modifier = Modifier.height(8.dp))

          // Sign Out Button
          Button(
            onClick = {
              onSignOut()
              isEditMode = false
            },
            modifier = Modifier
              .fillMaxWidth()
              .height(46.dp)
              .testTag("dialog_sign_out_button"),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(
              containerColor = MaterialTheme.colorScheme.error.copy(alpha = 0.12f),
              contentColor = MaterialTheme.colorScheme.error
            )
          ) {
            Icon(Icons.Outlined.ExitToApp, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(strings.signOut, fontWeight = FontWeight.Bold)
          }

        } else {
          // ==========================================
          // 2. ACCOUNT CREATION & EDIT FORM (ناڤ، پاسورد، تەمەن)
          // ==========================================
          Text(
            text = strings.createAccountHeader,
            fontSize = 20.sp,
            fontWeight = FontWeight.Black,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurface
          )

          Text(
            text = strings.googleAccountSubtitle,
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 4.dp, bottom = 14.dp),
            lineHeight = 18.sp
          )

          // 1. ناڤ (Full Name Input)
          OutlinedTextField(
            value = inputName,
            onValueChange = { inputName = it },
            label = { Text(strings.googleAccountName, fontSize = 12.sp) },
            leadingIcon = {
              Icon(
                imageVector = Icons.Default.Person,
                contentDescription = null,
                tint = EmeraldPrimary
              )
            },
            singleLine = true,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("input_account_name"),
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = EmeraldPrimary,
              focusedLabelColor = EmeraldPrimary
            ),
            shape = RoundedCornerShape(14.dp)
          )

          Spacer(modifier = Modifier.height(10.dp))

          // 2. ئیمەیڵ (Google Email)
          OutlinedTextField(
            value = inputEmail,
            onValueChange = { inputEmail = it },
            label = { Text(strings.googleAccountEmail, fontSize = 12.sp) },
            leadingIcon = {
              Icon(
                imageVector = Icons.Default.Email,
                contentDescription = null,
                tint = Color(0xFF4285F4)
              )
            },
            singleLine = true,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("input_account_email"),
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = EmeraldPrimary,
              focusedLabelColor = EmeraldPrimary
            ),
            shape = RoundedCornerShape(14.dp)
          )

          Spacer(modifier = Modifier.height(10.dp))

          // 3. تەمەن (Age Input & Quick Age Chips)
          Surface(
            shape = RoundedCornerShape(14.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(12.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                  Icon(
                    imageVector = Icons.Default.Cake,
                    contentDescription = null,
                    tint = EmeraldPrimary,
                    modifier = Modifier.size(20.dp)
                  )
                  Text(
                    text = strings.accountAgeInput,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                  )
                }

                // Age stepper (+ and -)
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                  Surface(
                    shape = CircleShape,
                    color = EmeraldPrimary.copy(alpha = 0.15f),
                    modifier = Modifier
                      .size(32.dp)
                      .clip(CircleShape)
                      .clickable { if (inputAge > 12) inputAge-- }
                  ) {
                    Box(contentAlignment = Alignment.Center) {
                      Icon(Icons.Default.Remove, contentDescription = "Decrease", tint = EmeraldPrimary, modifier = Modifier.size(16.dp))
                    }
                  }

                  Text(
                    text = "$inputAge ${strings.ageYearsSuffix}",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Black,
                    color = EmeraldPrimary,
                    modifier = Modifier.padding(horizontal = 4.dp)
                  )

                  Surface(
                    shape = CircleShape,
                    color = EmeraldPrimary.copy(alpha = 0.15f),
                    modifier = Modifier
                      .size(32.dp)
                      .clip(CircleShape)
                      .clickable { if (inputAge < 100) inputAge++ }
                  ) {
                    Box(contentAlignment = Alignment.Center) {
                      Icon(Icons.Default.Add, contentDescription = "Increase", tint = EmeraldPrimary, modifier = Modifier.size(16.dp))
                    }
                  }
                }
              }

              // Quick age chips
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(top = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
              ) {
                listOf(18, 22, 25, 30, 35, 40).forEach { ageOption ->
                  val isSelected = inputAge == ageOption
                  Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (isSelected) EmeraldPrimary else MaterialTheme.colorScheme.surface,
                    border = if (isSelected) null else androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
                    modifier = Modifier
                      .weight(1f)
                      .clip(RoundedCornerShape(8.dp))
                      .clickable { inputAge = ageOption }
                  ) {
                    Box(
                      modifier = Modifier.padding(vertical = 6.dp),
                      contentAlignment = Alignment.Center
                    ) {
                      Text(
                        text = "$ageOption",
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                      )
                    }
                  }
                }
              }
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          // 4. پاسورد (Password with Show/Hide toggle)
          OutlinedTextField(
            value = inputPassword,
            onValueChange = { inputPassword = it },
            label = { Text(strings.accountPasswordInput, fontSize = 12.sp) },
            leadingIcon = {
              Icon(
                imageVector = Icons.Default.Lock,
                contentDescription = null,
                tint = GoldPrimary
              )
            },
            trailingIcon = {
              IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
                Icon(
                  imageVector = if (isPasswordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                  contentDescription = "Toggle Password",
                  tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            },
            visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            singleLine = true,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("input_account_password"),
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = EmeraldPrimary,
              focusedLabelColor = EmeraldPrimary
            ),
            shape = RoundedCornerShape(14.dp)
          )

          Spacer(modifier = Modifier.height(18.dp))

          // Primary Submission Button: "چێکرنا حسابێ ب Google"
          Button(
            onClick = {
              onSignIn(inputName, inputEmail, inputAge, inputPassword)
              isEditMode = false
            },
            modifier = Modifier
              .fillMaxWidth()
              .height(52.dp)
              .testTag("google_sign_in_submit"),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.Center
            ) {
              GoogleIconGraphic(modifier = Modifier.size(20.dp))
              Spacer(modifier = Modifier.width(10.dp))
              Text(
                text = strings.continueWithGoogle,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
              )
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          // Guest Mode Option
          OutlinedButton(
            onClick = onDismiss,
            modifier = Modifier
              .fillMaxWidth()
              .height(46.dp)
              .testTag("guest_continue_btn"),
            shape = RoundedCornerShape(14.dp)
          ) {
            Text(
              text = strings.continueAsGuest,
              fontSize = 13.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              fontWeight = FontWeight.Medium
            )
          }

          Spacer(modifier = Modifier.height(12.dp))

          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
          ) {
            Icon(
              imageVector = Icons.Outlined.Security,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.outline,
              modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = "Official Google Identity Authentication",
              fontSize = 11.sp,
              color = MaterialTheme.colorScheme.outline
            )
          }
        }
      }
    }
  }
}

/**
 * Authentic 4-color Google G icon graphic drawn via Canvas.
 */
@Composable
fun GoogleIconGraphic(modifier: Modifier = Modifier) {
  Canvas(modifier = modifier) {
    val w = size.width
    val h = size.height
    val stroke = w * 0.22f
    val radius = (w - stroke) / 2f
    val center = Offset(w / 2f, h / 2f)

    // Red sector (top left to top right)
    drawArc(
      color = Color(0xFFEA4335),
      startAngle = 180f,
      sweepAngle = 100f,
      useCenter = false,
      topLeft = Offset(center.x - radius, center.y - radius),
      size = Size(radius * 2, radius * 2),
      style = androidx.compose.ui.graphics.drawscope.Stroke(width = stroke)
    )

    // Yellow sector (bottom left)
    drawArc(
      color = Color(0xFFFBBC05),
      startAngle = 120f,
      sweepAngle = 60f,
      useCenter = false,
      topLeft = Offset(center.x - radius, center.y - radius),
      size = Size(radius * 2, radius * 2),
      style = androidx.compose.ui.graphics.drawscope.Stroke(width = stroke)
    )

    // Green sector (bottom right)
    drawArc(
      color = Color(0xFF34A853),
      startAngle = 20f,
      sweepAngle = 100f,
      useCenter = false,
      topLeft = Offset(center.x - radius, center.y - radius),
      size = Size(radius * 2, radius * 2),
      style = androidx.compose.ui.graphics.drawscope.Stroke(width = stroke)
    )

    // Blue sector & horizontal bar
    drawArc(
      color = Color(0xFF4285F4),
      startAngle = 280f,
      sweepAngle = 100f,
      useCenter = false,
      topLeft = Offset(center.x - radius, center.y - radius),
      size = Size(radius * 2, radius * 2),
      style = androidx.compose.ui.graphics.drawscope.Stroke(width = stroke)
    )

    // Inner horizontal blue bar
    drawRect(
      color = Color(0xFF4285F4),
      topLeft = Offset(center.x - stroke * 0.2f, center.y - stroke / 2f),
      size = Size(radius + stroke * 0.2f, stroke)
    )
  }
}

@Composable
fun GoogleBadge(modifier: Modifier = Modifier) {
  Surface(
    shape = RoundedCornerShape(20.dp),
    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
    modifier = modifier
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
      GoogleIconGraphic(modifier = Modifier.size(16.dp))
      Text(
        text = "Google Account",
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurface
      )
    }
  }
}
