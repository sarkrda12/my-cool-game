package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
  primary = GoldLight,
  onPrimary = EmeraldDark,
  primaryContainer = EmeraldPrimary,
  onPrimaryContainer = GoldContainer,
  secondary = EmeraldLight,
  onSecondary = Color.White,
  tertiary = GoldPrimary,
  background = BackgroundDark,
  onBackground = Color(0xFFE6EFEA),
  surface = SurfaceDark,
  onSurface = Color(0xFFE6EFEA),
  surfaceVariant = SurfaceVariantDark,
  onSurfaceVariant = Color(0xFFBAC9C2),
  outline = CardBorderDark
)

private val LightColorScheme = lightColorScheme(
  primary = EmeraldPrimary,
  onPrimary = Color.White,
  primaryContainer = EmeraldContainer,
  onPrimaryContainer = OnEmeraldContainer,
  secondary = GoldPrimary,
  onSecondary = Color.White,
  secondaryContainer = GoldContainer,
  onSecondaryContainer = OnGoldContainer,
  tertiary = SlatePrimary,
  background = BackgroundLight,
  onBackground = Color(0xFF19231E),
  surface = SurfaceLight,
  onSurface = Color(0xFF19231E),
  surfaceVariant = SurfaceVariantLight,
  onSurfaceVariant = Color(0xFF566660),
  outline = CardBorderLight
)

@Composable
fun TheDuhokAqarTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false, // Keep brand aesthetic cohesive
  content: @Composable () -> Unit
) {
  val colorScheme = when {
    dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
      val context = LocalContext.current
      if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
    }
    darkTheme -> DarkColorScheme
    else -> LightColorScheme
  }

  MaterialTheme(
    colorScheme = colorScheme,
    typography = Typography,
    content = content
  )
}
