package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Brand Palette - Duhok Emerald & Kurdish Mountain Pine
val EmeraldPrimary = Color(0xFF0D4734)
val EmeraldDark = Color(0xFF07271D)
val EmeraldLight = Color(0xFF1B6B51)
val EmeraldContainer = Color(0xFFD0E8DC)
val OnEmeraldContainer = Color(0xFF042117)

// Accent Palette - Warm Kurdish Gold & Champagne
val GoldPrimary = Color(0xFFC99738)
val GoldLight = Color(0xFFDFB65F)
val GoldDark = Color(0xFF9E711F)
val GoldContainer = Color(0xFFFFF2D6)
val OnGoldContainer = Color(0xFF3B2803)

// Secondary & Tertiary
val SlatePrimary = Color(0xFF2C3E50)
val SlateLight = Color(0xFF4A6572)
val SlateMuted = Color(0xFF718096)

// Surface & Background Colors
val BackgroundLight = Color(0xFFF7F9F8)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFEDF2F0)
val CardBorderLight = Color(0xFFE2E8E5)

val BackgroundDark = Color(0xFF0C1411)
val SurfaceDark = Color(0xFF14211D)
val SurfaceVariantDark = Color(0xFF1B2E28)
val CardBorderDark = Color(0xFF253E36)

// Functional & Badges
val RentBadgeBg = Color(0xFFE3F2FD)
val RentBadgeText = Color(0xFF1565C0)
val SaleBadgeBg = Color(0xFFFFF3E0)
val SaleBadgeText = Color(0xFFE65100)
val VerifiedGreen = Color(0xFF2E7D32)
val VerifiedGreenBg = Color(0xFFE8F5E9)
val WhatsAppGreen = Color(0xFF25D366)
val PriceTagGold = Color(0xFFB78103)
