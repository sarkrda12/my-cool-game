package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("The Duhok-Aqar", appName)
  }

  @Test
  fun `user profile save and load works`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val testProfile = com.example.data.UserProfile(
      name = "Snerway Duhoki",
      email = "snerway66@gmail.com",
      age = 28,
      password = "SecretPassword123",
      isSignedIn = true
    )
    com.example.data.PropertyStorage.saveUserProfile(context, testProfile)
    val loaded = com.example.data.PropertyStorage.loadUserProfile(context)
    org.junit.Assert.assertNotNull(loaded)
    assertEquals("Snerway Duhoki", loaded?.name)
    assertEquals("snerway66@gmail.com", loaded?.email)
    assertEquals(28, loaded?.age)
    assertEquals("SecretPassword123", loaded?.password)

    com.example.data.PropertyStorage.clearUserProfile(context)
    val cleared = com.example.data.PropertyStorage.loadUserProfile(context)
    org.junit.Assert.assertNull(cleared)
  }

  @Test
  fun `custom neighborhoods save and load works`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val places = listOf("سێمێل", "زاویتە", "شاخی دهۆک")
    com.example.data.PropertyStorage.saveCustomNeighborhoods(context, places)
    val loaded = com.example.data.PropertyStorage.loadCustomNeighborhoods(context)
    assertEquals(3, loaded.size)
    assertEquals("سێمێل", loaded[0])
  }

  @Test
  fun `admin passcode DUHOK-AQAR-VIP-REVABAR98 unlocks manage`() {
    val viewModel = com.example.ui.RealEstateViewModel()
    val wrongResult = viewModel.unlockManage("WRONG123")
    org.junit.Assert.assertFalse(wrongResult)
    org.junit.Assert.assertFalse(viewModel.uiState.value.isManageUnlocked)

    val correctResult = viewModel.unlockManage("DUHOK-AQAR-VIP-REVABAR98")
    org.junit.Assert.assertTrue(correctResult)
    org.junit.Assert.assertTrue(viewModel.uiState.value.isManageUnlocked)
  }

  @Test
  fun `registered users persistence and master announcement work`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val users = listOf(
      com.example.data.UserProfile(
        name = "Azad Duhoki",
        email = "azad.duhok@gmail.com",
        age = 29,
        password = "PassAzad2026",
        registeredDate = "2026-10-30"
      )
    )
    com.example.data.PropertyStorage.saveRegisteredUsers(context, users)
    val loadedUsers = com.example.data.PropertyStorage.loadRegisteredUsers(context)
    assertEquals(1, loadedUsers.size)
    assertEquals("Azad Duhoki", loadedUsers[0].name)
    assertEquals("PassAzad2026", loadedUsers[0].password)

    com.example.data.PropertyStorage.saveAppAnnouncement(context, "Welcome to Duhok Real Estate")
    val announcement = com.example.data.PropertyStorage.loadAppAnnouncement(context)
    assertEquals("Welcome to Duhok Real Estate", announcement)
  }
}
