package com.example

import com.example.data.SampleProperties
import com.example.data.model.AppLanguage
import com.example.data.model.CurrencyMode
import com.example.data.model.ListingType
import com.example.data.model.LocaleStrings
import com.example.data.model.PropertyType
import com.example.data.model.VisitBooking
import com.example.ui.RealEstateViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

  @Test
  fun sampleProperties_loadedWithDuhokNeighborhoods() {
    val properties = SampleProperties.properties
    assertTrue("Should have sample properties", properties.isNotEmpty())

    val neighborhoods = properties.map { it.neighborhood }.toSet()
    assertTrue("Should include Masik", neighborhoods.contains("Masik"))
    assertTrue("Should include Malta", neighborhoods.contains("Malta"))
    assertTrue("Should include Avro City", neighborhoods.contains("Avro City"))
  }

  @Test
  fun sampleProperties_hasAllFourLanguages() {
    val firstProperty = SampleProperties.properties.first()

    assertNotNull(firstProperty.getTitle(AppLanguage.BADINI))
    assertNotNull(firstProperty.getTitle(AppLanguage.SORANI))
    assertNotNull(firstProperty.getTitle(AppLanguage.ARABIC))
    assertNotNull(firstProperty.getTitle(AppLanguage.ENGLISH))

    assertTrue(firstProperty.getTitle(AppLanguage.BADINI).contains("ڤێلایەکا"))
    assertTrue(firstProperty.getTitle(AppLanguage.ARABIC).contains("فيلا"))
  }

  @Test
  fun appLanguages_layoutDirectionCorrect() {
    assertTrue("Badini is RTL", AppLanguage.BADINI.isRtl)
    assertTrue("Sorani is RTL", AppLanguage.SORANI.isRtl)
    assertTrue("Arabic is RTL", AppLanguage.ARABIC.isRtl)
    assertFalse("English is LTR", AppLanguage.ENGLISH.isRtl)
  }

  @Test
  fun localeStrings_returnsLocalizedValues() {
    val badiniStrings = LocaleStrings.get(AppLanguage.BADINI)
    assertEquals("خانوبەرێن دهۆکێ", badiniStrings.appTitle)
    assertEquals("بۆ فڕۆشتنێ", badiniStrings.forSale)

    val soraniStrings = LocaleStrings.get(AppLanguage.SORANI)
    assertEquals("خانووبەرەکانی دهۆک", soraniStrings.appTitle)
    assertEquals("بۆ فرۆشتن", soraniStrings.forSale)

    val arabicStrings = LocaleStrings.get(AppLanguage.ARABIC)
    assertEquals("عقارات دهوك", arabicStrings.appTitle)
    assertEquals("للبيع", arabicStrings.forSale)

    val englishStrings = LocaleStrings.get(AppLanguage.ENGLISH)
    assertEquals("The Duhok-Aqar", englishStrings.appTitle)
    assertEquals("For Sale", englishStrings.forSale)
  }

  @Test
  fun currencyMode_formatsCorrectly() {
    val usdPrice = 250000.0 // 25 Daftars

    val usdFormat = CurrencyMode.USD.formatPrice(usdPrice)
    assertEquals("$250,000", usdFormat)

    val daftarFormat = CurrencyMode.DAFTAR.formatPrice(usdPrice)
    assertTrue("Should format in Daftars", daftarFormat.contains("25.0"))

    val iqdFormat = CurrencyMode.IQD.formatPrice(usdPrice)
    assertTrue("Should format in IQD", iqdFormat.contains("IQD"))
  }

  @Test
  fun viewModel_languageSwitching() {
    val viewModel = RealEstateViewModel()
    assertEquals(AppLanguage.BADINI, viewModel.uiState.value.appLanguage)

    viewModel.setLanguage(AppLanguage.SORANI)
    assertEquals(AppLanguage.SORANI, viewModel.uiState.value.appLanguage)

    viewModel.setLanguage(AppLanguage.ARABIC)
    assertEquals(AppLanguage.ARABIC, viewModel.uiState.value.appLanguage)

    viewModel.setLanguage(AppLanguage.ENGLISH)
    assertEquals(AppLanguage.ENGLISH, viewModel.uiState.value.appLanguage)
  }

  @Test
  fun sampleProperties_agentPhoneMatchesUserRequirement() {
    val sample = SampleProperties.properties.first()
    assertEquals("07514036954", sample.agent.phone)
    assertEquals("+9647514036954", sample.agent.whatsapp)
  }

  @Test
  fun viewModel_initialPropertiesEmptyByDefault() {
    val viewModel = RealEstateViewModel()
    assertTrue("Should start with 0 properties per user request", viewModel.uiState.value.properties.isEmpty())
  }

  @Test
  fun viewModel_addAndDeleteProperty() {
    val viewModel = RealEstateViewModel()
    assertEquals(0, viewModel.uiState.value.properties.size)

    val newProp = SampleProperties.properties.first().copy(id = "user_added_1")
    viewModel.addProperty(newProp)
    assertEquals(1, viewModel.uiState.value.properties.size)
    assertEquals("user_added_1", viewModel.uiState.value.properties.first().id)

    viewModel.deleteProperty("user_added_1")
    assertEquals(0, viewModel.uiState.value.properties.size)
  }

  @Test
  fun viewModel_loadDemoAndFilter() {
    val viewModel = RealEstateViewModel()
    viewModel.loadDemoProperties()
    assertTrue(viewModel.uiState.value.properties.isNotEmpty())

    viewModel.updateNeighborhood("Masik")
    val filtered = viewModel.getFilteredProperties()
    assertTrue(filtered.all { it.neighborhood.equals("Masik", ignoreCase = true) })

    viewModel.updateListingType(ListingType.FOR_RENT)
    val filteredRent = viewModel.getFilteredProperties()
    assertTrue(filteredRent.all { it.listingType == ListingType.FOR_RENT })
  }

  @Test
  fun viewModel_toggleFavoriteWithLoadedProperties() {
    val viewModel = RealEstateViewModel()
    viewModel.loadDemoProperties()
    val initialFavorite = viewModel.uiState.value.properties.first { it.id == "p2" }.isFavorite

    viewModel.toggleFavorite("p2")
    val updatedFavorite = viewModel.uiState.value.properties.first { it.id == "p2" }.isFavorite
    assertEquals(!initialFavorite, updatedFavorite)
  }

  @Test
  fun viewModel_scheduleVisit() {
    val viewModel = RealEstateViewModel()
    val booking = VisitBooking(
      propertyId = "p1",
      propertyTitle = "Royal Hillside Villa",
      date = "Tomorrow",
      timeSlot = "10:00 AM - 11:30 AM",
      tourType = "In-Person On-Site Visit",
      visitorName = "Kovan",
      visitorPhone = "+9647514036954"
    )

    viewModel.scheduleVisit(booking)
    assertTrue(viewModel.uiState.value.showBookingSuccessDialog)
    assertEquals(booking, viewModel.uiState.value.lastBookedVisit)
  }

  @Test
  fun viewModel_managePasscodeProtection_DUHOK_AQAR_VIP_REVABAR98() {
    val viewModel = RealEstateViewModel()
    assertFalse("Manage should be locked initially", viewModel.uiState.value.isManageUnlocked)

    // Wrong passcode should fail
    val wrongResult = viewModel.unlockManage("123456")
    assertFalse(wrongResult)
    assertFalse(viewModel.uiState.value.isManageUnlocked)

    // Correct passcode DUHOK-AQAR-VIP-REVABAR98 should succeed
    val correctResult = viewModel.unlockManage("DUHOK-AQAR-VIP-REVABAR98")
    assertTrue(correctResult)
    assertTrue("Manage should now be unlocked", viewModel.uiState.value.isManageUnlocked)

    // Lock manage
    viewModel.lockManage()
    assertFalse("Manage should be locked after lockManage()", viewModel.uiState.value.isManageUnlocked)
  }

  @Test
  fun viewModel_updateExistingProperty() {
    val viewModel = RealEstateViewModel()
    val initialProp = SampleProperties.properties.first().copy(id = "edit_test_1", priceUsd = 200000.0)
    viewModel.addProperty(initialProp)

    assertEquals(200000.0, viewModel.uiState.value.properties.first().priceUsd, 0.01)

    // Edit price and title
    val updatedProp = initialProp.copy(
      priceUsd = 275000.0,
      titleEn = "Updated Villa in Malta",
      areaSqm = 420
    )
    viewModel.updateProperty(updatedProp)

    val found = viewModel.uiState.value.properties.first { it.id == "edit_test_1" }
    assertEquals(275000.0, found.priceUsd, 0.01)
    assertEquals("Updated Villa in Malta", found.titleEn)
    assertEquals(420, found.areaSqm)
  }

  @Test
  fun viewModel_updateOfficeInfo() {
    val viewModel = RealEstateViewModel()
    viewModel.loadDemoProperties()

    assertEquals("07514036954", viewModel.uiState.value.officePhone)

    viewModel.updateOfficeInfo("07501234567", "Duhok Royal Real Estate")
    assertEquals("07501234567", viewModel.uiState.value.officePhone)
    assertEquals("Duhok Royal Real Estate", viewModel.uiState.value.officeName)

    // Check that properties agent phone is updated
    val firstProp = viewModel.uiState.value.properties.first()
    assertEquals("07501234567", firstProp.agent.phone)
  }

  @Test
  fun localeStrings_passcodeNeverExposedInUI() {
    for (lang in AppLanguage.values()) {
      val strings = LocaleStrings.get(lang)
      assertFalse(
        "Passcode should not appear in placeholder for $lang",
        strings.adminPasscodePlaceholder.contains("SAROKVIP98")
      )
      assertFalse(
        "Passcode should not appear in lock title for $lang",
        strings.adminLockTitle.contains("SAROKVIP98")
      )
      assertFalse(
        "Passcode should not appear in subtitle for $lang",
        strings.adminLockSubtitle.contains("SAROKVIP98")
      )
    }
  }

  @Test
  fun property_customImageSourcesSupport() {
    val propWithCustomImages = SampleProperties.properties.first().copy(
      id = "custom_img_prop",
      imageUris = listOf("/data/user/0/com.example/property_images/img_1.jpg", "/data/user/0/com.example/property_images/img_2.jpg"),
      imageResIds = emptyList()
    )
    val sources = propWithCustomImages.getImageSources()
    assertEquals(2, sources.size)
    assertEquals("/data/user/0/com.example/property_images/img_1.jpg", sources[0])
    assertEquals("/data/user/0/com.example/property_images/img_2.jpg", sources[1])
  }

  @Test
  fun viewModel_dynamicNeighborhoods_includesUserCustomPlaces() {
    val viewModel = RealEstateViewModel()
    val initialHoods = viewModel.getAllNeighborhoods()
    assertTrue(initialHoods.contains("All Duhok"))

    // Add a property with custom place name
    val customPlace = SampleProperties.properties.first().copy(
      id = "user_place_1",
      neighborhoodEn = "Semel",
      neighborhoodKu = "سێمێل",
      neighborhoodArabic = "سميل"
    )
    viewModel.addProperty(customPlace)

    val updatedHoods = viewModel.getAllNeighborhoods()
    assertTrue("Should include custom user place Semel", updatedHoods.contains("Semel"))
  }
}
